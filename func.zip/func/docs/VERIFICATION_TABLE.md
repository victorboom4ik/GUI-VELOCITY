# FVA hooks — runtime verification checklist

Cross-check every reconstruction claim against `C:\vmp\FuckVacAgain.dll`
running inside `cs2.exe` (pid = whatever CE reports).

## 1. Hook install state — verify `E9 rel32` at each target

```
# From mydbg or Cheat Engine (address = client.dll base + RVA):
db client.dll+0xACEF90  L 8       # Hook A target — expect E9 XX XX XX XX ??
db client.dll+0xAFDFB0  L 8       # Hook B target — expect E9 XX XX XX XX ??
db client.dll+0x1189930 L 8       # Hook C target — expect E9 XX XX XX XX ??
```

Any of these NOT beginning with `E9` means the hook is disarmed for this
session; re-inject FVA and retry.

## 2. Trampoline pool sanity

```
db client.dll_base - 0xF020 L 200
```

Expect to see:

* three `FF 25 00 00 00 00` gate stubs whose next qword lands inside FVA:
  `dq (client.dll_base - 0xF01D)` should equal FVA_base + 0x19D8C
  (Hook A handler entry).
* three sets of "original bytes + `FF 25` + qword back into client.dll":
  the qword should land at `client.dll_base + RVA + 5` (i.e. 5 bytes past
  the E9-patch site).

## 3. FVA scratch buffer at `FVA_base + 0x184C90`

```
dq FVA_base + 0x184C90 L 1
```

Between ticks in an active match the first qword should equal
`client.dll_base + 0x995748` — the address of
`??_7CBaseUserCmdPB@@6B@` (the CBaseUserCmdPB vtable). During
menu / lobby the buffer may be zero-initialised or hold a stale
last-match snapshot.

## 4. Typename filter — decode the encoded stack qwords

Standard XOR test (deterministic — no game state required):

```
0xF6E0262244CDBA8E ^ 0x9393734737ACF8CD = 0x6573614275654243
    (LE bytes  = "CBaseUse")
0x9F047512FCEAE7BC ^ 0x9F0437429887A4CE = 0x00004250646D7243  (approx)
    (LE bytes  = "rCmdPB\0\0")
Concatenation → "CBaseUserCmdPB" + 0x00 0x00  (14 chars + 2 pad = 16)
```

Any FVA-hosted variant that fails this XOR check has been re-obfuscated
by a game update; re-derive the qword pairs from the fresh dump.

## 5. Pattern-scanner sanity

Every pattern our scanner accepts is one of the ones you posted:

```
GameOverlayRenderer64.dll   present               "48 89 5C 24 ? 48 89 6C 24 ? 56 57 41 54 41 56 41 57 48 83 EC ? 41 8B E8"
client.dll                  createmove            "48 8B C4 4C 89 40 ? 48 89 48 ? 55 53 41 54"
client.dll                  overrideview          "40 57 48 83 EC ? 48 8B FA E8 ? ? ? ? BA"
client.dll                  createnewsubtickmovestep     (long)
client.dll                  handlebulletpenetration      "48 8B C4 44 89 48 ? 48 89 50 ? 48 89 48 ? 55 57"
…  (see the pattern manifest below)
```

For each, resolve at boot with:

```cpp
void* addr = fva::scanner::find_in_module(
    ::GetModuleHandleW(L"client.dll"),
    fva::scanner::parse("48 8B C4 4C 89 40 ? 48 89 48 ? 55 53 41 54"));
```

and record the RVA into a `pattern_manifest.json`.  If any resolves to
`nullptr`, the pattern has drifted and you need to reforge from the
current dump.

## 6. Pattern manifest (source: user-provided cspatterns dump)

See `src/patterns/patterns.inl` in the reconstruction — a header that
contains every one of the patterns you posted, ready to feed into
`fva::scanner::parse()` at startup.

## 7. Stage-by-stage checklist

| Stage | Method | File in reconstruction |
|-------|--------|------------------------|
| 1. dump | `FuckVacAgain.dll` + `FuckVacAgain_rebuild.exe` | already in cs2 dll new/ |
| 2. runtime | mydbg attach + db of each RVA above | mydbg command file in scratchpad |
| 3. devirt | `tools/devirtualize.ps1` from skeleton | present |
| 4. unpacker | same script | present |
| 5. CE+IDA+client.dll | IDA sessions 9579d2c2 + f464b09e; CE MCP for live reads | done through multiple workflow rounds |
| 6. hooks-on-hooks | inject a probe DLL that MinHook-wraps `fva::hooks::hook_body`, dump caller stacks | see `docs/PROBE_HOOK_TEMPLATE.cpp` (below) |
| 7. recheck each hook | at install time, byte-compare `db (target) L 5` before and after `MH_EnableHook` | built into `install_all()` via debug printfs |
| 8. deobfuscation | `obfuscation.cpp` reproduces XOR pair + YMM VPXOR + rolling-XOR | done |

## 8. Probe-hook template (for stage 6 — hook the FVA hook)

```cpp
// probe.cpp — MinHook wrapper AROUND fva::hooks::hook_body, dumps callers
#include <MinHook.h>
#include <DbgHelp.h>
#include <cstdio>

using SerFn = char(__fastcall*)(void*, void*, int);
SerFn g_orig_hook_c = nullptr;

char __fastcall probe_body(void* self, void* stream, int max_size)
{
    void* callers[16] = {};
    unsigned short n = CaptureStackBackTrace(1, 16, callers, nullptr);

    fprintf(stderr, "[probe] Hook C called; typename ptr = %p, stack:\n", self);
    for (unsigned i = 0; i < n; ++i)
        fprintf(stderr, "    [%u] %p\n", i, callers[i]);

    return g_orig_hook_c(self, stream, max_size);
}

extern "C" __declspec(dllexport) void install_probe(void* fva_hook_body_addr)
{
    MH_Initialize();
    MH_CreateHook(fva_hook_body_addr, reinterpret_cast<void*>(&probe_body),
                    reinterpret_cast<void**>(&g_orig_hook_c));
    MH_EnableHook(fva_hook_body_addr);
}
```

Load this DLL into cs2 AFTER FVA (via a separate CreateRemoteThread /
Extreme Injector call) and pass the FVA `hook_body` address as its
argument. The stderr trace shows every caller path of Hook C —
which tells you exactly which internal FVA subsystem is reading the
scratch buffer.
