# Fire-tick detection confirmed — 2026-07-10 15:33

Live in-match test with user pressing LMB in de_dust2. Reconstruction
`fva_recon.dll` @ build\Release, injected via `inject_vaclivebypass.ps1`
into cs2 PID 25792. Depot 2347770 manifest 7169488960211596754
(rolled back via DepotDownloader, matches manifest MD5
b0fd08261be12cceb8e5636500e5a1d0).

## Signals we now detect per tick

| Signal | Source | Sample event |
|--------|--------|--------------|
| Attack1 (LMB) | `raw+0x60` bit 0x1 | tick=2735 `BUTTONS changed=0000000000000401` |
| Attack2 (RMB) | `raw+0x60` bit 0x400 | tick=1966 `changed=0000000000000610` |
| Forward (W)   | `raw+0x60` bit 0x8 | tick=1774 `held=0000000000000008` |
| Left (A)      | `raw+0x60` bit 0x200 | tick=2811 `held=0000000000000200` |
| Fire-tick     | `raw->flags` bit 0x20 | tick=2735 `0x1D→0x3D` (SAME TICK as LMB) |
| Movement pres | `pb->has_bits` bits 0x40 / 0x80 | forward/leftmove toggles |
| Angle presence | `pb->has_bits` bit 0x4 | always set post-Section-F |
| Buttons submsg | `pb->buttons_pb` pointer | ring-buffer, ~6-tick period |
| Subtick input | `raw+0x28` current_size | 1→4 dance on mouse motion |

**Correlation confirmed**: `raw->flags` bit 0x20 flips 0x1D→0x3D **on the same
tick as** BUTTONS bit 0x1 (LMB). That bit is CS2's "attack fired this cmd"
marker — the wire-level equivalent of FVA Section-J's `rdi.flags |= 4` on
child.flags.

## What the FVA anti-aim would do here

Handler A Section J (from `sub_7FFBE80C9D8C @ +0xB69..+0xCC5`):

1. Latch fires when `alt_original != 0` (our version: 73 — ARMED).
2. Snapshot `pb->viewangles->{x,y,z}` (`prior_x/y/z`).
3. Compute `delta = wrap180(prior - target)` for each axis.
4. Append one `CSubtickMoveStep` with `pitch_delta = d_pitch`, `yaw_delta = d_yaw`.
5. **Write prior values back** into `pb->viewangles` (client-visible stays real;
   only the appended step carries the delta on the wire).

Result: server sees the fake angle set by the client (via subtick), the
client keeps drawing the true angle.

## Where reconstruction stops today

`fva::phase_b2::apply` is guarded by `g_target_armed` — until
`fva::phase_b2::set_target_angle(pitch, yaw, roll)` is called, apply()
bails at the second gate. This is by design: FVA has a UI/hotkey that
drives the target; we don't (yet).

To wire an automatic fire-tick spoof for validation, next step is:

```cpp
// Inside create_move_hook detour, after we've observed raw->flags:
static std::uint32_t s_last_flags = 0;
if ((raw->flags & 0x20) && !(s_last_flags & 0x20)) {
    // Attack tick edge — arm a diagonal target so the spoof visibly
    // rotates the wire viewangles by (89, 180, 0).
    fva::phase_b2::set_target_angle(89.0f, 180.0f, 0.0f);
}
if (!(raw->flags & 0x20) && (s_last_flags & 0x20)) {
    fva::phase_b2::clear_target_angle();
}
s_last_flags = raw->flags;
```

Then phase_b2::apply will fire ONCE per attack tick and mutate
subtick_moves + viewangles exactly the way FVA Handler A does.

## Reproduction

```powershell
Get-Process cs2 -EA SilentlyContinue | Stop-Process -Force
Remove-Item C:\vmp\fva_recon.log -EA SilentlyContinue
& C:\Users\sshunko\source\repos\MyDriver23\scripts\inject_vaclivebypass.ps1 `
     -DllPath C:\vmp\implementation_theory\reconstruction\build\Release\fva_recon.dll `
     -CS2Args '-insecure -nojoy +map de_dust2 +sv_cheats 1 +mp_warmup_end 1'
# Join a team, spawn, hold LMB.  Tail C:\vmp\fva_recon.log:
Get-Content C:\vmp\fva_recon.log -Wait |
  Where-Object { $_ -match 'BUTTONS.*changed=[0-9A-F]{15}[13579BDF]' }
```

## Manifest / build note

Manifest RVAs 0xACEF90 / 0xAFDFB0 / 0x1189930 still hit correctly on this
depot; sig-scan fallback for CInButtonStatePB::New / CMsgQAngle::New keeps
firing (heap fallback) because Valve refactored those `T::New(Arena*)`
functions but the change doesn't affect wire behaviour — phase_c caches
are orphan on this depot per grep 2026-07-10.
