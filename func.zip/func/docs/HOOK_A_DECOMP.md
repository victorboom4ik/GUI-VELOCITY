# FVA Hook A body — decompile map

`sub_7FFBE80C9D8C` @ FVA `+0x19D8C`, size **0x14DC bytes** (1203 instructions,
214 basic blocks).  Hex-Rays refuses to decompile the full function due to
VMProtect residue, so we chunk-read the disasm.

All FVA offsets below are relative to the function head (`sub` at
`0x7FFBE80C9D8C`).

## What FVA actually is

The strings inside the FVA image (`C:\SafetyPlugin-Unprotected\ext\google
protobuf\...` and `C:\SafetyPlugin-Unprotected\src\valve\protobufs\...`)
identify this DLL as a **VAC-evasion helper** (SafetyPlugin), not an
aimbot.  Its job is to make VAC not flag other mutation tools running in
the same process.  Concretely FVA:

1. Zeros two ConVars whose non-zero state would generate telltale log
   output (`cl_pred_print_every_cmd`, `cl_showusercmd`).
2. Regenerates `CBaseUserCmdPB.move_crc` on every tick so that whatever
   fields another tool mutated still hash to a value the server accepts.
3. Snapshots the outgoing `CBaseUserCmdPB` into a static scratch instance
   (Hook C) so `move_crc` can be recomputed from a known-good byte view.

The actual aim/wallhack mutation is expected to be done by a **separate**
tool running alongside FVA.  Our reconstruction reproduces FVA's
behaviour, not a cheat client's.

## Prototype

CS2 `void __fastcall CInput::CreateMove(void* this, int cmdNum, bool bActive)`.

Register save on entry:
- `r13 = rcx` = this (CInput*)
- `r15d = edx` = cmdNum
- `r14b = r8b` = bActive

## Phase-by-phase map

### Phase A — Cvar cache + per-tick zero  ✅ ported (Hook A detour + cvar_suppress)

| FVA offset | Instr | Meaning |
|-----------:|-------|---------|
| `+0x00A9`..`+0x00F4` | TLS-once-init on `dword_7FFBE823CBFC` | Guard for cvar #1 lookup |
| `+0x00F4`..`+0x0125` | `lea r10, aClPredPrintEve` + inline FNV-1a loop | strlen("cl_pred_print_every_cmd") then h = basis; for c in name: h = (h ^ c) * prime |
| `+0x012C` | `call sub_7FFBE80C9520` | FindConvarByHash(hash) |
| `+0x0131` | `mov qword_7FFBE823CC00, rax` | Cache cvar #1 ptr |
| `+0x0144`..`+0x01D0` | Same shape for `"cl_showusercmd"` → `qword_7FFBE823CBF0` |
| **`+0x01D7`** | **`mov rax, qword_7FFBE823CC00; test rax, rax; jz +7; mov [rax+58h], dil`** | **PER-TICK zero cvar #1 value byte** |
| **`+0x01E7`** | **`mov rax, qword_7FFBE823CBF0; test rax, rax; jz +7; mov [rax+58h], dil`** | **PER-TICK zero cvar #2 value byte** |

**Reconstruction port**: `fva::cvar_suppress::apply()` called from the top of
Hook A `detour`.  Lazy re-init via `ready()` in case ICvar isn't up yet at
first tick.

### Phase B — Read Hook B resolved state, chain-resolve CUserCmd  ✅ ported

| FVA offset | Instr | Meaning |
|-----------:|-------|---------|
| `+0x01F7` | `mov rbx, qword_7FFBE823A988` | Read Hook B resolved game state #2 (heap ptr from level_init) |
| `+0x0201`..`+0x0270` | TLS-guarded state cache (init once from game state) | `byte_7FFBE823A9A0 = *(game_state + dword_7FFBE823A9CC)` |
| `+0x0444`..`+0x06FE` | Three `call sub_7FFBE80DCB84` sites, patterns in FVA .rdata | Cache `GetSlotInput / GetCurrentSequence / GetCmdBySequence` |
| **`+0x06FE`** | `mov rax, qword_7FFBE823A948; xor ecx,ecx; call rax` | `input = GetSlotInput(0)` |
| `+0x0705`..`+0x071D` | Two-stage chain call | `seq = GetCurrentSequence(input); raw_cmd = GetCmdBySequence(input, seq)` |
| `+0x0935` | `mov rsi, qword_7FFBE823A918` | Cached `raw_cmd` after chain |
| `+0x0943` | `or [rsi+20h], r15d` | `raw_cmd->flags |= cmdNum` (typically 0 for local player) |
| `+0x0947` | `mov rdi, [rsi+40h]` | `base = raw_cmd->base` (CBaseUserCmdPB*) |

### Phase B2 — Angle wrap + subtick promotion  🟢 being ported (workflow wn61kvd0q, 2026-07-10)

Substantial region at **`+0x0944..+0x0CC5`** (0x7FFBE80CA6D0..0x7FFBE80CAA4C)
that HOOK_A_DECOMP.md originally missed.  Discovered by workflow
`wrb9k1fu0`; user reversed the skip decision on 2026-07-10 — full 1:1 FVA
parity requested.  Workflow `wn61kvd0q` produces deep decomp + C++ port
design that lands in `src/hooks/phase_b2.{h,cpp}`.

What it does:
- **+0x0944..+0x09EE**: Allocate `base->viewangles` if null via
  `sub_7FFBE80F6FEC` (CMsgQAngle NewMaybeArena).  Read
  `viewangles.x/y/z` into xmm13/11/12.  Compute per-axis delta vs
  `qword_7FFBE823C250` (prev-angles cache) via `sub_7FFBE81B3D60` (fmodf).
  Wrap by ±360 into local var_1C0.
- **+0x09EE**: If no free subtick slot, write current angles back to
  prev-cache at `[rbx+0/4/8]` and jump to end.
- **+0x0A20..+0x0AE0**: Iterate `raw_cmd->subtick_moves` (RepeatedField at
  `raw_cmd+0x28`), call `sub_7FFBE80CB268` (element accessor) +
  `sub_7FFBE8103A70` on elements with `[el+64h] != 0.0`.
- **+0x0AE0..+0x0CC5**: Allocate base if null; promote button/subtick
  state via protobuf helpers `sub_7FFBE8101160/1240/1470/1250`.  Contains
  the assertion string
  `"C:\SafetyPlugin-Unprotected\...google\protobuf\repeated_ptr_field.h"
   CHECK failed: (index) < (current_size_)` — plain protobuf assert
  scaffolding.

Original decision (SUPERSEDED 2026-07-10 — see block below): **⛔ keep skipped**.  Rationale:
- `qword_7FFBE823C250` (prev-angles cache) has zero external readers
  outside Hook A itself, same as Phase C aux mirrors (verified via
  xrefs).  Nothing consumes the wrapped delta.
- The subtick iteration writes into `raw_cmd->subtick_moves` fields that
  CS2 will then re-serialize into the outgoing cmd — but the same fields
  are ALREADY re-serialized by Hook C's scratch snapshot.  Doing the
  wrap ourselves doesn't affect what goes on the wire.
- The block presumes some **other** injector will mutate viewangles /
  subtick between CreateMove-original and SerializeToArray.  When we
  run without such an injector, the wrap+promotion is a no-op.

If we later run alongside an aim/movement injector that DOES mutate
viewangles or subtick_moves, we need to revisit — the promotion writes
that FVA does could then produce visibly different wire bytes than
skipping this block.

**2026-07-10 UPDATE — decision reversed by user:** full 1:1 FVA parity
requested including this block, regardless of whether external readers
consume the state.  Insertion point in `create_move_hook.cpp:detour()`:
between `client_input::current_local_cmd()` and the current
`raw->flags |= 1` line.  Ordering: B2 runs before Phase E because it may
mutate `base->viewangles` / `base->subtick_moves` fields that Phase E's
scratch snapshot then re-serialises into the wire bytes.

### Phase C — Field mirror to auxiliary protos  🟢 being ported (workflow wn61kvd0q, 2026-07-10)

Real location (correcting earlier doc): **`+0x1212..+0x13EC`**
(0x7FFBE80CAF9E..0x7FFBE80CB178), NOT `+0x0A34..+0x0AA2F` as previously
stated.  Skip decision is unchanged — verified via xrefs.

The `+0x1212..+0x13EC` chunk allocates or fetches a cached CMsgQAngle
(`qword_7FFBE8234CD0`) and mirrors `base->viewangles->x/y/z` into it via
`vmovss [cache+18h], xmm0` with `has_bits |= 1/2/4`.  Similar block a bit
earlier writes three `[rbx+60h/68h/70h]` fields into a cached CMsgVector
(`qword_7FFBE8234CC8`).  Purpose is unclear — these caches are likely
read by other FVA subsystems we haven't reversed, or are staging for a
future mutation subsystem.

Angle **wrapping** happens at `+0x0A3F`..`+0x0A80` — computes
`fmodf(current - previous, 360.0)` and adjusts by ±360 when |delta| > 180,
then stores the new angles back into a persistent buffer at
`qword_7FFBE823C250`.  Purpose is delta tracking for next-frame diff.

This is not part of the VAC-evasion critical path — omitting it does not
break the cvar suppress or move_crc regeneration.  Kept as a documentation
reference for future work if we want to wire in the auxiliary caches.

**2026-07-10 UPDATE — decision reversed:** cache pointers must be OUR
globals (not FVA globals at `0x7FFBE8234CC8/CD0`).  Allocate them in our
own BSS so we don't step on FVA's caches if co-injected.  Landing file:
`src/hooks/phase_c.{h,cpp}`.

### Phase D — Base64 anti-tamper self-audit  🟢 being ported adapted (workflow wn61kvd0q, 2026-07-10)

Real location (correcting earlier doc): **`+0x0D6A..+0x1213`**
(0x7FFBE80CAAF6..0x7FFBE80CAF87), NOT `+0x0AA2F..+0x0AE57` as previously
stated.  The deliberate crash instruction is EXACTLY at
**`0x7FFBE80CAF7F..CAF87`**:
```
0x7FFBE80CAF7A: test r13b, r13b       ; from setz r13b at CAF00
0x7FFBE80CAF7D: jnz +0x08
0x7FFBE80CAF7F: xor eax, eax
0x7FFBE80CAF81: mov dword ptr [rax], 1  ; ★ deliberate NULL deref
```

At `+0x0D6A..+0x1213` FVA does:

1. Read `base->move_crc` (protobuf bytes field) via arena tag deref
2. Base64-encode that byte string using `"ABCDEFGH…+/"` alphabet
3. Call `sub_7FFBE80C989C` (ScratchToString) to serialize the previously-
   captured cmd into a std::string
4. Base64-encode the ScratchToString output too
5. Compare the two encoded strings (length + memcmp)
6. If they **don't** match: `xor eax, eax; mov dword [rax], 1` → **crash
   FVA on purpose** (SEH triggers, process dies)

This is anti-tamper — FVA verifies its own scratch matches what CS2 will
put on the wire, and crashes if someone tampered with the scratch or the
process.

We do NOT reproduce this, because (a) our reconstruction isn't running
tamper-detected on itself, and (b) crashing on mismatch would prevent
diagnostic use.

**2026-07-10 UPDATE — partial reversal:** we WILL port the base64 encoder
+ comparison logic so the same code path executes and the same
registers/timing profile is observable, but we REPLACE the deliberate
NULL-deref crash with a log line + `raw->flags &= ~1` retreat (so a bug
in our port surfaces without killing the process).  Landing file:
`src/hooks/phase_d.{h,cpp}`.  Workflow `wn61kvd0q` decides insertion
point:
- If the audit reads move_crc after CS2 wrote it (before our Phase E), we
  must snapshot our own reference bytes to compare against.
- If the audit reads move_crc after mutation, then running D after our
  Phase E naturally passes.

### Phase E — mutation flag + move_crc rewrite  ✅ full port

| FVA offset | Instr | Meaning |
|-----------:|-------|---------|
| **`+0x01178`** | `call sub_7FFBE80C989C` | ScratchToString — serialise scratch into local std::string at `[rbp+var_F0]` |
| **`+0x0117E`** | **`or dword [rbx+20h], 1`** | **raw_cmd->flags |= 1** — mutation marker (★ ported) |
| `+0x01182`..`+0x011A1` | If `raw_cmd->base` is null, allocate it via `sub_7FFBE80FAD0C` (`NewMaybeArena_CBaseUserCmdPB`) | Ensure base exists |
| `+0x011A5` | `or dword [rax+10h], 1` | `base->has_bits |= CBASEUSERCMDPB_BITS_MOVE_CRC` |
| `+0x011A9`..`+0x011C5` | Compute `arena = base->meta.ptr & ~3`; `call sub_7FFBE81027F0(&base->move_crc, &var_F0, arena)` | **Copy ScratchToString bytes into base->move_crc via arena string copy** — this is the actual VAC-evasion payload |

**Reconstruction port**:

- `raw_cmd->flags |= 1` — done in Hook A detour.
- Scratch serialisation — done in `fva::scratch_serialize::serialize()`.
  ByteSizeLong is virtual so dispatched via `scratch.vtable[+0x38 / 8]`;
  the actual serialiser is CS2's `MessageLite::SerializePartialToArray`
  resolved by sig-scan in client.dll (RVA 0x1189A60 on the legacy build;
  live-verified unique via the anchor `48 83 EC 78 48 8B 05 ? ? ? ? …`).
- Vtable caching — done in `capture_buffer::cache_vtable_from(src)`,
  invoked from Hook C on the first CBaseUserCmdPB match.  Scratch's
  vtable is populated from CS2's live instance, enabling the ByteSizeLong
  virtual dispatch above.
- `base->move_crc.assign(bytes)` — done via `std::string::assign()` on
  the arena-owned string CS2 populated.  This reuses the existing string
  (SSO or heap-backed) — good enough while FVA-parity is diagnostic; a
  future upgrade to arena-aware assignment (mirroring
  `sub_7FFBE81027F0`) can be added if the extra bytes push past the
  arena's current allocation.
- `base->has_bits |= CBASEUSERCMDPB_BITS_MOVE_CRC` — set immediately
  after the assign to advertise the field to the wire encoder.

Runtime flow every tick:
1. Hook A `detour` fires.
2. Cvar zero (Phase A) + chain-resolve `raw_cmd` (Phase B).
3. If `raw_cmd->base->move_crc` is non-null AND
   `scratch_serialize::ready()`, serialise scratch to a thread_local
   `std::string` and assign it into `*base->move_crc`, set MOVE_CRC bit.
4. Set `raw_cmd->flags |= 1`.
5. Original CreateMove runs (already invoked at step 2 before mutation).

### Epilog

`+0x01464`..`+0x01472` — restore xmm6..13 saved on entry, pop callee-saved
regs, `retn`.  Nothing FVA-specific.

## Runtime globals FVA uses (verified via CE 2026-07-10)

| Global | Type | Live value | Meaning |
|--------|------|-----------|---------|
| `dword_7FFBE823CBFC` | int32 TLS guard | — | Cvar #1 once-init |
| `dword_7FFBE823CC0C` | int32 TLS guard | — | Cvar #2 once-init |
| `qword_7FFBE823CC00` | ConVar* | `0x04DC92087348` | Cached "cl_pred_print_every_cmd" |
| `qword_7FFBE823CBF0` | ConVar* | `0x04DC9208B2E0` | Cached "cl_showusercmd" |
| `byte_7FFBE823A97C` | latch | `0x01` | First-tick complete |
| `qword_7FFBE823A988` | void* game state | `0x04DCB5FA0000` | From Hook B |
| `qword_7FFBE823A948` | GetSlotInput | `0x7FFB65EB3930` | client.dll+0x8E3930 |
| `qword_7FFBE823A950` | GetCmdBySequence | `0x7FFB65E905E0` | client.dll+0x8C05E0 |
| `qword_7FFBE823A968` | GetCurrentSequence | `0x7FFB65E8D900` | client.dll+0x8BD900 |
| `qword_7FFBE823A918` | CUserCmd* raw_cmd | `0x04DCF6BD7440` | Result of chain |
| `qword_7FFBE823C250` | pointer → float[3] | `0x04DC0C0A3040` | Frame-to-frame delta cache; storage is an 8-byte pointer, not inline floats |
| `qword_7FFBE8234CC8` | CMsgVector* | (allocated on demand) | Mirror of `[rbx+60h/68h/70h]` — purpose unclear |
| `qword_7FFBE8234CD0` | CMsgQAngle* | (allocated on demand) | Mirror of viewangles.x/y — purpose unclear |
| `qword_7FFBE823CBE0` | fn ptr | `0x7FFB655C0F40` | Hook C original trampoline |

Cvar values on live process (Hook A fires ~128 Hz, per-tick zero):
- `*(qword_7FFBE823CC00 + 0x58)` = `0x00` ✓
- `*(qword_7FFBE823CBF0 + 0x58)` = `0x00` ✓

CUserCmd->flags on live process = `0x1D` = 0b11101 → bit 0 set (FVA marker).

## Reconstruction status snapshot

| Phase | FVA offset range | Status |
|-------|------------------|--------|
| A — cvar cache + per-tick zero | `+0x0000`..`+0x01F7` | ✅ ported |
| B — Hook B state read + chain-resolve | `+0x01F7`..`+0x0944` | ✅ ported (chain only, state read is diagnostic) |
| B2 — angle wrap + subtick promotion | `+0x0944`..`+0x0CC5` | ✅ ported → `src/hooks/phase_b2.{h,cpp}` (2026-07-10) |
| D — base64 anti-tamper self-audit | `+0x0D6A`..`+0x1213` | ✅ ported adapted → `src/hooks/phase_d.{h,cpp}` (encoder+cmp; log-not-crash on mismatch) |
| C — aux proto mirrors | `+0x1212`..`+0x13EC` | ✅ ported → `src/hooks/phase_c.{h,cpp}` (orphan caches — Phase E rewrite is follow-up) |
| E body — scratch serialise + move_crc rewrite | `+0x1178`..`+0x11CB` | ✅ ported |
| E flag — raw_cmd->flags |= 1 | `+0x117E` | ✅ ported |
| Epilog | `+0x1464`..`+0x1472` | ✅ compiler-provided |
