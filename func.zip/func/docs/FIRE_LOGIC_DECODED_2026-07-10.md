# Handler A — full shot-fire logic (statically decoded)

Static decode from `sub_7FFBE80C9D8C` (Handler A body) in the
`FuckVacAgain_rebuild.exe.i64` IDA session. This covers offsets from
`+0x2E9` (the one call to original) through the Section J fire path.
Everything below is verifiable from the disasm — no live trace needed.

## Global slots created / used by Handler A

| RVA        | Global name                | Role |
|-----------:|----------------------------|------|
| 0x18A918   | `qword_7FFBE823A918`       | **CACHED PER-TICK `raw_cmd_root`** (result of `GetCmdBySequence`). This is the "old tick" storage the user asked about. |
| 0x18A920   | `qword_7FFBE823A920`       | **CACHED `child_cmd`** (the CUserCmd that actually goes out on the wire) |
| 0x18A928   | `qword_7FFBE823A928`       | Client-side global interface pointer (populated from `client_base + 0x2320570`) |
| 0x18A930   | `dword_7FFBE823A930`       | Init counter for sig-scan slot 1 |
| 0x18A934   | `dword_7FFBE823A934`       | **Cached field offset** (from hash `0x737DDDA9E99E0B5D`) added onto interface ptr to find the sub-object holding subtick_move base |
| 0x18A938   | `dword_7FFBE823A938`       | Init counter for sig-scan slot 2 |
| 0x18A93C   | `dword_7FFBE823A93C`       | **Cached field offset** (from hash `0x9320AED4F2DDF04B`) — offset within subtick_moves array to fire flag |
| 0x18A948   | `qword_7FFBE823A948`       | **Resolved `GetSlotInput` fn ptr** (sig `48 83 ec ?? 83 f9 ?? 75 ?? 48 8b 0d ??`...) |
| 0x18A950   | `qword_7FFBE823A950`       | **Resolved `GetCmdBySequence` fn ptr** (sig `40 53 48 83 EC 20 8B DA E8 ?? ?? ?? ?? 4C`...) |
| 0x18A958   | `dword_7FFBE823A958`       | Init counter for sig-scan slot 3 |
| 0x18A95C   | `dword_7FFBE823A95C`       | Init counter for hash-resolve slot 4 |
| 0x18A960   | `dword_7FFBE823A960`       | Init counter for hash-resolve slot 5 |
| 0x18A968   | `qword_7FFBE823A968`       | **Resolved `GetCurrentSequence` fn ptr** (sig `48 83 EC 28 E8 ?? ?? ?? ?? 8B 80`...) |
| 0x18A970   | `dword_7FFBE823A970`       | **Cached field offset** (from hash `0xC08C21B68A2C746D`) — offset of subtick counter within interface |
| 0x18A974   | `dword_7FFBE823A974`       | Init counter for `dword_7FFBE823A93C` |
| 0x18A978   | `dword_7FFBE823A978`       | **Live subtick counter mirror** (published for external overlay / debug) |
| 0x18A97C   | `byte_7FFBE823A97C`        | Handler B "already fired" flag (from earlier decode) |
| 0x18A9A0   | `byte_7FFBE823A9A0`        | **ORIGINAL byte snapshot** taken at Hook B init — the "arm indicator" |
| 0x18C250   | `qword_7FFBE823C250`       | **Engine-side view state** — Handler A subtracts engine's pitch from raw_cmd pitch to compute delta |
| 0x184C90   | `unk_7FFBE8234C90`         | Hook C scratch (not touched by Handler A directly) |

## Section-by-section execution flow

### Section A/C (top of the body, before the one call to original)

1. TLS-guarded init of `qword_7FFBE823CBE8` (original CreateMove ptr).
2. FNV1a-resolve two ConVars (`cl_pred_print_every_cmd`,
   `cl_showusercmd`) into `qword_7FFBE823CC00` / `qword_7FFBE823CBF0`,
   guarded by counters `dword_7FFBE823CBFC` / `CC0C`.
3. **Zero `[cvar+0x58]`** for both ConVars — silences the two debug
   spammers *before* CS2 builds the usercmd.

### Section D (before the one call)

1. `alt_symbol::init_and_snapshot()` — snapshots
   `byte_7FFBE823A9A0 = *[qword_7FFBE823A988 + resolved_offset]` on
   first fire. This is the **arm indicator**: if the target byte was 0
   at snapshot time, Section J below is skipped forever.
2. `alt_symbol::apply()` — zero the target byte every tick to keep it
   from tripping CS2 code.

### The one call to original (`+0x2E9`)

```
mov r8b, r14b        ; a3 = bFinal
mov edx, r15d        ; a2 = nSlot
mov rcx, r13         ; a1 = self
call cs:qword_7FFBE823CBE8   ; original CreateMove
```

CS2 fills the local CUserCmd from input state here — every mutation
Handler A does afterwards sees the freshly-built payload.

### Section B — three-sig chain-resolve of `raw_cmd_root`

Three lazy sig-scans (each guarded by its own dword counter). Each one:

1. AVX-XOR-decrypts an IDA-style byte-pattern string on stack
2. Calls `sub_7FFBE80DCB84(pattern_str, client_module)` which returns
   the address of the matched function

Slots resolved (in order):

| Sig prefix                                    | Slot                    | Role |
|-----------------------------------------------|-------------------------|------|
| `48 83 ec ?? 83 f9 ?? 75 ?? 48 8b 0d ??`      | `qword_7FFBE823A948`    | **`GetSlotInput(int slot)`** — returns per-slot input info |
| `48 83 EC 28 E8 ?? ?? ?? ?? 8B 80`            | `qword_7FFBE823A968`    | **`GetCurrentSequence(slot_input)`** — current command sequence # |
| `40 53 48 83 EC 20 8B DA E8 ?? ?? ?? ?? 4C`   | `qword_7FFBE823A950`    | **`GetCmdBySequence(slot_input, seq)`** — the raw CUserCmd for that sequence |

Then chain-called:
```
rax = GetSlotInput(0)
rax = GetCurrentSequence(rax)          ; save = seq
rax = GetCmdBySequence(slot_input, seq); result = raw_cmd_root
qword_7FFBE823A918 = raw_cmd_root       ; STASH PER-TICK
```

This qword is what the user identified as "старые тики". Every
CreateMove call updates it in place; a mutation elsewhere in FVA can
read the last raw CUserCmd back at any time.

### Section E — set flags + ensure child alloc

```
raw_cmd_root.flags |= 1                 ; (offset +0x20)
if (raw_cmd_root.child == nullptr) {
    if (raw_cmd_root.arena_tag & 1)
        arena = *(void**)(raw_cmd_root.arena_tag & ~3);
    else
        arena = (void*)(raw_cmd_root.arena_tag & ~3);
    raw_cmd_root.child = sub_7FFBE80FAD0C(raw_cmd_root); ; arena-alloc child CUserCmd
}
qword_7FFBE823A920 = raw_cmd_root.child ; STASH — this is the wire cmd
```

### Section B (cont.) — resolve interface field offsets

Handler A calls `sub_7FFBE80FB1C4(hash_qword)` (a **hash-to-offset**
resolver, distinct from the sig-scanner) three times:

| Hash                       | Cached offset dst           | Purpose |
|----------------------------|-----------------------------|---------|
| `0x737DDDA9E99E0B5D`       | `dword_7FFBE823A934`        | Offset within `qword_7FFBE823A928` interface to the sub-object holding subtick base (used by `sub_7FFBE80DBB0C`) |
| `0x9320AED4F2DDF04B`       | `dword_7FFBE823A93C`        | Offset within that sub-object to the "fire flag" byte |
| `0xC08C21B68A2C746D`       | `dword_7FFBE823A970`        | Offset within that sub-object to the live subtick counter |

Handler A then does:

```
subobj = sub_7FFBE80DBB0C(qword_7FFBE823A928 + dword_7FFBE823A934);
qword_7FFBE823A910 = subobj;

live_subtick_count = *(int32_t*)(subobj + dword_7FFBE823A970);
dword_7FFBE823A978 = live_subtick_count;    ; MIRROR for overlay/debug
if (live_subtick_count <= 0) return;         ; nothing to do
```

### Section C (post-init cvar zero — belt & braces)

Redundant cvar zero even after the pre-original block ran. Same two
ConVar callback fields hit again with `= 0`.

### Section J — the SHOT-FIRE injection (only if arm indicator was set)

```
if (byte_7FFBE823A9A0 == 0)              ; arm indicator was 0 at init
    goto skip_j;                          ; → return without touching subticks
```

If armed:

```
rbx = qword_7FFBE823C250;                 ; engine view state
rsi = qword_7FFBE823A918;                 ; the raw_cmd_root we stashed
rsi.flags |= 1;                            ; belt & braces (again)

rdi = rsi.child;                           ; child_cmd
if (rdi == nullptr) {
    rdi = sub_7FFBE80FAD0C(rsi);          ; arena-alloc child
    rsi.child = rdi;
}
rdi.flags |= 4;                            ; ★ FIRE FLAG on child.flags

rax = rdi.subtick_moves;                   ; child.subtick_moves
if (rax == nullptr) {
    rax = sub_7FFBE80F6FEC(rdi);          ; arena-alloc subtick_moves[0]
    rdi.subtick_moves = rax;
}

; ★ SNAPSHOT viewangles FROM the fresh subtick_moves[0] slot
xmm13 = subtick_moves.pitch;               ; +0x18
xmm11 = subtick_moves.yaw;                 ; +0x1C
xmm12 = subtick_moves.roll;                ; +0x20  (or a subtick-specific delta)

; ★ Compute delta against ENGINE view (previous authoritative angles)
delta_pitch = xmm13 - engine.pitch;         ; [rbx+0]
delta_pitch = wrap_to_neg180_180(delta_pitch);   ; sub_7FFBE81B3D60 (fmodf-like)
; ...same shape for yaw / roll below (truncated at 300 insns)
```

The rest of Section J (past instruction 300 — cursor.next=500 in the
disasm) continues the subtick move injection: it fills subtick_moves
with the wrapped deltas, sets bit `4` on `child.flags` to signal to
CS2's serializer that this cmd has a viewangle override, and populates
`CInButtonStatePB` scratch (the reconstruction phase_c helper) with
the current input button mask.

### Section H / I / F (deeper — decompile continues)

After Section J: populate `CInButtonStatePB` scratch, populate
`CMsgQAngle` scratch, then `scratch_serialize` fills the `move_crc`
string of `child` with the serialized subtick payload. Bits on
`child.has_bits` get toggled to mark MOVE_CRC and VIEWANGLES as
present. This matches reconstruction's `phase_c.cpp` /
`scratch_serialize.cpp` layer.

## User's questions answered

- **"Точно знаю что хук срабатывает на выстрел"** — confirmed. Section J
  fires only when `byte_7FFBE823A9A0 != 0`. That byte holds the SNAPSHOT
  of `*(qword_7FFBE823A988 + resolved_offset)` taken at Hook B init.
  Handler B (LevelInit) sets up `qword_7FFBE823A988` to point at the
  weapon-armed / attack-button-was-down slot in CS2 engine state. When
  the byte is non-zero at Handler A's Section D snapshot, the arm is
  latched and Section J fires from that tick onward.

- **"Он сохраняет старые тики"** — confirmed. Per-tick chain
  `GetSlotInput → GetCurrentSequence → GetCmdBySequence` writes the
  current tick's `raw_cmd_root` to `qword_7FFBE823A918` and its child
  cmd to `qword_7FFBE823A920`. Any subsequent FVA subsystem can read
  the last outgoing CUserCmd from those globals without re-hitting the
  chain.

## Where to add per-tick trace (if user still wants HW BP)

If cs2 stops crashing during FVA inject, the interesting single-line
trace points to arm are:

| Addr (VA in current session) | What it captures |
|-------|--------------------|
| `FVA + 0x19D8C` (Handler A entry) | every tick (128 Hz) |
| `FVA + 0x1A4B3` (mov qword_7FFBE823A918, rax) | just-computed raw_cmd_root ptr |
| `FVA + 0x1A6F9` (or dword ptr [rdi+10h], 4) | fire flag set → shot tick edge |
| `FVA + 0x1A6BB` (cmp byte_7FFBE823A9A0, 0)  | Section J gate — decides if this tick is a shooter |

The cleanest single BP is the `or dword ptr [rdi+10h], 4` — it fires
ONLY on shot ticks, once per shot, no tick-rate storm.

## Path to a working per-tick tracer

The v1 fva_hookbp DLL died to a Suspend-all-threads race in ntdll
heap fastpath. The v2 built here arms DR only on cs2's main thread
(chosen by earliest CreationTime), which avoids the race. It has not
yet been tested end-to-end because the current cs2 process crashed
right after FuckVacAgain injection (a race between FVA's own VMP init
and our LdrLoadDll shellcode — unrelated to our tracer).

If cs2 next launches cleanly with FVA still stable, injecting
`C:\vmp\fva_hookbp\fva_hookbp_v2.dll` right after FVA loads should
produce `C:\vmp\fva_livecap\hookbp_v2_trace.log` with one entry per
CreateMove tick + one entry per SerializeToArray call — enough to
correlate wall-clock shot events (from screen recording or CS2 log)
against per-tick reg state.
