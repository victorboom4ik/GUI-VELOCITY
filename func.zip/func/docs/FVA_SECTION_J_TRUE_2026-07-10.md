# FVA Section-J — истинный алгоритм из IDA disasm (2026-07-10 16:00)

Прямой decompile `C:\vmp\FuckVacAgain.dll.i64` (session ea21efe4) и
`C:\vmp\fva_livedump\FuckVacAgain_rebuild.exe.i64` (session 33ec1c00)
через IDA MCP.

## 1. FVA НЕ добавляет entries в subtick_moves напрямую

Handler A (`sub_7FFBE80C9D8C`) сам НИКОГДА не вызывает
`sub_7FFBE80FABFC` (CSubtickMoveStep::NewInArena) — xrefs подтверждают:
единственные caller'ы — `sub_7FFBE80F7FF8`, `sub_7FFBE80F94AC`
(CBaseUserCmdPB::MergeFromCoded), `sub_7FFBE80FAE84`. Handler A их не
среди них.

Handler A также НЕ вызывает `sub_7FFBE8101EA0` (RepeatedPtrField
AddAllocated). Ни одного xref от Handler A.

**Значит Section-J не использует стандартный protobuf append.**

## 2. Что делает Section-J на самом деле

Из disasm вокруг +0x8C0..+0xCA0 в Handler A:

```
mov r14, cs:qword_7FFBE823A918      ; r14 = raw_cmd_root (per-tick stashed CUserCmd)
add r14, 28h                         ; r14 = raw+0x28 = subtick_moves inline field
                                     ; (RepeatedPtrField_t<CSubtickMoveStep>)

; delta_pitch/yaw/roll в xmm13/11/12 (computed earlier)
; prior_x/y/z restore path:
vmovss dword ptr [rbx], xmm13        ; else path: restore viewangles + skip
vmovss dword ptr [rbx+4], xmm11
vmovss dword ptr [rbx+8], xmm12
jmp loc_7FFBE80CAA2F

; MAIN PATH — iterate existing subtick_moves searching for matching entry:
mov edi, [r14+8]                     ; edi = subs->current_size
sub edi, 1                           ; edi = current_size - 1  (last index)
js short skip_search                 ; if empty, no search
search_loop:
    mov edx, edi                     ; index
    mov rcx, r14                     ; subs pointer
    call sub_7FFBE80CB268             ; get element at index (RepeatedPtrField::Get)
    mov ecx, [rax+10h]                ; ecx = element->has_bits
    shr ecx, 0Ah                      ; bit 10 (?)
    test r15b, cl                     ; test bit 0
    jz found_matching                 ; if bit not set → found
    vmovss xmm0, dword ptr [rax+64h]  ; read element +0x64 (some cached float)
    vucomiss xmm0, cs:dword_7FFBE82190AC  ; compare to constant
    jp neq | jz found_matching
    sub edi, 1                        ; walk back to earlier index
    jns search_loop
found_matching:
    lea rdx, [rbp+delta_buffer]       ; local delta buffer (16 bytes zero-init)
    mov rcx, rax                      ; element
    call sub_7FFBE8103A70              ; SETTER — writes delta into element

; Then check remaining slots:
mov esi, 10h                          ; 16 (capacity cap)
sub esi, [rax+30h]                    ; esi = 16 - child.subtick_moves.current_size
test esi, esi
jg has_room
; else fall through to restore
```

Then IF `remaining_slots > 0` (child.subtick_moves has space):

```
mov rdi, cs:qword_7FFBE823A918        ; raw_cmd_root
or [rdi+20h], r15d                    ; raw->flags |= 1  (bit0 = has-child)
mov rax, [rdi+40h]                    ; rax = raw->child (CBaseUserCmdPB*)
test rax, rax
jnz have_child
; lazy-alloc child via arena:
mov rcx, [rdi+18h]                    ; arena_word
and rcx, ~3
test [rdi+18h], 1
jz not_tagged
mov rcx, [rcx]                        ; deref if tagged
not_tagged:
call sub_7FFBE80FAD0C                 ; CBaseUserCmdPB::NewInArena
mov [rdi+40h], rax                    ; raw->child = new

have_child:
mov ecx, [rax+54h]                    ; child+0x54 = random_seed (from FVA proto)
mov [rbp+cached_seed], ecx            ; save

; Iterate child.subtick_moves reading a magic value:
mov r13d, [child+30h]                 ; r13d = child.subtick_moves.current_size
xor edi, edi                          ; edi = 0
test r13d, r13d
jle skip_iter
iter_loop:
    ; ...runs bounds-check on rep→elements[edi], reads element+0x60,
    ; caches ecx = element+0x60 into var_1D0
    mov rax, [child+38h]              ; child.subtick_moves.rep
    mov rdx, [rax + edi*8 + 8]         ; rep->elements[edi]
    test rdx, rdx
    jz iter_advance
    mov ecx, [rdx+60h]                 ; element+0x60 = last-known button/state
    mov [rbp+var_1D0], ecx
iter_advance:
    inc edi
    cmp edi, r13d
    jl iter_loop

; THE CRITICAL CALL:
mov [rsp+var_240], ecx                ; pass cached_button
mov r9d, esi                          ; r9d = remaining_slots
lea r8, [rbp+delta_buffer]            ; r8 = &delta_pitch (from earlier)
mov rdx, rbx                          ; rdx = engine.view_state (from Section start)
mov rcx, r14                          ; rcx = raw.subtick_moves inline field
call sub_7FFBE80C9614                  ; ← THE ACTUAL EMITTER

; And ALWAYS restore viewangles at end:
vmovss dword ptr [rbx], xmm13
vmovss dword ptr [rbx+4], xmm11
vmovss dword ptr [rbx+8], xmm12
```

## 3. `sub_7FFBE80C9614` — thunk to `sub_7FFBE82E8C32`

Реальный emitter — `sub_7FFBE82E8C32(subs_field, engine_view, delta_buf, remaining_slots, cached_button)`.

Он делает `remaining_slots` итераций:

```c
do {
    // Interpolate delta at fraction — вычислить дробную позицию
    _RAX = sub_7FFBE80C95B4(&v42, engine_view, delta_buf, iter_index, remaining_slots);
    if (subs_field) {
        // xmm6 = returned pitch, xmm7 = yaw, xmm8 = roll (via ASM)
        // Sig-scan client.dll for CS2's own protobuf T::New helper
        // (cached in qword_7FFBE823A9C0 via TLS-guarded init):
        _RBX = qword_7FFBE823A9C0(subtick_arena);  // ← CS2's CSubtickMoveStep::New
        if (_RBX) {
            // ALSO sig-scan for a SECOND helper (qword_7FFBE823A9A8):
            _RAX = qword_7FFBE823A9A8(0);  // ← CS2's CMsgQAngle::New(arena=null)
            _RSI = _RAX;
            if (_RAX) {
                // Write pitch/yaw/roll into fresh CMsgQAngle:
                *(float*)(_RAX + 0x18) = xmm6;  // CMsgQAngle.x = pitch
                *(float*)(_RAX + 0x1C) = xmm7;  // CMsgQAngle.y = yaw
                *(uint32_t*)(_RAX + 0x10) |= 7; // has_bits |= X|Y|Z
                *(float*)(_RAX + 0x20) = xmm8;  // CMsgQAngle.z = roll

                // Arena consistency check on subtick step's arena vs new qangle
                // — if mismatch, sub_7FFBE8101CC0 (arena copy):
                if (subtick_step.arena != qangle.arena)
                    _RSI = sub_7FFBE8101CC0(subtick_step.arena, _RSI);

                // ATTACH CMsgQAngle POINTER to subtick step at offset +0x18:
                *(_QWORD*)(_RBX + 0x18) = _RSI;

                // Set other subtick step fields:
                *(uint32_t*)(_RBX + 0x60) = cached_button;
                *(float*)(_RBX + 0x64) = xmm9;  // some fraction (when)
                *(_QWORD*)(_RBX + 0x68) = 0;
                *(uint32_t*)(_RBX + 0x10) |= 0x1E01;  // has_bits: fields present

                // NOW INSERT into subs->rep — inline AddAllocated equivalent:
                // Check arena consistency:
                if (subs->arena == subtick_step.arena
                    && subs->rep != nullptr
                    && subs->rep->allocated_size < subs->total_size)
                {
                    // Fast path: swap element and increment counters
                    if (subs->current_size < subs->rep->allocated_size)
                        subs->rep->elements[allocated_size] = subs->rep->elements[current_size];
                    subs->rep->elements[current_size++] = subtick_step;
                    subs->rep->allocated_size++;
                }
                else
                {
                    // Slow path — arena-copy + grow:
                    sub_7FFBE80CB348(subs, subtick_step, subs->arena, ...);
                }
            }
        }
    }
} while (++iter_index < remaining_slots);
```

## 4. Ключевые различия с нашей реконструкцией

| Аспект | Мы делали | FVA делает |
|---|---|---|
| Alloc CSubtickMoveStep | Свой `alloc_and_init_step` с sig `48 8D 05 ? ? ? ? 48 89 01` для vtable | Sig-scan CS2's own CSubtickMoveStep::New через `48 89 5C 24 ? 57 48 83 EC ? 33 DB 48 8B F9 48 85 C9 75 ? B9 ? ? ? ? E8` и ВЫЗОВ этой функции — CS2 сам стампит правильный vtable |
| Alloc CMsgQAngle sub-message | НЕ делали | Sig-scan CS2's CMsgQAngle::New (same sig shape), выделяет fresh CMsgQAngle, пишет pitch/yaw/roll |
| Attach CMsgQAngle to subtick | НЕ делали | `*(void**)(subtick_step + 0x18) = new_qangle` — записывает pointer на CMsgQAngle **в offset +0x18 subtick step'а**! Layout CSubtickMoveStep у FVA/CS2 отличается — +0x18 это НЕ button (u64) как в моих layout header'ах, а pointer на CMsgQAngle |
| Insert в rep | Пытались overwrite `elements[current_size]` | Inline AddAllocated с проверкой arena_consistency и SWAP старого pointer'а в `elements[allocated_size]` (не leak!) |
| Loop iterations | 1 emit per Section-J | `remaining_slots = 16 - child.current_size` итераций (spread спуфа по нескольким subticks с fractional when) |
| pre-emit search | НЕТ | Прежде чем emit, iterate existing entries и `sub_7FFBE8103A70` (какой-то SETTER) на найденный slot |

## 5. Правильная sig для CS2 protobuf T::New

**Наша текущая (WRONG)**:
```
48 89 5C 24 08 57 48 83 EC 20 48 8B F9 33 D2
```
Не совпадает с CS2 build'ом — потому phase_c.cpp fallback SIG-scan промахивался.

**FVA's exact sig (verified in IDA)**:
```
48 89 5C 24 ? 57 48 83 EC ? 33 DB 48 8B F9 48 85 C9 75 ? B9 ? ? ? ? E8
```

Ключевые отличия:
- `33 DB` (xor ebx, ebx) ПЕРЕД `48 8B F9` (mov rdi, rcx)
- `48 85 C9` (test rcx, rcx) ПОСЛЕ mov rdi, rcx
- НЕ `33 D2` (xor edx, edx)

## 6. Почему наша реконструкция крашила cs2

Крашила по нескольким причинам, минимум:

1. `find_csubtick_vtable` использует sig `48 8D 05 ? ? ? ? 48 89 01` — это `LEA + MOV [rcx], rax`, что встречается в **сотнях** protobuf конструкторов в client.dll. Первый попавшийся hit — почти наверняка НЕ CSubtickMoveStep vtable.

2. Наш стэмпл этого чужого vtable → CS2 диспатчил virtual methods → произвольные указатели → crash.

3. Даже с "приватным" вариантом мы НЕ вызывали CS2's own `CSubtickMoveStep::New`. FVA всегда идёт через CS2 функцию — CS2 сам стампит правильный vtable+metadata+arena, и всё protobuf machinery ниже работает как надо.

4. Наш `subs->rep->elements[current_size] = step` не заботился о `subs->total_size` cap и не делал swap — FVA сохраняет старый pointer в `elements[allocated_size]` (растёт allocated_size вместе с current_size).

## 7. Actionable fix для phase_b2

Правильная реализация должна:
1. Sig-scan CS2's `CSubtickMoveStep::New(Arena*)` — `48 89 5C 24 ? 57 48 83 EC ? 33 DB 48 8B F9 48 85 C9 75 ? B9 ? ? ? ? E8` — БЕРЁМ ПЕРВЫЙ HIT (FVA так и делает; проверка — размер immediate = 0x38/56)
2. Sig-scan CS2's `CMsgQAngle::New(Arena*)` — та же shape но size=0x28/40
3. В Section-J-эквиваленте:
   - Call CS2 CSubtickMoveStep::New(subs_arena) → new_step
   - Call CS2 CMsgQAngle::New(0) → new_qangle
   - Write pitch/yaw/roll в new_qangle+0x18/1C/20; has_bits |= 7
   - Arena-consistency check + arena-copy если разные
   - Write new_qangle pointer at new_step+0x18 (viewangles field)
   - Write button at new_step+0x60, when at +0x64
   - new_step->has_bits |= 0x1E01
   - Inline AddAllocated: swap-safe insert в subs→rep

Ключевое — CS2 сам делает правильную vtable+metadata инициализацию,
никаких stamp'ов от нас не нужно.

## 8. Что делать со схемой offset'ов

CSubtickMoveStep у FVA/CS2 (per Section-J writes):
- +0x00: vtable (u64) — CS2 стампит
- +0x08: metadata / arena (u64) — CS2 инициализирует
- +0x10: has_bits (u32)
- +0x14: cached_size (u32)
- +0x18: **CMsgQAngle* viewangles** (не button!)
- +0x20: (skip)
- +0x60: button (u32)
- +0x64: when (float)
- +0x68: 0

Наш `valve/cbaseusercmdpb_layout.h` описывает CSubtickMoveStep иначе:
```
uint64_t button;         // +24 = +0x18  ← но FVA видит здесь ptr на CMsgQAngle
bool     pressed;        // +32
float    when;           // ...
```

Возможно наш layout полностью неверен для этого CS2 build'а. Нужно
регенерировать layout из fresh cs2-dumper output.

## 9. TL;DR

**FVA использует CS2 собственные protobuf helpers через sig-scan.**
Не пытается сама аллоцировать / стэмпить vtable. Делегирует всё
CS2, получает готовые правильные messages, только заполняет float
поля + has_bits + инсертит.

**Наша реконструкция пыталась shortcut'нуть аллокацию — это была
принципиальная ошибка**. Нужен полный порт этого алгоритма с точным
CS2 sig-scan для T::New.
