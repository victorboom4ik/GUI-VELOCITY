# Hook C — CORRECTED — capture, not injection

**Version 2** (based on workflow #2 findings, 23 agents / 1.33M tokens).

## The correction

My first pass at `HOOK_C_DEEP_DIVE.md` claimed Hook C **mutates** the
outgoing `CBaseUserCmdPB`. That was wrong. The disassembly proves it:

* `sub_7FFBE80FA2E4` is **`MergeFrom(dst=scratch, src=this)`**, not
  `CopyFrom(dst=this, src=scratch)`.
* Direct evidence: `CHECK failed: (&from) != (_this)` string at
  `usercmd.pb.cpp:1891` — this is the standard Google-protobuf assert
  inside `MergeFrom` that refuses self-merge.
* Direction of copy is **`this → scratch`**, never `scratch → this`.
* The original serializer runs on **the unmodified `this`** and puts
  those bytes on the wire.

So Hook C is a **capture-only hook**. Every tick it snapshots the
outgoing `CBaseUserCmdPB` into the FVA-owned scratch buffer
`unk_7FFBE8234C90` for another part of FVA to consume; the packet
itself goes out untouched.

## Where the mutation actually happens

**Hook A** (`sub_7FFBE80C9D8C` on `sub_180ACEF90`).

Hook A intercepts a CS2 function on the CreateMove path
(`WriteUsercmd`-side, per verifier). The handler:

1. lets the original run so the base `CBaseUserCmdPB` is built,
2. **iterates the repeated `subtick_moves` array** at
   `[cmd+0x30]` / `[cmd+0x38]` (RepeatedPtrField layout),
3. resolves the current tick_count from `[sub+0x60]`,
4. calls `sub_7FFBE8103A70` which **overwrites the outgoing viewangles
   field** (fake-angle / anti-aim injector).

So the timeline is:

```
CS2                                                                       FVA
 │                                                                          │
 │ CreateMove (sub_180C621D0) builds base CBaseUserCmdPB                    │
 │  + input_history append (sub_180C59D80 = PopulateInputHistoryEntry)     │
 │                                                                          │
 │ ↓                                                                        │
 │ Hook A returns from original, then MUTATES viewangles / subtick_moves ← │
 │                                                                          │
 │ Caller sub_180C4D050 calls SerializeToArray → sub_181189930              │
 │ ↓                                                                        │
 │ Hook C snapshots the (already-mutated) message into scratch ─────────→ │
 │ ↓                                                                        │
 │ Original sub_181189930 writes bytes to the NetChannel buffer            │
 │                                                                          │
 │ Bytes go out.                                                            │
```

## What the scratch buffer is for

The scratch mirror at `unk_7FFBE8234C90` is a **passive log** of the
last outgoing usercmd. Two known consumers:

* **`sub_7FFBE80C989C`** — reads scratch, calls
  `ByteSizeLong`+`SerializePartialToArray`, produces an
  `std::string` of the last serialised usercmd. Callers of this
  function are **UNVERIFIED** in the current pass but must exist —
  candidates are:
   * a background thread that snapshots demos for post-hoc review,
   * the AntiTamper watchdog verifying its own hooks didn't break
     Valve's serialisation,
   * the rage-bot post-mortem logger.
* **Any FVA code that wants "last known outgoing input"** to build a
  future backtrack payload.

## What this means for the reconstruction

Update the reconstruction like this:

### `serialize_to_array_hook.cpp` — capture-only

```cpp
char __fastcall hook_body(void* self, void* stream, int max_size)
{
    // 1. Passthrough always — do NOT mutate `self`.
    if (get_typename_hash(self) == k_target_hash &&
        self != &g_scratch)
    {
        // 2. Snapshot into scratch.  Direction is exactly `self → g_scratch`.
        //    We use the game's own MergeFrom (vtable slot for it exists).
        clear_message(&g_scratch);
        merge_from(&g_scratch, self);      // vtable[+X] on CBaseUserCmdPB
        capture_buffer::publish(&g_scratch); // wake any consumers
    }
    // 3. Original runs on unmodified `self`.
    return g_original(self, stream, max_size);
}
```

### `create_move_hook.cpp` — this is where mutation lives

```cpp
void __fastcall detour(void* self, int cmd_num, bool active)
{
    // 1. Let CS2 build the base cmd (viewangles from input, subtick_moves
    //    from ForceSubtickMove, input_history from PopulateInputHistoryEntry).
    g_original(self, cmd_num, active);

    // 2. Post-original — mutate the built cmd.
    auto* cmd = reinterpret_cast<CBaseUserCmdPB*>(
        get_current_usercmd_slot(self, cmd_num));
    if (!cmd) return;

    // 3. Apply the pending rage/movement policy.
    ScheduledMutation m = fetch_pending();
    if (m.apply_viewangles && cmd->viewangles) {
        cmd->viewangles->pitch = m.pitch;
        cmd->viewangles->yaw   = m.yaw;
        cmd->has_bits |= CBASEUSERCMDPB_BITS_VIEWANGLES;
    }
    if (m.apply_buttons && cmd->buttons_pb) {
        cmd->buttons_pb->buttonstate1 |= m.buttons1_or_mask;
        cmd->has_bits |= CBASEUSERCMDPB_BITS_BUTTONS_PB;
    }
    // Subtick moves: for each entry the rage-bot wants to force
    //   pitch_delta / yaw_delta at a specific `when`, replace them here.
    apply_subtick_deltas_to(cmd, m);

    // 4. Also spoof input_history[attack1_start_history_index] so that
    //    target_*_check_ correlates with the mutated aim.
    if (m.spoof_input_history) {
        auto* csgo_cmd = reinterpret_cast<CSGOUserCmdPB*>(
            get_current_csgo_cmd_slot(self, cmd_num));
        spoof::inject_spoofed_history(csgo_cmd, m.pitch, m.yaw,
                                        build_spoof_fields(m));
    }
}
```

## Sources verified in workflow #2

* **Actual serializer path**: caller `sub_180C4D050` (not `sub_180C621D0`)
  drives the SerializeToArray → `sub_181189930` → Hook C chain.
  See workflow #2 agent `callers-of-181189930`.
* **CreateNewSubtickMoveStep entry**: `sub_180C3E430` (not the lower-level
  `sub_1804B21E0/22D0/5E2C60` which are just internal accessors).
  See workflow #2 agent `createmove-full`.
* **input_history container**: `CFixedSizeCircularBuffer<
   CSGOInputHistoryEntryPB, 32, int>`, vtable
   `??_7?$CFixedSizeCircularBuffer@VCSGOInputHistoryEntryPB@@$0CA@H@@6B@`
   at `0x181A65200`. 32 slots × 120 bytes at owner+896..+4736.
  See workflow #2 agent `input-history-flow`.
* **CBaseUserCmdPB vtable**: `??_7CBaseUserCmdPB@@6B@` at
  `0x181995748`.
* **CSGOInputHistoryEntryPB vtable**: `0x181A1E028`.
* **`sub_7FFBE80FA2E4` = `MergeFrom`** (confirmed by CHECK strings from
  `usercmd.pb.cpp:1891` — "`CHECK failed: (&from) != (_this)`").

## Fields on CBaseUserCmdPB confirmed against Steam GameTracking

Verified against `SteamDatabase/GameTracking-CS2/Protobufs/usercmd.proto`
(tag numbers **CONFIRMED**):

| Tag | Field | Type |
|----:|-------|------|
| 1 | legacy_command_number | int32 |
| 2 | client_tick | int32 |
| 3 | buttons_pb | CInButtonStatePB |
| 4 | viewangles | CMsgQAngle |
| 5 | forwardmove | float |
| 6 | leftmove | float |
| 7 | upmove | float |
| 8 | impulse | int32 |
| 9 | weaponselect | int32 |
| 10 | random_seed | int32 |
| 11 | mousedx | int32 |
| 12 | mousedy | int32 |
| 14 | pawn_entity_handle | uint32 (default 0xFFFFFF) |
| 17 | prediction_offset_ticks_x256 | uint32 |
| 18 | subtick_moves | repeated CSubtickMoveStep |
| 19 | move_crc | bytes |

## Fields on CSGOInputHistoryEntryPB with tag numbers

(**UNVERIFIED tag numbers** — community-reconstructed, but layout matches
what workflow #2 agent decoded from `CSGOInputHistoryEntryPB::Clear`.)

| Tag | Field | Type | Purpose |
|----:|-------|------|---------|
| 2 | view_angles | CMsgQAngle | pitch/yaw at this subtick sample |
| 4 | render_tick_count | int32 | client render ticks elapsed |
| 5 | render_tick_fraction | float | fraction inside current render tick |
| 6 | player_tick_count | int32 | client-side player tick |
| 7 | player_tick_fraction | float | fraction inside player tick |
| 8 | cl_interp | CSGOInterpolationInfoPB_CL | client interp offset |
| 9 | sv_interp0 | CSGOInterpolationInfoPB | server interp lag frame 0 |
| 10 | sv_interp1 | CSGOInterpolationInfoPB | server interp lag frame 1 |
| 11 | player_interp | CSGOInterpolationInfoPB | local player interp |
| 13 | target_ent_index | int32 | which entity we aimed at (or -1) |
| 14 | shoot_position | CMsgVector | world-position we shot from |
| **15** | **target_head_pos_check** | CMsgVector | **client's opinion of target head world-pos** |
| **16** | **target_abs_pos_check** | CMsgVector | **client's abs-pos of target** |
| **17** | **target_abs_ang_check** | CMsgQAngle | **client's abs-angles of target** |

## Adversarial-honest notes

Everything the workflow could not directly disassemble is tagged
**UNVERIFIED** or **GUESS**:

* The exact caller path of `sub_7FFBE80C989C` (the scratch reader) is
  not yet mapped — verifying which FVA subsystem drinks the captured
  usercmd stream is the next investigation.
* The Hook A viewangle mutation was found by verifier but the exact
  offsets it writes to (`[cmd+0x30]`/`[cmd+0x38]` in the internal
  layout) are the same slots we already documented in
  `cbaseusercmdpb_layout.h`, so the reconstruction is directionally
  correct.
* The backtrack-attack payload flow (§7 of `wf2_synth_output.md`) is
  a **plausible model**, not a byte-verified path.

## Verification against `C:\vmp\FuckVacAgain.dll` runtime

For runtime 1:1 sanity, run these three checks after loading FVA into
cs2:

```
# 1. Hook A byte check — should be E9 rel32
db 0x7FFB6609EF90 8       # expect: E9 XX XX XX XX + junk

# 2. Hook C byte check — should be E9 rel32
db 0x7FFB66759930 8       # expect: E9 XX XX XX XX + junk

# 3. Scratch buffer sanity — after a live match tick, the memory at
#    (FVA_base + 0x184C90) should hold a valid CBaseUserCmdPB pointer,
#    i.e. first qword = client.dll+CBaseUserCmdPB vtable = 0x181995748
#    (image-based, +client.dll_base = 0x7FFB6..).
dq 0x7FFBE8234C90 1
```
