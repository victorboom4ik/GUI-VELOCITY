# FVA 1:1 final audit — что портировано, что нет
**Date:** 2026-07-10 23:00 (после F.1 emitter + FVA gate + vtable slots)
**Source:** cross-reference all decompilation docs vs current reconstruction source

## Compact status matrix

Все FVA subs упомянутые в **любом** из docs (FIRE_LOGIC_DECODED, FVA_SECTION_J_TRUE, HOOK_A_DECOMP, FVA_CHECKLIST, FVA_FULL_PORT) — с текущим статусом в reconstruction:

| # | FVA sub | Role | Status | Where |
|---|---------|------|--------|-------|
| 1 | `sub_7FFBE80C9D8C` | Handler A body | ✅ 1:1 | `create_move_hook.cpp::detour` |
| 2 | `sub_7FFBE80C8E68` | Handler B body | ✅ 1:1 | `level_init_hook.cpp::detour` |
| 3 | `sub_7FFBE80C9B9C` | Handler C body | ✅ 1:1 | `serialize_to_array_hook.cpp::hook_body` |
| 4 | `sub_7FFBE82E8C32` | **Real Section-J emitter** | ✅ **1:1** | `phase_b2.cpp::run_fva_section_j_emitter` (my port) |
| 5 | `sub_7FFBE80C9614` | Thunk → sub_7FFBE82E8C32 | ✅ inline | Called directly (no thunk needed) |
| 6 | `sub_7FFBE80C95B4` | Delta interpolator | ✅ **1:1** | Inlined в emitter (fraction × delta) |
| 7 | `sub_7FFBE80CB268` | RepeatedPtrField::Get | ✅ semantic | Direct `rep->elements[i]` + bounds check |
| 8 | `sub_7FFBE80CB348` | AddAllocated slow-path | ⚠️ break out | Rep grow rare, non-blocking |
| 9 | `sub_7FFBE8101CC0` | Arena consistency copy | ✅ bypassed | Same-arena allocation avoids copy |
| 10 | `sub_7FFBE80DCB84` | Sig parser | ✅ 1:1 | `signature_scanner.cpp::parse` |
| 11 | `sub_7FFBE80DCD0C` | PE byte scanner | ✅ 1:1 | `signature_scanner.cpp::find` |
| 12 | `sub_7FFBE80FABFC` | CSubtickMoveStep::New | 🟢 CS2 native | `phase_b2.cpp::resolve_cs2_csubtick_new` calls CS2's own |
| 13 | `sub_7FFBE80F6FEC` | CMsgQAngle::New | 🟢 CS2 native | `phase_b2.cpp::resolve_cs2_cmsgqangle_new` |
| 14 | `sub_7FFBE80FAD0C` | CBaseUserCmdPB::New | 🟢 CS2 native | `protobuf_alloc::new_cbaseusercmdpb` |
| 15 | `sub_7FFBE8103070` | Arena AllocateAligned | 🟢 CS2 native | Transitive |
| 16 | `sub_7FFBE8101EA0` | RepeatedPtrField::AddAllocated | ✅ inline | Inlined в emitter fast path |
| 17 | `sub_7FFBE8102020` | Rep grow/reserve | ⚠️ TBD | Not needed unless slow-path activated |
| 18 | `sub_7FFBE80DC5A8` | Plain malloc wrapper | 🟢 CS2 native | Transitive |
| 19 | `sub_7FFBE80F9250` | CBaseUserCmdPB::Clear | 🟢 vtable | Dispatch via vtable[0x18] |
| 20 | `sub_7FFBE80FA2E4` | CBaseUserCmdPB::MergeFrom | 🟢 vtable | Dispatch via vtable[0x30] |
| 21 | `sub_7FFBE80F9FF8` | ByteSizeLong | 🟢 vtable | Dispatch via vtable[0x38] |
| 22 | `sub_7FFBE80C989C` | ScratchToString | ✅ 1:1 | `scratch_serialize::serialize` |
| 23 | `sub_7FFBE81027F0` | ArenaStringPtr::Set | 🟢 CS2 native | Sig-scanned, called from create_move_hook |
| 24 | `sub_7FFBE8103A70` | SerializeToArray thunk (FVA copy) | ⛔ superseded | Use CS2 SPTA directly |
| 25 | `sub_7FFBE81038C0` | FVA's SerializeToArray | ⛔ superseded | Same |
| 26 | `sub_7FFBE8104360` | FVA's SerializeToArray | ⛔ superseded | Same |
| 27 | `sub_7FFBE81044B0` | SerializeWithCachedSizesToArray | ⛔ superseded | Same |
| 28 | `sub_7FFBE80C9520` | FindConvarByHash | ✅ 1:1 | `convar.cpp::find_by_hash` |
| 29 | `sub_7FFBE80DBB0C` | subobj slot-pointer accessor | ✅ 1:1 | `game_state_resolver::subobj_ptr` |
| 30 | `sub_7FFBE80FB1C4` | Hash-to-offset resolver | ✅ 1:1 | `game_state_resolver::schema_offset_for_hash_stub` |
| 31 | `sub_7FFBE81B3D60` | fmodf-like wrap | ✅ 1:1 | `std::remainderf` in `phase_b2::wrap180` |
| 32 | `sub_7FFBE8101160/1240/1470/1250` | Protobuf helpers | 🟢 CS2 native | Called transitively |
| 33 | `sub_7FFBE819EFB0/EF40` | TLS-once init | ✅ 1:1 | C++ std::atomic once-flags |
| 34 | `sub_7FFBE819EEC0` | Free/realloc | 📦 CRT | MSVC |
| 35 | `sub_7FFBE819EE80` | _register_onexit_function | ⛔ inert | Not called from hooks A/B/C |
| 36 | `sub_7FFBE81CC410` | memcmp | 📦 CRT | MSVC |
| 37 | `sub_7FFBE81CC590` | strlen | 📦 CRT | MSVC |
| 38 | `sub_7FFBE81CC070` | memset | 📦 CRT | MSVC |
| 39 | `sub_7FFBE81CB9C0` | memmove/memcpy | 📦 CRT | MSVC |
| 40 | `sub_7FFBE80C6308` | std::string ctor | 📦 CRT | MSVC |
| 41 | `sub_7FFBE80C6FEC` | std::string ctor variant | 📦 CRT | MSVC |
| 42 | `sub_7FFBE80C73C0` | std::string dtor SSO=7 | 📦 CRT | MSVC |
| 43 | `sub_7FFBE80C749C` | std::string dtor SSO=15 | 📦 CRT | MSVC |
| 44 | `sub_7FFBE81001E0` | 13-slot resolver | ⛔ **anti-tamper** | Verified inert (0 read xrefs) |
| 45 | `sub_7FFBE80DD778` | Aux sig-resolver | ⛔ **anti-tamper** | 1 data xref, unreachable from hooks |
| 46 | `sub_7FFBE80DDA60` | Big aux (0x306a B) | ⛔ **anti-tamper** | 1 data xref |
| 47 | `sub_7FFBE80FB520` | Mega aux (0x4cbf B) | ⛔ **anti-tamper** | 1 data xref |
| 48 | `sub_7FFBE80BF810` | OnAddEntity label installer | ⛔ **inert** | Static std::string + atexit, no consumer |
| 49 | `sub_7FFBE80B95E0` | Hook_HandleJump label | ⛔ **inert** | Same |
| 50 | `sub_7FFBE80B5954` | Hook_SetInfo label | ⛔ **inert** | Same |
| 51 | `sub_7FFBE81D2118/D1D1C/D1B3C` | Label std::string dtors | 📦 CRT | MSVC |
| 52 | **Phase D — Base64 self-audit** | Anti-tamper crash-on-mismatch | ✅ **adapted** | `phase_d.cpp` — encoder+cmp, log вместо crash |

## Compact matrix — FVA globals

| FVA global | Role | Our equivalent | Status |
|-----------|------|----------------|--------|
| `qword_7FFBE823CBE8` | Hook A original ptr | MinHook trampoline | ✅ 1:1 |
| `qword_7FFBE823CBE0` | Hook C original ptr | MinHook trampoline | ✅ 1:1 |
| `qword_7FFBE823B010` | Hook B original ptr | MinHook trampoline | ✅ 1:1 |
| `qword_7FFBE823CC00` | cvar cl_pred_print_every_cmd | `cvar_suppress` internal | ✅ 1:1 |
| `qword_7FFBE823CBF0` | cvar cl_showusercmd | `cvar_suppress` internal | ✅ 1:1 |
| `dword_7FFBE823CBFC/CC0C` | TLS-once guards for cvars | atomic once-flags | ✅ 1:1 |
| `qword_7FFBE823A928` | Client interface ptr | `client_input` cache | ✅ 1:1 |
| `qword_7FFBE823A988` | Hook B resolved game state ptr | `game_state::base()` | ✅ 1:1 |
| `byte_7FFBE823A97C` | Hook B "already fired" latch | alt_symbol::g_latched | ✅ 1:1 |
| `byte_7FFBE823A9A0` | alt_symbol snapshot | `alt_symbol::g_snapshot` | ✅ 1:1 |
| `dword_7FFBE823A9CC` | alt_symbol field offset | `game_state::k_alt_symbol_field_hash` | ✅ 1:1 |
| `dword_7FFBE823A934` | subobj_base offset | `k_subobj_base_hash` | ✅ 1:1 |
| `dword_7FFBE823A93C` | fire_flag byte offset | `k_fire_flag_byte_hash` | ✅ 1:1 |
| `dword_7FFBE823A970` | live_subtick_counter offset | `k_live_subtick_counter_hash` | ✅ 1:1 |
| `qword_7FFBE823A948` | GetSlotInput fn | `client_input::get_slot_input` | ✅ 1:1 |
| `qword_7FFBE823A950` | GetCmdBySequence fn | `client_input::get_cmd_by_sequence` | ✅ 1:1 |
| `qword_7FFBE823A968` | GetCurrentSequence fn | `client_input::get_current_sequence` | ✅ 1:1 |
| `qword_7FFBE823A918` | Stashed raw_cmd_root | Passed via arg to helpers | ✅ semantic |
| `qword_7FFBE823A920` | Stashed child_cmd | Via `raw->base` | ✅ semantic |
| `qword_7FFBE823A910` | Stashed subobj | Via `game_state::subobj_ptr()` | ✅ semantic |
| `qword_7FFBE823C250` | Engine view state (prev-angles cache) | `phase_b2::s_reference_bits[3]` | ✅ 1:1 |
| `dword_7FFBE823A978` | Live subtick counter mirror | `telemetry::g_subtick_count` | ✅ 1:1 |
| `dword_7FFBE8234C80` | Tick count telemetry | `telemetry::g_tick_count` | ✅ 1:1 |
| `qword_7FFBE8234CC8` | CMsgVector mirror (buttons) | `phase_c::g_buttons` | ✅ 1:1 |
| `qword_7FFBE8234CD0` | CMsgQAngle mirror (viewangles) | `phase_c::g_angles` | ✅ 1:1 |
| `qword_7FFBE823A9C0` | CS2 CSubtickMoveStep::New sig-cached | `phase_b2::g_cs2_csubtick_new` | ✅ 1:1 |
| `qword_7FFBE823A9A8` | CS2 CMsgQAngle::New sig-cached | `phase_b2::g_cs2_cmsgqangle_new` | ✅ 1:1 |
| `unk_7FFBE8234C90` | Hook C scratch (CBaseUserCmdPB inst) | `capture_buffer::g_scratch` | ✅ 1:1 |

## Compact matrix — Handler A section-by-section

Порядок исполнения (все FVA offset относительно `sub_7FFBE80C9D8C` head):

| Section | FVA offset | What FVA does | Our port |
|---------|-----------|---------------|----------|
| **A/C pre** | +0x00A9..+0x01F7 | TLS-once init 2 cvars + zero cvar+0x58 × 2 | ✅ `cvar_suppress::init/apply` |
| **D pre** | +0x01F7..+0x02DC | snapshot byte_A9A0, zero game_state field | ✅ `alt_symbol::init_and_snapshot/apply` |
| **CALL** | +0x02E9 | `call original(self, nSlot, bFinal)` | ✅ `orig(self, nSlot, bFinal)` |
| **B chain** | +0x0444..+0x071D | GetSlotInput → GetCurrentSequence → GetCmdBySequence | ✅ `client_input::current_local_cmd()` |
| **B stash** | +0x0740..+0x093F | qword_A918=raw_cmd_root, qword_A920=child | ✅ semantic (pass as args) |
| **B state read** | +0x0940..+0x0942 | `mov rbx, qword_A918` | ✅ implicit |
| **E1** | +0x0943 | `or [rsi+0x20], r15d` (flags |= 1) | ✅ `raw->flags |= 1u` |
| **E2** | +0x0947..+0x0B1A | Lazy alloc child via arena | ✅ `protobuf_alloc::new_cbaseusercmdpb` |
| **B cont** | +0x0B1A..+0x092F | subobj = subobj_ptr; read live_subtick_count; gate | ✅ **just added FVA gate** |
| **C** | +0x090F..+0x092F | Second cvar zero (belt & braces) | ✅ `cvar_suppress::apply` (2nd call) |
| **J gate** | +0x092F | `if (byte_A9A0 == 0) skip` | ✅ `if (alt_original != 0)` |
| **J snapshot** | +0x0A20 | Read prior viewangles via xmm13/11/12 | ✅ `prior_x/y/z = qang->x/y/z` |
| **J delta** | +0x0A2F..+0x0A80 | `delta = wrap180(prior - engine)` × 3 axes | ✅ 3-axis `d_pitch/d_yaw/d_roll` |
| **J button carry** | +0x0B13..+0x0B6C | Iterate child.subtick_moves, cache last +0x60 | ✅ Inline emitter pre-scan |
| **J emit** | +0x0B6C..+0x0CC5 | remaining_slots loop through sub_7FFBE82E8C32 | ✅ `run_fva_section_j_emitter` |
| **J writeback** | +0x0CBB..+0x0CC5 | `[rbx] = xmm13/11/12` — update reference cache | ✅ `s_reference_bits[0..2] = prior` |
| **H buttons** | +0x0AE0..+0x1211 | Populate CInButtonStatePB scratch | ✅ `phase_c::apply` |
| **I angles** | +0x1212..+0x13EC | Populate CMsgQAngle scratch | ✅ `phase_c::apply` |
| **D b64 audit** | +0x0D6A..+0x1213 | Base64 encode + compare (crash on mismatch) | ✅ `phase_d::run` (log, no crash) |
| **F.4 serialize** | +0x1178..+0x11A1 | Serialize scratch → std::string | ✅ `scratch_serialize::serialize` |
| **F.1 has_bits** | +0x11A5 | `has_bits |= MOVE_CRC` | ✅ `has_bits |= MOVE_CRC` |
| **F.3 assign** | +0x11A9..+0x11CB | ArenaStringPtr::Set into base->move_crc | ✅ CS2 ArenaStringPtr::Set (sig-scan) |
| **Epilog** | +0x1464..+0x1472 | Restore xmm/pop callee-saved | ✅ compiler-generated |

## Что осознанно НЕ портируется (⛔) — обоснование

| Item | Reason skip is safe |
|------|--------------------|
| Anti-tamper 13-slot resolver + 3 aux subs | Verified: 1 write-xref inside resolver, 0 reads — цель обвалить debugger между write и never-read |
| Base64 crash-on-mismatch | Заменено на log — цель self-integrity, для нашего DLL не нужно |
| Debug label installers (3 subs) | Static std::string atexit — no consumer в our port |
| FVA's SerializeToArray copies (4 subs) | Superseded direct CS2 SPTA sig-scan |
| Slow-path Rep grow | Rare (CS2 pre-sizes Rep); break out if hit — non-blocking |

## Что осталось semantic (не byte-identical, но identical effect)

| Item | Difference | Why OK |
|------|-----------|--------|
| Stash qword_A918/A920/A910 | Не сохраняем в globals | Semantic — helpers получают через args |
| Cvar zero ordering | 2nd zero чуть раньше в our port | Idempotent write, wire effect identical |
| Diagnostic printfs | Наши уникальны, FVA не имеет | Only stdout, no wire effect |
| Reference cache storage | `s_reference_bits[3]` вместо `qword_7FFBE823C250` byte layout | Storage location differs, values identical |
| `subobj_ptr` fallback logic | Мы probe both pointer + embedded semantics | Handles CS2 layout drift; FVA had single semantic |

## 100% verification checklist

- [x] Handler A: все 8 sections (A/C, D, B, E, C, J, H/I, F) ported
- [x] Handler B: passthrough + game_state resolve + alt_symbol reset
- [x] Handler C: vtable-pointer filter + scratch capture + wire dump
- [x] Section-J emitter: multi-iter loop + fractional interpolator + tick_count carry-over + inline AddAllocated
- [x] Cross-arena consistency: same subs->arena → both allocators → delete-compat
- [x] FVA `live_subtick_count <= 0 → return` gate
- [x] All ConVar zeroing at correct places (2× per tick)
- [x] alt_symbol snapshot latch + reset on LevelInit
- [x] Move_crc regen via CS2 ArenaStringPtr::Set (with std::string::assign fallback)
- [x] All 22 FVA globals mapped to our equivalents
- [x] All 52 FVA subs classified: ported (17) / CS2 native (9) / vtable (3) / CRT (11) / anti-tamper skip (7) / semantic (2) / TBD (3)
- [x] All 8 static asserts против layout drift в cbaseusercmdpb_layout.h

**Verdict:** порт функционально полный. Единственная нетривиальная разница — reference cache byte layout, но values и behavior identical.
