# FVA Mass Decompile Status — 2026-07-10

Systematic Hex-Rays extraction of 31 FVA functions from
`C:\vmp\fva_livedump\FuckVacAgain_rebuild.exe.i64` (IDA MCP session `fvar`)
and cross-audit against our reconstruction at
`C:\vmp\implementation_theory\reconstruction\src\`.

Pseudocode saved under `reconstruction/fva_decomp/decompiled/0x<VA>.c` (31/31).

Legend:
- ✅ decomp clean, port matches semantically
- 🟢 we route to CS2 native (via vtable / sig-scan) — no port needed
- ⚠️ subtle divergence — see notes
- ⛔ VMP residue / decomp failed

---

## (a) Protobuf helpers

| VA | Symbol | Status | Notes |
| --- | --- | --- | --- |
| 0x7FFBE80F9250 | `CBaseUserCmdPB::Clear` | 🟢 | We call CS2 native via vtable slot from `try_cache_vtables()` in `phase_b2.cpp`. No port. FVA's version references `SafetyPlugin-Unprotected\src\valve\protobufs\usercmd.pb.cpp:1365/1369/1373` and a 4-slot hasbits (buttons_pb, viewangles, execution_notes, subtick_moves). |
| 0x7FFBE80FA2E4 | `CBaseUserCmdPB::MergeFrom` | 🟢 | Same — never invoked from our hooks. Field-map (0x10..0x80 scalars, 0x100..0x8000 second bank, 0x10000/0x20000 for pawn_entity_handle default 0xFFFFFF) confirms `cbaseusercmdpb_layout.h` offsets. |
| 0x7FFBE80F9FF8 | `CBaseUserCmdPB::ByteSizeLong` | 🟢 | We call it via vtable slot +56 in `scratch_serialize.cpp:115` and via SerializeToArray hook. |
| 0x7FFBE80FAD0C | `NewMaybeArena<CBaseUserCmdPB>` (size **136**, pawn_entity_handle default **0xFFFFFF**) | ✅ | `protobuf_alloc.cpp::new_cbaseusercmdpb` (uses 20-byte prologue sig-scan). Size 136 and 0xFFFFFF default confirmed. |
| 0x7FFBE80FABFC | `NewInArena<CSubtickMoveStep>` (size 56) | ✅ | `alloc_and_init_step` in `phase_b2.cpp` uses cached CS2 vtable + arena AllocateAligned. |
| 0x7FFBE80F6FEC | `NewInArena<CMsgQAngle>` (size 40) | ✅ | `resolve_cs2_cmsgqangle_new()` in `phase_b2.cpp:950`. |
| 0x7FFBE80E3E64 | `NewInArena<CSGOInputHistoryEntryPB>` (size **120**) | ⚠️ | Byte offset 116 = `pawn_entity_handle` default **-1** (=0xFFFFFFFF). Cross-check with `MEMORY[cs2-t-new-rva-hardcoded.md]`: memory says "byte 4 = 0x10 не 0x08" — refers to FVA's `New` prologue *fingerprint byte*, not the field default. Field layout matches. **Verify `protobuf_alloc.cpp` uses hardcoded RVA + fingerprint check per memory note.** |
| 0x7FFBE80CB268 | `RepeatedPtrField::Get` | ✅ | Inlined at every subtick access; guarded via `current_size_` in `phase_b2.cpp`. |
| 0x7FFBE8101EA0 | `RepeatedPtrField::AddAllocated` | ✅ | Directly matched in `phase_b2.cpp::alloc_and_init_step` (Reserve-then-write pattern). |
| 0x7FFBE8102020 | `Rep grow/reserve` (TLS size-class free-list) | ⚠️ | Grow formula `max(2*total+1, cur+n)` and 0x7FFFFFFF cap ports fine. **TLS size-class recycler** (`NtCurrentTeb + TlsIndex + [+64]/[+72]`) is NOT ported — we always take heap path via `sub_7FFBE80DC5A8`. Impact: minor extra allocator pressure; observable only under `Reserve` hammer. Not a correctness issue for our capture-and-replay path. |
| 0x7FFBE8102330 | `Rep Reserve` public entry | ✅ | Trivial delta-grow forwarder. Matched via `phase_b2.cpp`. |

## (b) Sig-scan & init

| VA | Symbol | Status | Notes |
| --- | --- | --- | --- |
| 0x7FFBE80DCB84 | Sig parser (IDA-style `48 89 ? ?`) | ⚠️ | Ported as `hex_nibble`+wildcard in `signature_scanner.cpp:17-53`. Threshold divergence: FVA uses **HeapAlloc when pattern>1024 bytes**, stack `alloca` under. Our port uses `std::vector` for both — allocator differs but pattern semantics identical. Also FVA writes sentinel `0xDDDD`/`0xCCCC` as dbg markers; we don't. |
| 0x7FFBE80DCD0C | PE byte scanner | ⚠️ | Compares `?` and byte-eq over `[base .. base + .text_size - patlen]`. Port matches. **On miss**: FVA hex-decodes the pattern and calls `sub_7FFBE80C486C` (ScratchToString error variant) — our port just returns `nullptr` and lets caller log via `logf.cpp`. Downstream identical (nullptr → phase_c fallback). |
| 0x7FFBE80DBB0C | subobj slot-pointer accessor | ⚠️ | Uses lazy-init cookies for **two** offsets: `dword_7FFBE823AA00` (obj-slot hash **0x4C7C6391100B2438**) and `dword_7FFBE823A9F8` (generation-bit hash **0x51CEE653EC562D63**). Our `game_state_resolver.cpp` currently implements only the first probe (see `hash_to_offset` walker at lines 134-140). **Generation bit gating (`v6 & 0x7FFF | ((v7 - gen_bit) << 15)`) is missing** — matters if CS2 recycles interface handles mid-frame. Add follow-up. |
| 0x7FFBE80FB1C4 | Hash-to-offset resolver (linear scan of `[qword_7FFBE823A8D8 .. qword_7FFBE823A8E0]` 16-byte pairs) | ✅ | Matched. `game_state_resolver.cpp:139-140` uses same FNV-1a constants `0xCBF29CE484222325` / `0x100000001B3`. |
| 0x7FFBE80FAEF0 | Schema populator per `FIRE_LOGIC_DECODED` | ⚠️ | Walks `root + 1472`, `+7616`, feeds `(hash, u32 offset)` pairs into `qword_7FFBE823A8E0` — the table that (b)'s resolver consumes. **We don't populate this table ourselves** — we rely on FVA-injected copy at runtime. If we ever run without FVA present, `find_by_hash` returns 0 for all queries. Documented risk. |
| 0x7FFBE80C9614 | Section-J thunk | ✅ | Trivial 5-arg passthrough to `sub_7FFBE82E8C32`. Section-J emitter port in `phase_b2.cpp` calls the target directly — thunk not preserved (irrelevant). |

## (c) Arena management

| VA | Symbol | Status | Notes |
| --- | --- | --- | --- |
| 0x7FFBE8103070 | `Arena::AllocateAligned` thunk | ✅ | Simple forwarder to `sub_7FFBE81029A0`. We wrap CS2's real Arena via the `sub-message->New(arena)` pattern; no direct port. |
| 0x7FFBE81027F0 | `ArenaStringPtr::Set` | ⚠️ | 3-way branch (owned-in-place / arena-alloc-32B / heap-alloc-32B) with tag bits `[& 3]`. Our `phase_b2.cpp` only ever hits the owned-in-place branch (command_number preset by CS2). Untested: arena and heap paths under our synthetic new-cmd generation. Low risk (we never Set command_number ourselves). |
| 0x7FFBE8102B40 | Arena deferred delete registration | ⚠️ | Reads TLS `ThreadLocalStoragePointer[TlsIndex]` for per-thread chunk cache — same pattern as (a) Reserve. Not ported (we don't register deferred deletes). Only reachable via `ArenaStringPtr::Set` arena path. |
| 0x7FFBE80CB440 | arena copy step helper | ✅ | 2-arg swap thunk to `sub_7FFBE80E2E48`. Not called from our hooks. |
| 0x7FFBE80CB450 | deferred delete callback | ✅ | `(**obj)(obj, 1)` — invokes vtable slot 0 (delete-with-dtor). Standard. |
| 0x7FFBE80E1E30 | `CSGOUserCmdPB::~` destructor helper | 🟢 | We never own a CSGOUserCmdPB — we merge into CS2's arena-owned instance. FVA has this because it constructs standalone PBs at test paths (cs_usercmd.pb.cpp:917 CHECK confirms). |
| 0x7FFBE8103A70 | SETTER via vtable | ✅ | Thunk to `sub_7FFBE81038C0`. Not on hot path we care about. |

## (d) FVA-internal (SerializeToArray / ScratchToString)

| VA | Symbol | Status | Notes |
| --- | --- | --- | --- |
| 0x7FFBE8104360 | `MessageLite::SerializeToArray` | ⚠️ | Path A (size ≤ 0x7FFFFFFF): calls `SerializeWithCachedSizesToArray` at `sub_7FFBE81044B0`. Path B (>2GB): logs `message_lite.cc:479 " exceeded maximum protobuf size of 2GB: "` via `sub_7FFBE8101160/470/250`. Our `serialize_to_array_hook.cpp:189` intercepts CS2's version by scanning `48 89 5C 24 18` — we do NOT re-implement the 2GB CHECK. Divergence irrelevant (CS2 messages never exceed 4KB). |
| 0x7FFBE80DCB84 | (sig parser, dup entry in list) | (see (b)) | |
| 0x7FFBE80C8DE8 | ScratchToString ERROR path | ⚠️ | Sets stdout attr via `GetStdHandle(-11)` + `SetConsoleTextAttribute(err_code)`, then dispatches through `off_7FFBE8233C00` and (if `qword_7FFBE8235998 != 0`) `off_7FFBE8235910`. Our `scratch_serialize.cpp` only handles success path — error logging goes through our own `logf.cpp`. Cosmetic divergence; not observable in captures. |

## (e) CRT helpers

| VA | Symbol | Status | Notes |
| --- | --- | --- | --- |
| 0x7FFBE80DC5A8 | Plain malloc wrapper (lazy vtable-based `msvcrt.malloc`) | 🟢 | We use CRT `malloc` / `new[]` directly. FVA's obfuscated GetProcAddress dance is anti-scanner window dressing. |
| 0x7FFBE819EFB0 | TLS-once-init begin (CRITICAL_SECTION + condvar) | 🟢 | Standard MSVCRT `_Init_thread_header` clone. We rely on C++11 `std::atomic` / `once_flag`. |
| 0x7FFBE819EF40 | TLS-once-init done | 🟢 | Same. |
| 0x7FFBE819EE80 | `_register_onexit_function` wrapper | 🟢 | We don't register atexit callbacks. |
| 0x7FFBE81B3D60 | `remainderf`-like (IEEE-754 float remainder) | ⚠️ | **NOT `fmodf`** — uses IEEE round-to-nearest quotient (matches CRT `remainderf`). If FVA-parity requires **fmodf** for angle wrap (as `phase_b2.cpp:989-998` claims for `wrap180`), the port at `wrap180` must use `std::fmod`, not `std::remainder`. **Verify `wrap180` uses fmodf semantics** (last-tick angle wrap 360 → -180..180 differs vs remainderf output at 180.001). Grep confirmed `phase_b2.cpp` documents fmodf(360), so port is correct; FVA also had a distinct `fmodf` at a different VA (this is not it). |

---

## Cross-cut findings

1. **`g_target_armed` (memory: fva-no-hotkey.md)** — still declared and used in `src/hooks/phase_b2.cpp:59/643/648/925/978`. Current logic falls through to a "reference-bits = 0" self-echo when unarmed, which **is** FVA-parity (FVA's `qword_7FFBE823C250` static struct is zero-initialized). ⚠️ The atomic itself is semantic dead-weight in FVA-parity mode — recommend either removing it or documenting it as an opt-in user-driven overlay. Not a correctness bug now that the fallback path was fixed to read zero-reference.

2. **TLS size-class recycler** (rec-c) — FVA's arena `Reserve` and deferred-delete paths thread through `NtCurrentTeb->ThreadLocalStoragePointer[TlsIndex]` to reach a per-thread ThreadLocalCache. Our port always takes the heap path. Impact: extra `malloc`/`free` traffic under hammer; no observable divergence in single-cmd merges.

3. **Generation-bit gate in `sub_7FFBE80DBB0C`** — resolver uses hash `0x51CEE653EC562D63` to fetch a "generation bit" and folds it into the slot index. `game_state_resolver.cpp` skips this. If CS2 recycles interface handles between the initial resolve and a later cmd, our stale index could dereference the wrong object. Add follow-up: mirror the second hash lookup.

4. **`FIRE_LOGIC_DECODED` schema table** — FVA populates `qword_7FFBE823A8E0` at DLL-init via `sub_7FFBE80FAEF0` (walks CS2's proto schema tree, FNV-1a-hashes each `"msg.field"` name, appends 16-byte {hash, u32 offset} entries). Our port depends on this table being populated by FVA runtime. Standalone (FVA-not-loaded) operation will produce zero from `find_by_hash`. Documented risk.

5. **CHECK-log side-channel** — every protobuf helper in (a)/(b) logs to `SafetyPlugin-Unprotected\...*.pb.cpp:LINE` via `sub_7FFBE8101160/470/250/240`. Our port silently returns on failure. Not observable in capture; captured PB bytes match either way.

## File index

31 files at `C:\vmp\implementation_theory\reconstruction\fva_decomp\decompiled\`:
```
0x7FFBE80C8DE8.c  0x7FFBE80C9614.c  0x7FFBE80CB268.c  0x7FFBE80CB440.c
0x7FFBE80CB450.c  0x7FFBE80DBB0C.c  0x7FFBE80DC5A8.c  0x7FFBE80DCB84.c
0x7FFBE80DCD0C.c  0x7FFBE80E1E30.c  0x7FFBE80E3E64.c  0x7FFBE80F6FEC.c
0x7FFBE80F9250.c  0x7FFBE80F9FF8.c  0x7FFBE80FA2E4.c  0x7FFBE80FABFC.c
0x7FFBE80FAD0C.c  0x7FFBE80FAEF0.c  0x7FFBE80FB1C4.c  0x7FFBE8101EA0.c
0x7FFBE8102020.c  0x7FFBE8102330.c  0x7FFBE81027F0.c  0x7FFBE8102B40.c
0x7FFBE8103070.c  0x7FFBE8103A70.c  0x7FFBE8104360.c  0x7FFBE819EE80.c
0x7FFBE819EF40.c  0x7FFBE819EFB0.c  0x7FFBE81B3D60.c
```
