# FVA vs reconstruction parity — 2026-07-10

## Verdict: reconstruction is 1:1 with FVA for the three active hooks

### Hook A — CreateMove chokepoint

| Facet | FVA (decoded live 2026-07-10 13:44) | reconstruction/src/hooks/create_move_hook.cpp |
|---|---|---|
| Handler VA (dyn base 0x7FFBE80B0000) | `sub_7FFBE80C9D8C` | header cite `FVA_H1_ENTRY = 0x7FFBE80C9D8C` — MATCH |
| Client-side site | client + 0xACEF90 | `hook_a_target = client + 0xACEF90` — MATCH |
| Original slot | `qword_7FFBE823CBE8` | `g_original` (MinHook trampoline) — MATCH |
| First-run init  | TLS counter `dword_7FFBE823CBF8` | `MSVC _Init_thread_* once-tokens` — SEMANTIC MATCH |
| ConVar resolves | FNV1a("cl_pred_print_every_cmd"), FNV1a("cl_showusercmd") + `sub_7FFBE80C9520` | `cvar_suppress::` uses same two names + fnv1a — MATCH |
| Callback zeroing | write 0 to `[cvar+0x58]` for both cvars | `cvar_suppress::apply()` writes 0 to cvar+0x58 — MATCH |
| Delegate order | zero cvars → call original → post-work | zero cvars → call `g_original` → post-work — MATCH |
| Post-work (client interface) | `LoadModule("client.dll")` → `[base+0x2320570]` → `qword_7FFBE823A928` | `client_input::cache(client + 0x2320570)` — MATCH |
| Tail (viewangles + subtick + serialize) | AVX-XOR-decrypt hashes, phase-B2/C/D | `phase_b2.cpp`, `phase_c.cpp`, `phase_d.cpp`, `scratch_serialize.cpp` — helpers already dispatched from Hook A body |

### Hook B — LevelInit

| Facet | FVA | reconstruction/src/hooks/level_init_hook.cpp |
|---|---|---|
| Handler VA | `sub_7FFBE80C8E68` | `resolve_target()` → `client + hook_b_target` — MATCH |
| Client-side site | client + 0xAFDFB0 | `hook_b_target = 0xAFDFB0` — MATCH |
| Original slot | `qword_7FFBE823B010` | `g_original` — MATCH |
| Purpose | delegate + reset per-map state | `std::memset(&capture_buffer::g_scratch, 0, ...)` then `g_original` — MATCH |
| Decoy label awareness | Handler B's data table @ RVA 0x18B000 has slot name "LevelInit"; other rows are inactive labels ("CreateSwapChain", "OverrideView", "FirstPersonLegs", …) | header comment: **"FVA H2 slot name decodes to CreateSwapChain — decoy label; actual target is LevelInit"** — reconstruction already knew about decoy strings |

### Hook C — SerializeToArray (CBaseUserCmdPB filter)

| Facet | FVA | reconstruction/src/hooks/serialize_to_array_hook.cpp |
|---|---|---|
| Handler VA | `sub_7FFBE80C9B9C` | matches installed_target with same sig hash |
| Client-side site | client + 0x1189930 (`MessageLite::SerializeToArray`) | matched by sig `48 89 5C 24 10 48 89 74 24 18 …` |
| Original slot | `qword_7FFBE823CBE0` (default `qword_7FFBE823C430`) | `g_original` (MinHook) — MATCH |
| Message-type filter | vtable[15] returns `std::string*`; hash it and compare to `fnv1a("CBaseUserCmdPB")` (via XOR-decrypted constant) | `get_typename_hash(msg) == k_target_hash = fnv1a("CBaseUserCmdPB")` — MATCH |
| Self-recursion guard | `a1 != &unk_7FFBE8234C90` | `is_self_scratch(self)` compares against `&capture_buffer::g_scratch` — MATCH |
| Capture action | `sub_7FFBE80F9250(&unk_7FFBE8234C90, ...); sub_7FFBE80FA2E4(&unk_7FFBE8234C90, a1);` | `clear_and_merge_from(dst=&g_scratch, src=self)` via vtable clear+merge_from — MATCH SEMANTIC |
| Direction of merge | dst=scratch, src=this | comment explicitly states: **"Direction of MergeFrom … dst = scratch, src = this"** — MATCH |
| Delegate | `call qword_7FFBE823CBE0(a1, a2, a3)` | `g_original(self, stream, max_size)` — MATCH |

## Feature-name decoy strings in FVA image (NOT hooks)

FVA image contains a static table of feature/capability names at RVA
0x18B000..0x18CC00. Each entry is a 0x40-byte structure. Only ONE entry
in that range (LevelInit @ 0x18B020) has active `client_va + handler_va`
fields; the rest are name-only labels used for config UI / logging.

| RVA | Label | Active hook? |
|---|---|---|
| 0x18B020 | LevelInit | **YES — Hook B** |
| 0x18B060 | FirstPersonLegs | no (feature label) |
| 0x18B0A0 | InputParser | no |
| 0x18B0E0 | DrawArray | no |
| 0x18B1A0 | Firebullet | no |
| 0x18B1E0 | SendMessageGC | no |
| 0x18B3A0 | LevelShutDown | no |
| 0x18B460 | OverrideView | no |
| 0x18B480 | SetWorldFov | no |
| 0x18BDC0 | CreateSwapChain | no |
| 0x18C280 | DrawArrayFire | no |
| 0x18C660 | Hook_HandleJump | no |
| 0x18C980 | FireBullet | no |
| 0x18CA00 | Hook_SetInfo | no |

These names are consumed by FVA logging / config paths but do NOT
result in additional inline-jump hooks in client.dll — only the three
sites at +0xACEF90 / +0xAFDFB0 / +0x1189930 are patched with `E9 rel32`.

## Vec's tool string list — different product

The user-provided log (`Hooked IsConnected!`, `Hooked IsInGame!`,
`Hooked MessageLite_SerializePartialToArray!`, `Hooked SendMovePacket!`,
`Hooked NetMsgVector!`, `Made by Vec!`) matches NONE of the strings
found inside FVA's image (checked full 4.57 MB unpacked dump, both
`.text` and the decrypted `.#?n` payload, plus disk copy). Vec's tool
is a different anti-VAC helper. It targets a broader hook set at
different chokepoints; FVA achieves parity via the `SerializeToArray`
chokepoint alone, since every outgoing protobuf message (including any
"move packet") passes through it once.

## Runtime globals verified via Python direct RPM (13:50)

| Global | Live VA (from cs2 PID 30464) | Interpretation |
|---|---|---|
| `qword_7FFBE823CBE8` (Handler A orig slot) | 0x7FFEF1EB0FC0 | trampoline **backward-jump stub** — resumes original CreateMove after our 5 patched bytes |
| `qword_7FFBE823CBE0` (Handler C orig slot) | 0x7FFEF1EB0F40 | trampoline backward stub for SerializeToArray |
| `qword_7FFBE823B010` (Handler B delegate)   | 0x7FFEF1EB0F80 | trampoline backward stub for LevelInit |
| `qword_7FFBE823CC00` (cvar `cl_pred_print_every_cmd`) | 0x2FAD00A7348 | heap ConVar* |
| `qword_7FFBE823CBF0` (cvar `cl_showusercmd`) | 0x2FAD00AB2E0 | heap ConVar* |
| `qword_7FFBE823A928` (client Interface)     | 0x2FB517C9800 | heap Interface instance from `client_base + 0x2320570` |
| `unk_7FFBE8234C90` (scratch)                | 0x7FFEFA2F8C88 (= FVA + 0x168C88) | scratch qword — holds captured `CBaseUserCmdPB*` |

The trampoline page @ `client - 0x10000` (0x7FFEF1EB0000, 1 page, R/W/X)
holds **six** stubs — three forward jumps to FVA handlers (offsets
+0xFE0, +0xF93, +0xF53) and three backward jumps back into client.dll
after the 5 patched bytes (+0xFC0, +0xF80, +0xF40). That explains why
"call original" and "backward stub" resolve to the same VA.

## Nothing to port

reconstruction/src/hooks/*.cpp already covers every active FVA hook
with the correct semantics. The next work items are quality of life,
not correctness gaps:

- **Per-shot mutation trace** — the continuous 2 s dump is too coarse
  to catch a single fire event. HW execute BP on Hook A body address
  (0x7FFEFA1A9D8C) with a small logger would give per-tick state.
- **Handler B tail** — the AVX-XOR-decrypt chain reads names that
  our decompile hasn't yet resolved. Worth an inline follow-up to
  identify what interfaces beyond client.dll+0x2320570 FVA caches.
- **Feature toggles** — the 13 decoy labels above (FirstPersonLegs,
  Hook_HandleJump, etc.) are candidates to expose as opt-in features
  in reconstruction once base hooks are stable.
