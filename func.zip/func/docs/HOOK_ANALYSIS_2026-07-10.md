# FuckVacAgain hook analysis — 2026-07-10 13:50

Complete hook / trampoline / handler decoding from today's live capture.

## Layout observed

All three CS2-side hooks are `E9 rel32` at:

| Hook | Client-side site | Trampoline VA | Handler RVA (FVA) |
|------|-------------------|---------------|-------------------|
| A    | client+0xACEF90   | 0x7FFEF1EB0FE0 | 0x19D8C          |
| B    | client+0xAFDFB0   | 0x7FFEF1EB0F93 | 0x18E68          |
| C    | client+0x1189930  | 0x7FFEF1EB0F53 | 0x19B9C          |

The trampoline sits in a single MEM_COMMIT PAGE_EXECUTE_READWRITE page at
`client-0x10000` (`0x7FFEF1EB0000`, 0x1000 bytes). Each trampoline is
`FF 25 00 00 00 00 <qword handler_va>` — six-byte indirect jump through
an inline qword pointer.

**IMPORTANT: Hook A's handler pointer is HOT-PATCHED by VMP after unpack.**
First read (13:25): pointer = `FVA+0x18C88` — that address is mid-instruction
inside `sub_7FFBE80C8C1C` (a `std::vector<uint32_t>` copy routine). Executing
there would trap on `1E` (invalid x86-64 opcode). Second read (13:44):
pointer = `FVA+0x19D8C` — a real function entry.  Hook B / Hook C
pointers were stable across the same window.  Interpretation: VMP writes
a placeholder or `.reloc`-decoy pointer at load time and replaces it with
the real handler only after the corresponding init path fires (probably
gated by cvar / TLS state elsewhere in FVA).

## Handler A @ FVA+0x19D8C — `CreateMove` hook

Client-side function: `double __fastcall CreateMove(__int64 a1, uint a2, __int64 a3)`.
Client-side signature: `48 8B C4 4C 89 40 ? 48 89 48 ? 55 53 41 54`
(matches `client.dll:createmove` in `cs2_signatures.json`).

Prologue is canonical MSVC / Windows-x64 for AVX-heavy code:
`mov rax, rsp; push rbp/rbx/rsi/rdi/r12-r15; sub rsp,0x228;
vmovaps [rax-0x58]..[rax-0xB8], xmm6..xmm13`.
Aligns `rbp` down to 32B for AVX use.

Semantics (in order of execution):

1. **First-run init of the original-fn slot** (`qword_7FFBE823CBE8`)
   guarded by TLS counter `dword_7FFBE823CBF8`:
   ```
   mov rax, cs:qword_7FFBE823AD10   ; original CreateMove pointer, captured
                                     ; at hook install time
   mov cs:qword_7FFBE823CBE8, rax
   ```
2. **Lazy resolve** two ConVars via FNV1a (seed `0xCBF29CE484222325`,
   prime `0x100000001B3`) + `sub_7FFBE80C9520(name_hash)`:
   - `"cl_pred_print_every_cmd"` → `qword_7FFBE823CC00`
   - `"cl_showusercmd"`          → `qword_7FFBE823CBF0`
3. **Zero out both ConVars' change-callback fields** (`[cvar+0x58] = 0`).
   That is the classic `Msg`/`Console printout` mute — client-side
   prediction and usercmd debug logs both go silent as soon as CreateMove
   is called for the first time.
4. **Delegate** to captured original:
   ```
   mov r8b, r14b ; a3
   mov edx, r15d ; a2
   mov rcx, r13  ; a1
   call cs:qword_7FFBE823CBE8
   ```
5. **Post-call analytics** — resolve `client.dll` via
   `qword_7FFBE81D30B8("client.dll")` (Ldr-based module locator), read a
   qword from client_base + 0x2320570 (interface pointer), and stash it
   at `qword_7FFBE823A928`.
6. AVX-XOR-decrypt more hash constants using the same key ring as Handler
   B / Handler C (`0x9393734737ACF8CD`, `0x9F0437429887A4CE`,
   `0x4C0504D7FEB6B1F`, `0x71C99B70746C6708`) — these decrypt into
   additional cvar / interface names; the rest of the function continues
   the FVA anti-VAC bookkeeping path.

Matches `reconstruction/src/hooks/create_move_hook.cpp` (22 KB) and
`reconstruction/src/features/cvar_suppress.cpp`.

## Handler B @ FVA+0x18E68 — lazy-resolver / dispatch stub

VMP pattern: on first call it decrypts 15+ hash constants via AVX XOR,
resolves 3 function pointers through `sub_7FFBE80DCB84(str_ptr, ...)`, and
caches them in globals `qword_7FFBE823A980 / A988 / A990`. Then delegates
to `qword_7FFBE823B010(a1, a2)`. Sets `byte_7FFBE823A97C = 0` on return.

Client-side site is `client+0xAFDFB0` (function prologue
`40 55 53 56 41 56 48 8D 6C`). The three cached fn pointers are consumed
later by Handler A's step 5 and Handler C's core capture — so Handler B
is the **shared bootstrap** for the other two hooks, not a hook itself.

## Handler C @ FVA+0x19B9C — `MessageLite::SerializeToArray` interceptor

Client-side function: `google::protobuf::MessageLite::SerializeToArray`
(client+0x1189930, prologue
`48 89 5C 24 18 48 89 74 24 18 55 57 41 54 41 56 41 57 48 8B EC 48 83 EC 70`).

Semantics (from decompile, sub_7FFBE80C9B9C):

1. TLS-guarded init of `qword_7FFBE823CBE0` (original SerializeToArray fn
   ptr) from `qword_7FFBE823C430`, guarded by counter
   `dword_7FFBE823CC08`.
2. Read short-string field via `(*vtable[15])(a1, &v21) + 8`. This is the
   protobuf message's type-name lookup: vtable slot 15 returns a
   `std::string*`, +8 is the SSO buffer / heap pointer split field.
3. Build an encrypted string in local buffer (`v21..v22`) — four qwords
   `0xF6E0262244CDBA8E`, `0x9F047512FCEAE7BC`, then XOR keys
   `0x9393734737ACF8CD` and `0x9F0437429887A4CE` — decrypts to a probe
   name.
4. Compute `sub_7FFBE81CC590(&v21)` (hash of decrypted target).
5. Compare against the message's decoded string length + bytes; if
   `hash_matches && strcmp_matches && a1 != scratch`:
   - `sub_7FFBE80F9250(&unk_7FFBE8234C90, ...)` — clear scratch slot
   - `sub_7FFBE80FA2E4(&unk_7FFBE8234C90, a1)` — store caller's message
     ptr into scratch (`FVA + 0x184C90`, `unk_7FFBE8234C90` global)
6. Delegate: `v18 = qword_7FFBE823CBE0(a1, a2, a3)`.
7. Free long-SSO string if allocated.

The scratch `unk_7FFBE8234C90` (RVA 0x184C90) matches the qword we saw
change 10 bytes per iteration in continuous dumps and matches the
`unk_7FFBE8234C90` global address IDA already knew.

Matches `reconstruction/src/hooks/serialize_to_array_hook.cpp`.

## Globals catalog (in FVA image, from disasm)

| Global | RVA (FVA) | Purpose |
|---|---|---|
| qword_7FFBE823AD10 | 0x18AD10 | captured original `CreateMove` fn ptr |
| qword_7FFBE823CBE8 | 0x18CBE8 | Handler A "call original" slot |
| qword_7FFBE823CC00 | 0x18CC00 | cvar `cl_pred_print_every_cmd` |
| qword_7FFBE823CBF0 | 0x18CBF0 | cvar `cl_showusercmd` |
| dword_7FFBE823CBF8 | 0x18CBF8 | Handler A init counter |
| dword_7FFBE823CBFC | 0x18CBFC | cvar init counter (cl_pred_print_every_cmd) |
| dword_7FFBE823CC0C | 0x18CC0C | cvar init counter (cl_showusercmd) |
| qword_7FFBE823CBE0 | 0x18CBE0 | Handler C "call original" slot (SerializeToArray) |
| qword_7FFBE823C430 | 0x18C430 | captured original `SerializeToArray` fn ptr |
| dword_7FFBE823CC08 | 0x18CC08 | Handler C init counter |
| qword_7FFBE823A928 | 0x18A928 | Client interface pointer (from client+0x2320570) |
| qword_7FFBE823A980/988/990 | 0x18A980/8/0 | Handler B resolved fn pointer cache |
| qword_7FFBE823B010 | 0x18B010 | Handler B delegate target |
| byte_7FFBE823A97C | 0x18A97C | Handler B "already fired" flag |
| unk_7FFBE8234C90 | 0x184C90 | Global scratch — Handler C stores captured msg ptr here |

The two hash constants from a prior session (`0x4C7C6391100B2438` and
`0x51CEE653EC562D63`) are the FNV1a hashes of two other cvar / interface
names — matched neither of the CreateMove pair. They likely belong to a
fourth hook or an interface-cache seed used inside Handler B.

## Continuous-dump signal

271 iterations captured over 4 minutes to
`C:\vmp\fva_livecap\continuous\`. Per-iteration delta in the 32 KB
scratch region shows real state change every 2 s: current live 10-byte
churn between iter 0 and iter 2, concentrated at scratch offsets
`+0xC80..+0xC82` (near `unk_7FFBE8234C90 = FVA+0x184C90`) and
`+0x6918..+0x691A`. The trampoline dump slot came out empty because the
helper requested 0x20000 bytes anchored 0x20000 before client.dll but the
committed trampoline page is only 0x1000 bytes at
`client - 0x10000`. Helper build to be adjusted to VirtualQuery-walk the
trampoline area.

## Reproducibility

Winning path this session, unchanged since 13:22:

1. `nvidia_profile_reset.ps1` if NVAPI_ACCESS_DENIED is showing (BSOD
   corruption from prior runs).
2. `steam://run/730//-insecure%20-nojoy%20+map%20de_dust2/`, wait for
   client.dll.
3. `mydbg --stealth --attach-name cs2 --script mydbg_fva_minimal.script`
   (minimal script — DllMain deferred BP + holdexit + g).
4. `inject_ldrloaddll.ps1 -DllPath C:\vmp\FuckVacAgain.dll -TargetProc cs2.exe`.
5. Python direct RPM for burst reads (own handle, no debug port impact).
6. `inject_ldrloaddll.ps1 -DllPath C:\vmp\fva_helper\fva_helper.dll` for
   continuous in-process dumps.

Everything runs from a single elevated PowerShell session; cs2 stays
alive indefinitely with hooks installed and no self-scan trigger.
