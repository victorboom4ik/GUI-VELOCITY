# Runtime injection fix guide — что может сломаться и как чинить
**Date:** 2026-07-10 23:30

Гид по каждому потенциальному failure point при injection `fva_recon.dll` в cs2.exe.
Читай log output — matching lines → соответствующий fix.

## Prereq — правильная DLL под правильный depot

**live client.dll MD5** = `b0fd08261be12cceb8e5636500e5a1d0` = **depot 14167 baseline** ✅

**Use:** `C:\vmp\implementation_theory\reconstruction\build\Release\fva_recon.dll` (= `fva_recon_depot_14167.dll`)

Если Steam догонит up-to-date версию (24134959) — используй `fva_recon_depot_24134959.dll` или пересобирай.

## Sequence at DLL entry (dllmain.cpp main_thread)

Каждый шаг ниже с ожидаемым log line + fix if fails.

### Step 1: Console + file sink

**Expected log:**
```
[fva_recon] console attached
```

**Failure:** `AllocConsole` failed — не критично, DLL работает без console.
**Fix:** не нужен.

### Step 2: Module wait (≤10s)

**Expected log:**
```
[fva_recon] waiting for CS2 modules...
[fva_recon] modules: client=... engine2=... networksystem=... animationsystem=...
```

**Failure:**
```
[fva_recon] FATAL: modules not present after 10 s — abort
```

**Cause:** cs2 not launched, or wrong process.
**Fix:** запусти cs2 перед inject.

### Step 3: client_input::init

**Expected log:**
```
[fva_recon] client_input: get_slot_input=0x... current_seq=0x... get_cmd=0x...
[fva_recon] client_input ready
```

**Failure:**
```
[fva_recon] WARN: client_input::init failed — mutation will be a no-op
```

**Cause:** один из 3 sigs не hit-нулся (client.dll drift).
**Verified:** все 3 sigs работают на 14167 + 24134959 (проверено статически).

**Fix if fails:** sig-scan patterns в [client_input.cpp:32-38](../src/valve/client_input.cpp). Найти правильные RVAs через IDA/mydisasm.

### Step 4: cvar_suppress::init

**Expected log (14167 baseline):**
```
[fva_recon] wire_icvar: icvar=0x...
[fva_recon] wire_icvar: table=0x... (legacy layout root+72)
[fva_recon] cvar_suppress init ok
```

**Expected log (24134959):**
```
[fva_recon] cvar_suppress: direct-RVA hit for "cl_pred_print_every_cmd" @ 0x23A4328 (name@obj+0x18)
[fva_recon] cvar_suppress: direct-RVA hit for "cl_showusercmd" @ 0x239ECE8 (name@obj+0x18)
[fva_recon] cvar_suppress init ok
```

**Failure на 14167:**
```
[fva_recon] wire_icvar: table=... layout invalid, probing...
[fva_recon] wire_icvar: probe found layout — table @ root+0x..., ...
```

Это OK — auto-probe fallback работает. Если ФАКТИЧЕСКИ fail:

```
[fva_recon] wire_icvar: probe failed — no valid ConVar table found
[fva_recon] WARN: cvar_suppress::init failed — cvar zeroing disabled
```

**Cause:** ICvar interface layout drift totally.
**Impact:** cvars НЕ zeroed — CS2 debug lines `cl_pred_print_every_cmd`/`cl_showusercmd` могут спамить в console. НЕ БЛОКИРУЕТ Section-J spoof.
**Fix:** RunTime — можно игнорировать (spoof работает без cvar suppression). Nice-to-have.

### Step 5: console::init (InputService_001)

**Expected log:**
```
[fva_recon] console: InputService_001=0x... vtable[25]=0x... ready
```

**Failure:**
```
[fva_recon] WARN: console::init failed — auto-test harness disabled
```

**Cause:** engine2.dll InputService_001 vtable slot 25 не соответствует expected type.
**Impact:** ONLY auto-test harness (`console::exec` для scripted commands). НЕ БЛОКИРУЕТ spoof.
**Fix:** не нужен для gameplay demo.

### Step 6: scratch_serialize::init

**Expected log (14167):**
```
[fva_recon] Hook C resolved target=... (RVA 0x1189930)
[fva_recon] arena_string_set @ ... (RVA fallback)
[fva_recon] scratch_serialize ready
```

**Failure:**
```
[fva_recon] WARN: scratch_serialize::init failed — move_crc regen disabled
```

**Cause:** SerializePartialToArray sig OR ArenaStringPtr::Set RVA drift.
**Verified:** RVA 0x1189930 на 14167 ✓, 0x11712C0 для ArenaStringPtr::Set ✓.

**Impact:** move_crc НЕ пересчитывается. Wire integrity checks server-side могут флагнуть.
**Impact severity:** MEDIUM — Section-J spoof работает, но move_crc mismatch.
**Fix:** update `arena_string_ptr_set` RVA в [manifest](../src/version_manifest.h).

### Step 7: protobuf_alloc::init

**Expected log:**
```
[fva_recon] protobuf_alloc: CBaseUserCmdPB::New @ 0x4B21E0 (14167) OR 0x4E2300 (24134959)
[fva_recon] protobuf_alloc ready
```

**Failure:**
```
[fva_recon] WARN: protobuf_alloc::init failed — null-base alloc disabled
```

**Cause:** RVA drift + fingerprint gate refused.
**Impact:** если raw->base == null (rare, только pre-connect), lazy-alloc не сработает → Hook A bails.
**Fix:** verify RVA + fingerprint bytes в manifest.

### Step 8: phase_c::init

**Expected log:**
```
[fva_recon] phase_c CInButtonStatePB::New @ RVA 0x... first=48 89 5C 24 10 at+0x14=B9 30 00 00 00
[fva_recon] phase_c CMsgQAngle::New @ RVA 0x... first=48 89 5C 24 10 at+0x14=B9 28 00 00 00
[fva_recon] phase_c ready
```

**Failure — RVA + sig-fallback хиты:**
```
[fva_recon] phase_c: manifest RVA drift — trying sig-scan fallback
[fva_recon] phase_c: fallback sig-scan hit @ 0x...
```

**Failure — heap fallback:**
```
[fva_recon] phase_c: sig-scan also missed — installing heap fallback
```

**Impact:** heap fallback OK для scratch mirror (не VAC-critical). Скипается self_check.
**Fix:** update manifest RVAs.

### Step 9: phase_b2::init

**Expected log:**
```
[fva_recon] phase_b2 ready
```

**Failure:** нет — просто ready flag flip. Не fails.

### Step 10: self_check::run_all

**Expected log:**
```
[fva_recon] entering self_check::run_all
[fva_recon] self_check returned: 1
```

**Failure:**
```
[fva_recon] self_check returned: 0
```
(потом FATAL abort ЕСЛИ FVA_STRICT_FINGERPRINT defined — иначе warning + continue)

**Cause:** MD5 mismatch OR pre-patch bytes don't match.
**Impact:** hooks all install anyway (default non-strict). Индикатор что нужно update manifest.
**Fix:** update `kExpectedClientMd5` + `kHookAPrePatch/BPrePatch/CPrePatch` в manifest.

### Step 11: install_all (MinHook)

**Expected log:**
```
[fva_recon] Hook A target=0x... (RVA 0xACEF90) prologue=85 D2 0F 85 85
[fva_recon] Hook B resolved target=0x... (RVA 0xAFDFB0) prologue=40 55 56 41 56
[fva_recon] Hook C resolved target=0x... (RVA 0x1189930) prologue=48 89 5C 24 18
[fva_recon] hooks installed
[fva_recon] install_all returned: 1
```

**Failure — sig-scan hit + fingerprint mismatch:**
```
[fva_recon] Hook C fingerprint MISMATCH — refusing to install
[fva_recon] install_all returned: 0
[fva_recon] FATAL: install_all failed — abort
```

**Cause:** target bytes не совпадают с expected prologue.
**Fix:** update `kHook?PrePatch` в manifest для этого depot.

**Failure — MinHook error:**
```
[fva_recon] install_all returned: 0
```

**Cause:** MinHook internal error (out of trampoline pages, invalid target).
**Fix:** try MH_STATUS enum in debugger; usually 0x80000000+ codes indicate specific issues.

### Step 12: game_state::resolve

**Expected log:**
```
[fva_recon][B] game_state: accessor=0x... rel32=... slot=0x... interface=0x...
[fva_recon] game_state resolved: interface=0x...
```

**Failure:**
```
[fva_recon][B] game_state: accessor sig not found
[fva_recon] game_state resolve: MISS (accessor sig not in client.dll — alt_symbol stays dormant)
```

**Cause:** sig `48 8B 0D ? ? ? ? 48 8D 54 24 ?` не hit — non-unique sig может drift.
**Impact:** alt_symbol остаётся 0 → Section J всегда skipped → **spoof не работает!**
**Fix:** replace sig в [game_state_resolver.cpp:70](../src/hooks/game_state_resolver.cpp#L70) на более специфичный. FVA использует sub_7FFBE80C8E68's XOR-decrypted pattern.

### Step 13: Runtime — first Hook A tick

**Expected log:**
```
[fva_recon][H1] first tick self=... nSlot=... bFinal=...
[fva_recon] Hook C target vtable=... (RVA 0x1995748 or 0x19D5588)
```

**Failure — vtable mismatch:**
Если vtable RVA не тот что в manifest → filter fail → scratch capture не срабатывает.
**Fix:** verify `vtable_cbaseusercmdpb` в manifest — на 14167 = 0x1995748, на 24134959 = 0x19D5588.

### Step 14: Runtime — Section-J emit

**Expected log (fire event):**
```
[fva_recon][H1] tick=... fire_flag: 0 -> 1 (+ATTACK PRESSED)
[fva_recon][B2] apply#... ENTRY  pre_va=... target=... SELF-ECHO
[fva_recon][B2] resolved CS2 CSGOInputHistoryEntryPB::New @ 0x... size 0x78 verified
[fva_recon][B2] resolved CS2 CMsgQAngle::New @ 0x... size 0x28 verified
[fva_recon][B2] EMIT last_idx=... has_bits=0x1E01 qangle=(pitch,yaw,roll) emitted=N
[fva_recon][B2] apply#... EXIT   post_va=... delta=... post_subs=... (+N)
```

**Failure — allocator fingerprint mismatch:**
```
[fva_recon][B2] CSGOInputHistoryEntryPB::New: RVA 0x... fingerprint MISS — REFUSING sig fallback
```

**Impact:** emitter не может alloc — no emit, no spoof.
**Fix:** update `new_maybe_arena_csgoinputhistoryentrypb` RVA в manifest для этого depot.

### Step 15: Runtime — Hook C capture

**Expected log (после Section-J emit):**
```
[fva_recon][H3] vtable seen: 0x... (RVA 0x1995748) [CBaseUserCmdPB — target]
[fva_recon][H3] wire snapshot len=... bytes: ...
```

**Failure:**
```
[fva_recon][H3] vtable seen: 0x... (RVA ...) 
```
(no `[CBaseUserCmdPB — target]` tag)

**Cause:** vtable-pointer filter miss.
**Fix:** update `vtable_cbaseusercmdpb` в manifest.

## Runtime fix — что могу починить прямо сейчас, если что-то сломается

Скажи мне какой log line ты видишь → я скорректирую manifest RVA + пересоберу DLL за ~1 минуту.

Если хочешь runtime-live debugging — включи `-DFVA_TRACE_HOOKA=ON` в CMake:
```
cmake -DFVA_TARGET_DEPOT=14167 -DFVA_TRACE_HOOKA=ON .
```
Даёт per-tick verbose logging (~128 lines/sec) с всеми phase transitions.

## Quick reference — что где искать в log

| Log prefix | Component | Значит что |
|-----------|-----------|------------|
| `[fva_recon] console` | DLL entry | init state |
| `[fva_recon] modules:` | wait_for_modules | modules loaded |
| `[fva_recon] client_input:` | Section B chain-resolve | GetSlotInput etc |
| `[fva_recon] cvar_suppress:` | Section A cvar zero | cvars found |
| `[fva_recon] wire_icvar:` | ICvar fallback | ConVar registry walk |
| `[fva_recon] Hook A/B/C` | install phase | hook targets |
| `[fva_recon][H1]` | Hook A body | per-tick logs |
| `[fva_recon][B2]` | Section-J emitter | spoof emit |
| `[fva_recon][H3]` | Hook C capture | scratch snapshot |
| `[fva_recon][B]` | game_state resolver | interface find |

## Injection instructions

**Prereq:**
1. Live client.dll MD5 = `b0fd08261be12cceb8e5636500e5a1d0` (baseline 14167)
2. `C:\vmp\implementation_theory\reconstruction\build\Release\fva_recon.dll` = 14167 build
3. Steam auto-update OFF (Свойства → Обновления → Только по запуску)

**Steps:**
1. Launch cs2.exe с `-insecure` (offline).
2. Wait for main menu.
3. Load map: `map de_dust2` (console).
4. Add bots: `bot_add ct` (console).
5. **Inject** `fva_recon.dll` через твой manual mapper.
6. **Log window появится** с `[fva_recon] console attached`.
7. Play — стреляй по ботам.
8. Log должен показать `[fva_recon][H1] fire_flag: 0 -> 1 (+ATTACK)` + `[fva_recon][B2] EMIT ... emitted=N`.
9. Records video.
10. Press **END** to unload DLL cleanly.

**Если что-то не работает** — copy log output → сюда → починю.
