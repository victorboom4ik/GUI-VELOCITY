# FVA reconstruction — gap audit для BugHunter report
**Date:** 2026-07-10 (после depot 14167 → 24134959 update + F.1 CLOSED)

## Executive summary

**Готово к PoC video для BugHunter report.** Все critical gaps закрыты:

| Компонент | Status |
|-----------|--------|
| Hook A (CreateMove) — full detour body с cvar zero, alt_symbol snapshot, one-time original call | ✅ 1:1 |
| Hook B (LevelInit) — passthrough + game_state resolve + alt_symbol reset | ✅ 1:1 semantic |
| Hook C (SerializePartialToArray) — vtable-pointer filter + scratch capture via Clear+MergeFrom | ✅ 1:1 (vtable-pointer более robust чем FVA's typename) |
| **Section-J emitter (`sub_7FFBE82E8C32`)** — multi-iteration loop с fractional interpolator + render_tick_count carry-over + cross-arena consistency | ✅ **FULLY PORTED** (см. §C) |
| CS2 protobuf T::New helpers (CBaseUserCmdPB, CSGOInputHistoryEntryPB, CMsgQAngle) via known-RVA + fingerprint gate | ✅ 1:1 |
| CS2 ArenaStringPtr::Set via sig-scan | ✅ 1:1 |
| ICvar zeroing per-tick (cl_pred_print_every_cmd, cl_showusercmd) | ✅ 1:1 |

**Известные skip'ы (см. §E, не блокируют PoC):**
- `random_seed` / `execution_notes` writes — FVA source обфусцирован VMProtect на диске, не порчу CS2 prediction guessing
- Buffer growth slow path — Rep обычно pre-sized CS2, миссится редко

## A. Что 1:1 верифицировано (✅ ported)

| FVA sub | Роль | Наш код |
|---------|------|---------|
| `sub_7FFBE80C9D8C` Handler A | CreateMove detour skeleton | [create_move_hook.cpp](../src/hooks/create_move_hook.cpp) `detour` |
| `sub_7FFBE80C8E68` Handler B | LevelInit passthrough + alt_symbol reset | [level_init_hook.cpp](../src/hooks/level_init_hook.cpp) |
| `sub_7FFBE80C9B9C` Handler C | SerializePartialToArray filter+capture | [serialize_to_array_hook.cpp](../src/hooks/serialize_to_array_hook.cpp) |
| **`sub_7FFBE82E8C32`** Section-J emitter | Multi-iteration emit с interpolator + carry-over | [phase_b2.cpp `run_fva_section_j_emitter`](../src/hooks/phase_b2.cpp) |
| `sub_7FFBE80DCB84` + `sub_7FFBE80DCD0C` | IDA-sig parser + PE scanner | [signature_scanner.cpp](../src/core/signature_scanner.cpp) |
| `sub_7FFBE80C9520` | ConVar FNV1a walker | [convar.cpp](../src/core/convar.cpp) |
| `sub_7FFBE819EFB0`/`sub_7FFBE819EF40` | TLS-guarded once-init | C++ `std::atomic` once-flags |
| Cvar zeroing (`+0x1D7`/`+0x914`) | `cvar+0x58 = 0` × 2 per tick | [cvar_suppress.cpp](../src/features/cvar_suppress.cpp) |
| alt_symbol byte poke | Snapshot + zero + reset in Hook B | `alt_symbol` namespace |
| `[raw+0x20] |= 1u` Section E.1 | flags OR | [create_move_hook.cpp:498](../src/hooks/create_move_hook.cpp#L498) |

## B. Semantically equivalent (не byte-identical, но identical effect)

| FVA sub | Наш заменитель | Почему equivalent |
|---------|----------------|-------------------|
| `sub_7FFBE80F9250` (Clear) | vtable slot `[0x18]` dispatch | CS2's OWN Clear через vtable → тот же эффект |
| `sub_7FFBE80FA2E4` (MergeFrom) | vtable slot `[0x30]` dispatch | Same |
| `sub_7FFBE80F9FF8` (ByteSizeLong) | vtable slot `[0x38]` dispatch | Same |
| `sub_7FFBE80C989C` (ScratchToString) | `scratch_serialize::serialize()` + CS2 SPTA | Same wire bytes |
| `sub_7FFBE80FAD0C` (NewMaybeArena_CBaseUserCmdPB) | CS2's own @ RVA 0x4E2300 | CS2 stamps correct vtable |
| `sub_7FFBE81027F0` (ArenaStringPtr::Set) | CS2's @ RVA 0x1194E70 via sig-scan | Same tagged-string behavior |
| `sub_7FFBE80DC5A8` (malloc wrapper) | MSVC CRT `malloc` | Same allocator |
| `sub_7FFBE8103070` (arena AllocateAligned) | Транзитивно через CS2's T::New | Same arena |
| `sub_7FFBE80F6FEC` (CMsgQAngle::NewInArena) | CS2's `sub_180xxx` via sig-scan | Same |
| `sub_7FFBE80FABFC` (CSubtickMoveStep::NewInArena) | CS2's fingerprint-gated resolver | Same |
| `sub_7FFBE80CB268` (RepeatedPtrField::Get) | Direct `rep->elements[i]` с bounds check | Same |
| `sub_7FFBE80DDA60` / `sub_7FFBE80DD778` (aux sig-resolvers) | Не нужны — Hook B tail state populated via `game_state_resolver` direct scan | Same runtime state |

## C. Section-J emitter — детали port (было HIGHEST priority gap, теперь CLOSED)

**Что портировано** (см. [phase_b2.cpp `run_fva_section_j_emitter`](../src/hooks/phase_b2.cpp)):

```c
// Pre-emit scan: cache last render_tick_count from existing Rep entries
uint32_t cached_tc = 0;
for (i = 0; i < subs->current_size; i++) {
    if (elements[i]) cached_tc = *(uint32_t*)(elements[i] + 0x60);
}

remaining = 16 - subs->current_size;
for (iter = 0; iter < remaining; iter++) {
    fraction = (iter + 1) / remaining;
    interp_pitch = engine_pitch + fraction * d_pitch;
    interp_yaw   = engine_yaw   + fraction * d_yaw;
    interp_roll  = engine_roll  + fraction * d_roll;

    step   = CS2_CSGOInputHistoryEntryPB_New(subs->arena);   // 120 B
    qangle = CS2_CMsgQAngle_New(subs->arena);                // 40 B, SAME arena
    qangle{.x=interp_pitch, .y=interp_yaw, .z=interp_roll, .has_bits |= 0x7}
    step[+0x18] = qangle
    step[+0x60] = cached_tc              // render_tick_count carry-over
    step[+0x64] = fraction               // render_tick_fraction
    step[+0x68] = 0                      // player_tick_count / fraction
    step->has_bits |= 0x1E01             // VIEW|R_TC|R_TF|P_TC|P_TF

    // Inline swap-safe AddAllocated:
    if (rep->allocated_size < subs->total_size) {
        if (subs->current_size < rep->allocated_size)
            rep->elements[allocated_size] = rep->elements[current_size]
        rep->elements[current_size++] = step
        rep->allocated_size++
    } else break   // slow path (§D) не порт
}
```

**Map-exit crash root cause fix (§C5 + §E5 в старой версии):**
FVA использует `sub_7FFBE8101CC0` для cross-arena copy когда step's arena != qangle's arena. Мы избегаем copy передавая SAME `subs->arena` обоим allocator'ам → shared owner → CS2 Rep destructor unwinds без mismatch → нет crash на map exit.

## D. Остаточные gaps (skipped — не блокируют BugHunter PoC)

### D.1 Buffer growth slow path (`sub_7FFBE80CB348` + `sub_7FFBE8102020` + `sub_7FFBE819EEC0`)

FVA fallback когда Rep full — arena-copy + realloc growth. Мы break out of emit loop если Rep full → эмиттим меньше entries в edge case.

**Impact:** практически неощутим — CS2 pre-sizes Rep до 16-ish на каждый tick, `allocated_size < total_size` почти всегда true.

### D.2 `random_seed` (pb+0x6C) writes

FVA возможно пишет в pb->random_seed для server-side prediction override. Значение не декодируется из VMProtect-обёрнутой FVA на диске.

**Impact:** без этого server prediction RNG идёт нормально (CS2's own value) — не ломает spoof. С неправильным value могло бы наоборот испортить hitreg.

**Decision:** SKIP. Better safe than broken.

### D.3 `execution_notes` (pb+0x48) writes

Similar reasoning. Skip.

### D.4 Cross-arena copy (`sub_7FFBE8101CC0`)

Не нужен благодаря shared-arena fix в §C (передаём `subs->arena` в оба allocator).

## E. Deliberately skipped (anti-tamper / decoy — verified inert)

| FVA sub | Что делает | Почему skip |
|---------|-----------|-------------|
| `sub_7FFBE81001E0` | "13-slot resolver" — 13 patterns all → `FF 27` (import stub) | Anti-tamper decoy: 13 globals имеют 1 write-xref only (в самом resolver), 0 read-xref → цель crash debugger между init и never-read |
| `sub_7FFBE80DD778` | Aux sig-resolver | 1 data xref, never called from hooks |
| `sub_7FFBE80DDA60` | Big aux (0x306a B) | 1 data xref, not on critical path |
| `sub_7FFBE80FB520` | Mega aux (0x4cbf B) | 1 data xref, not on critical path |
| `sub_7FFBE80BF810`/`sub_7FFBE80B95E0`/`sub_7FFBE80B5954` | Label installers (OnAddEntity/Hook_HandleJump/Hook_SetInfo) | Static std::string labels с atexit — no consumer |
| `sub_7FFBE81D2118`/`sub_7FFBE81D1D1C`/`sub_7FFBE81D1B3C` | std::string dtors для labels | MSVC CRT |
| **Phase D — Base64 self-audit** | Reads FVA's own scratch, crashes FVA if tampered | FVA-side self-integrity — reproducing собственный crash не нужен |
| `sub_7FFBE8103A70`/`sub_7FFBE81038C0`/`sub_7FFBE8104360`/`sub_7FFBE81044B0` | FVA's SerializeToArray copies | Superseded by CS2 SPTA @ RVA 0x11AD4E0 |

## F. Как проверить что работает — test plan для видео

### F.1 Prereq

1. **Закрыть cs2 полностью** (Steam → CS2 → Exit) — иначе rebuild fva_recon.dll не пройдёт (LNK1104).
2. Ждать ~5s чтобы Windows освободил file handle.

### F.2 Build

```powershell
cd C:\vmp\implementation_theory\reconstruction\build
cmake --build . --config Release --target fva_recon
```

Ожидаемо: `fva_recon.dll -> C:\vmp\implementation_theory\reconstruction\build\Release\fva_recon.dll`

### F.3 Запуск CS2 + inject

1. Steam → CS2 → Launch с параметром `-insecure` (тестируем offline без VAC — legit ресерч для BugHunter).
2. Загрузить offline map: `map de_dust2` в console.
3. Добавить ботов: `bot_add ct`.
4. Inject fva_recon.dll через любой manual mapper (LdrLoadDll / injector.exe если есть).

### F.4 Проверка logs

fva_recon.dll печатает в stdout (нужен console spawner или debug console output). Ожидаемые строки:

```
[fva_recon] Hook A target=... (RVA 0xB09528)
[fva_recon] Hook B resolved target=... (RVA 0xB3A600)
[fva_recon] Hook C resolved target=... (RVA 0x11AD4E0)
[fva_recon] Hook C target vtable=... (RVA 0x19D5588)
[fva_recon] arena_string_set @ ... (sig-scan)
[fva_recon][B2] resolved CS2 CSGOInputHistoryEntryPB::New @ ... [known-RVA + size 0x78 verified]
[fva_recon][B2] resolved CS2 CMsgQAngle::New @ ... [known-RVA + size 0x28 verified]
[fva_recon][H1] first tick self=...
[fva_recon][H1] tick=X BUTTONS changed=... (при нажатии клавиши)
[fva_recon][B2] apply#1 ENTRY  pre_va=... target=... SELF-ECHO  pre_subs=X
[fva_recon][B2] EMIT last_idx=X step@... has_bits=0x1E01 qangle=(pitch,yaw,roll) ... emitted=Y
[fva_recon][B2] apply#1 EXIT   post_va=... delta=... post_subs=X (+Y) appended=1
[fva_recon][H3] vtable seen: ... [CBaseUserCmdPB — target]
[fva_recon][H3] wire snapshot len=X bytes: ...
```

### F.5 In-game demonstration

Стреляй по боту:
- Client видит свою собственную viewangle корректно (CS2 restores prior_x/y/z после нашего spoof).
- **Server видит spoofed input_history с fractional interpolated angles** — 1..N новых entries с интерполированной pitch/yaw/roll от `engine_view` к `engine_view + delta`.
- **Wire snapshot dump в log** покажет serialized bytes идущие серверу — можно сравнить с baseline capture (без inject).

### F.6 Recording

Для BugHunter report — 30–60s video:
1. Boot cs2, add bots, inject fva_recon.dll.
2. Показать log output ([fva_recon] строки).
3. Show gameplay где viewangles client vs. spectator POV разные (spectate бота через dev cam / third-person).
4. Опционально — pcap Wireshark filter на CS2 UDP shows non-standard input_history payloads.

## G. Что оставить ЗА пределами BugHunter report

- Anti-tamper decoy resolvers (§E) — reporting inert code = shallow analysis.
- Debug label installers — same.
- Feature toggle labels (OverrideView, FirstPersonLegs) — decoys.
- VMProtect wrapping — Valve и так знает.
- `random_seed` speculation — без ground truth нельзя claim.

## H. Итоги

| Category | Count | Status |
|----------|-------|--------|
| Fully 1:1 ported (§A) | 10 | ✅ |
| Semantic equivalent (§B) | 12 | ✅ |
| Section-J emitter (§C) | 1 | ✅ **FULLY PORTED** |
| Skipped gaps (§D) | 4 | ⚠️ non-blocking |
| Anti-tamper skipped (§E) | 12 | ✅ verified inert |

**Bottom line:** порт готов к PoC. Основной механизм VAC-evasion (input_history spoofing через interpolated view angles) 1:1 воспроизведён. Build + inject + record.
