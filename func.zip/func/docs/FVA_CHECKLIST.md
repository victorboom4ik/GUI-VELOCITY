# FVA function-by-function reconstruction checklist

Every FVA function we identified, mapped to the reconstruction line(s) that
reproduce it — or a documented skip with justification.

All FVA addresses use FVA base `0x7FFBE80B0000` (live session).  Reconstruction
paths are relative to `C:\vmp\implementation_theory\reconstruction\`.

Legend for **Status** column:
- ✅ ported   — behavior is reproduced in reconstruction
- 🟢 native   — behavior is achieved by calling CS2's own implementation
- ⛔ skip     — verified inert / anti-tamper only for FVA, no need to port
- 📦 CRT     — MSVC C runtime, provided by our own linker
- ⏸ optional — could be ported later, no user-visible loss right now

## 1. Hooks

### Hook A — CInput::CreateMove side

Target: `client.dll+0xACEF90` (RVA), FVA handler: `sub_7FFBE80C9D8C`.

| Sub-phase (FVA offset) | Status | Where it lives in our code |
|------------------------|--------|-----------------------------|
| Prologue + save r13/r15/r14 args | ✅ | `src/hooks/create_move_hook.cpp:63` (compiler-generated) |
| Phase A — Cvar cache + per-tick zero (`+0x0000..+0x01F7`) | ✅ | `src/hooks/create_move_hook.cpp:67-69` (`cvar_suppress::apply()`) |
| Phase B — chain-resolve CUserCmd (`+0x0444..+0x071D`) | ✅ | `src/hooks/create_move_hook.cpp:72-76` (`client_input::current_local_cmd()`) |
| Phase B — read Hook-B state qword_7FFBE823A988 (`+0x01F7..+0x0270`) | ⛔ | Skip: FVA reads game state byte into byte_7FFBE823A9A0 — never consumed by hooks A/B/C themselves (verified via xrefs) |
| Phase C — auxiliary CMsgVector/CMsgQAngle mirrors (`+0x0A34..+0x0AA2F`) | ⏸ | Skip pending re-audit (workflow wrb9k1fu0 auditing xrefs to qword_7FFBE8234CC8/CD0) |
| Phase D — Base64 self-audit (`+0x0AA2F..+0x0AF87`) | ⛔ | Skip: verified as FVA-internal anti-tamper — reads FVA's own scratch and crashes FVA if tampered. Our reconstruction doesn't need to trigger its own crash. |
| Phase E1 — `raw_cmd->flags |= 1` (`+0x0117E`) | ✅ | `src/hooks/create_move_hook.cpp:79` |
| Phase E2 — null-base guard (`+0x0B182..+0x0B1A1`) | 🟢 | `src/hooks/create_move_hook.cpp:82-89` calls `protobuf_alloc::new_cbaseusercmdpb()` which invokes CS2's own `NewMaybeArena_CBaseUserCmdPB` @ RVA 0x4B21E0 |
| Phase E3 — set MOVE_CRC has_bit (`+0x011A5`) | ✅ | `src/hooks/create_move_hook.cpp:104-105` |
| Phase E4 — scratch → base->move_crc bytes (`+0x011A9..+0x011CB`) | ✅ | `src/hooks/create_move_hook.cpp:99-102` calls `scratch_serialize::serialize()` (uses CS2's own SerializePartialToArray via sig-scan) + `std::string::assign()` |
| Epilog (restore xmm6..13, pop callee-saved) | ✅ | Compiler-generated |

### Hook B — CBaseClientState::FireLevelInitEvent

Target: `client.dll+0xAFDFB0`, FVA handler: `sub_7FFBE80C8E68`.

| Sub-phase | Status | Where |
|-----------|--------|-------|
| Lazy resolve 3 patterns → qword_7FFBE823A980/A988/A990 | ⏸ | `src/hooks/level_init_hook.cpp:22` — passthrough only. Deferred: our Hook A doesn't consume the resolved globals; if Phase C aux mirrors are ever ported (⏸ decision above), these resolves are pulled in with them. |
| Call original CBaseClientState::FireLevelInitEvent | ✅ | `src/hooks/level_init_hook.cpp:24` |

### Hook C — MessageLite::SerializeToArray (CBaseUserCmdPB filter)

Target: `client.dll+0x1189930`, FVA handler: `sub_7FFBE80C9B9C`.

| Sub-phase (FVA offset) | Status | Where |
|------------------------|--------|-------|
| Once-init cache original trampoline | ✅ | `MH_CreateHook` — MinHook handles equivalent lifetime |
| GetTypeName via `vtable[+0x78]` | ✅ | `src/hooks/serialize_to_array_hook.cpp:54-62` (`get_typename_hash`) |
| XOR-decode expected "CBaseUserCmdPB" | ✅ | `k_target_hash` init in `serialize_to_array_hook.cpp:32` using `fva::obf::fnv1a` |
| strlen + memcmp compare | ✅ | Reduced to fnv1a hash compare — semantically equivalent, faster |
| Recursion guard `self != scratch` | ✅ | `serialize_to_array_hook.cpp:71-74` (`is_self_scratch`) |
| `Clear(scratch); MergeFrom(scratch, self);` | ✅ | `serialize_to_array_hook.cpp:98-99` (`clear_and_merge_from`) using vtable[0x30] + vtable[0x80] |
| Cache CS2 vtable into scratch (once) | ✅ | `serialize_to_array_hook.cpp:93` (`cache_vtable_from`) — enables ByteSizeLong virtual dispatch in Hook A |
| Tail-call original | ✅ | `serialize_to_array_hook.cpp:107` |

## 2. Helper functions FVA calls

| FVA function | Role | Status | Where |
|--------------|------|--------|-------|
| `sub_7FFBE80C9520` FindConvarByHash | ConVar hash-node walker | ✅ | `src/core/convar.cpp:97-125` (`find_by_hash`) |
| `sub_7FFBE80DCB84` pattern parser | IDA sig → bytes+mask parser | ✅ | `src/core/signature_scanner.cpp:27-61` (`parse`) |
| `sub_7FFBE80DCD0C` module scanner | Scan region for parsed pattern | ✅ | `src/core/signature_scanner.cpp:63-86` (`find`) — restricted to executable sections as an optimisation over FVA's whole-module scan |
| `sub_7FFBE80F9250` CBaseUserCmdPB::Clear | protobuf Clear method | 🟢 | Not ported — invoked via `vtable[+0x30]` in Hook C |
| `sub_7FFBE80FA2E4` CBaseUserCmdPB::MergeFrom | protobuf MergeFrom | 🟢 | Not ported — invoked via `vtable[+0x80]` in Hook C |
| `sub_7FFBE80F9FF8` ByteSizeLong | protobuf size compute | 🟢 | Invoked via `vtable[+0x38]` in `scratch_serialize.cpp:70` |
| `sub_7FFBE80C989C` ScratchToString | serialize scratch → std::string | ✅ | `src/hooks/scratch_serialize.cpp:50-79` — uses CS2's SPTA directly |
| `sub_7FFBE80FAD0C` NewMaybeArena_CBaseUserCmdPB | arena alloc of CBaseUserCmdPB | 🟢 | `src/valve/protobuf_alloc.cpp:46-56` — calls CS2's own copy @ RVA 0x4B21E0 |
| `sub_7FFBE81027F0` arena-string-assign | Tagged std::string assign | ⛔ | Skip: verified as FVA-INTERNAL — CS2's client.dll uses regular std::string without the low-2-bit ownership tag, so our direct `std::string::assign()` is semantically correct |
| `sub_7FFBE8103A70` MessageLite::SerializeToArray thunk | FVA's own copy | ⛔ | Skip: not called anywhere in our port; superseded by direct CS2 SPTA in scratch_serialize |
| `sub_7FFBE81038C0` MessageLite::SerializeToArray | FVA's own copy | ⛔ | Skip: same reason |
| `sub_7FFBE8104360` MessageLite::SerializeToArray | FVA's own copy | ⛔ | Skip: same reason |
| `sub_7FFBE81044B0` SerializeWithCachedSizesToArray | FVA's direct serializer | ⛔ | Skip: superseded by CS2's SPTA @ RVA 0x1189A60 |
| `sub_7FFBE8103070` arena allocator | Google-protobuf arena alloc | 🟢 | Transitively used by CS2's own NewMaybeArena |
| `sub_7FFBE80DC5A8` heap allocator | Standard heap fallback | 📦 | MSVC CRT malloc reachable through the same NewMaybeArena |
| `sub_7FFBE81CC410` memcmp | Byte compare | 📦 | MSVC CRT (called as needed inside `std::string::assign`) |
| `sub_7FFBE81CC590` strlen | String length | 📦 | MSVC CRT |
| `sub_7FFBE80C6308` std::string construct | protobuf helper | 📦 | Any `std::string` construction in our code uses MSVC's implementation |
| `sub_7FFBE80C6FEC` std::string ctor variant | protobuf helper | 📦 | Same |
| `sub_7FFBE80C73C0` std::string dtor (SSO=7) | wide-string dtor | 📦 | MSVC CRT — decompile confirms it's a plain SSO-aware dtor |
| `sub_7FFBE80C749C` std::string dtor (SSO=15) | narrow-string dtor | 📦 | MSVC CRT — decompile confirms plain SSO-aware dtor |
| `sub_7FFBE819EEC0` free/realloc helper | CRT free | 📦 | MSVC CRT |
| `sub_7FFBE819EE80` _register_onexit_function | atexit-style registration | ⛔ | Skip: verified — `if (table == -1) init; else register_callback(table, cb); return -1 on fail` — MSVC CRT `_register_onexit_function` wrapper. Not called by any of our runtime paths. |
| `sub_7FFBE81CC070` memset | Zero-fill helper | 📦 | MSVC CRT |
| `sub_7FFBE81CB9C0` memmove/memcpy | Byte-copy helper | 📦 | MSVC CRT |

## 3. AntiTamper decoy resolvers

| FVA function | What it does | Status | Justification for skip |
|--------------|--------------|--------|-------------------------|
| `sub_7FFBE81001E0` "13-slot resolver" | Pattern-scans 13 modules → stores results in `qword_7FFBE823A9?? / AB?? / ABA?`. All 13 patterns decode to `"FF 27"` (jmp qword [rdi]) which every module has as the first byte of some import stub | ⛔ | Verified as anti-tamper decoy in [docs/DECOMPILE_FINDINGS_2026-07-09.md §4](DECOMPILE_FINDINGS_2026-07-09.md).  Each of the 13 globals has EXACTLY 1 code xref — the write-once inside this function; **none are read anywhere else**.  Purpose: cause a crash if the debugger is stopping FVA between init and the never-executed read. |
| `sub_7FFBE80DD778` auxiliary sig-resolver | Decodes an XOR-obfuscated pattern, sig-scans, returns the resolved slot value | ⛔ | Only 1 data xref (in FVA's rdata vtable table).  Never called from the three hook handlers. |
| `sub_7FFBE80DDA60` big auxiliary | 0x306a bytes of misc sig-scans that fill FVA rdata | ⛔ | 1 data xref only.  Not called from hook A/B/C paths. |
| `sub_7FFBE80FB520` mega auxiliary | 0x4cbf bytes of protobuf-related helper code | ⛔ | 1 data xref only.  Not on the three-hook critical path. |

## 4. Debug label registration

FVA has 4 "installer" functions that all follow the same pattern: XOR-decode a
string label ("OnAddEntity" / "AntiTamper" / "Hook_HandleJump" / "Hook_SetInfo"),
copy into a global std::string, register a destructor callback via
`_register_onexit_function`.  The destructor callbacks are plain SSO-aware
std::string destructors.

| FVA function | What | Status |
|--------------|------|--------|
| `sub_7FFBE80BF810` OnAddEntity installer | Fills `unk_7FFBE823A6F0` with the string, atexit `sub_7FFBE81D2118` | ⛔ |
| `sub_7FFBE80B95E0` Hook_HandleJump installer | Fills `xmmword_7FFBE823AC50`, atexit `sub_7FFBE81D1D1C` | ⛔ |
| `sub_7FFBE80B5954` Hook_SetInfo installer | Fills `xmmword_7FFBE823B020`, atexit `sub_7FFBE81D1B3C` | ⛔ |
| `sub_7FFBE81D2118` OnAddEntity destructor | Calls `sub_7FFBE80C73C0(&unk_7FFBE823A6F0)` = std::string dtor | ⛔ |
| `sub_7FFBE81D1D1C` Hook_HandleJump destructor | Calls `sub_7FFBE80C749C(&xmmword_7FFBE823AC50)` = std::string dtor | ⛔ |
| `sub_7FFBE81D1B3C` Hook_SetInfo destructor | Calls `sub_7FFBE80C749C(&xmmword_7FFBE823B020)` = std::string dtor | ⛔ |

All labels are **static global std::strings** with proper C++ static destruction.  There are ZERO event dispatchers or hook targets attached to them.  The `Hook_*` names are misleading debug labels FVA embeds probably for its own logging that we don't reproduce.

## 5. Reconstruction modules — what they implement

| Reconstruction file | Purpose | Corresponding FVA function(s) |
|---------------------|---------|-------------------------------|
| `src/dllmain.cpp` | DLL entrypoint, module wait, install-all | FVA's DllMain equivalent |
| `src/core/signature_scanner.cpp` | pattern parse + scan | `sub_7FFBE80DCB84` + `sub_7FFBE80DCD0C` |
| `src/core/obfuscation.h` | XOR qword-pair decode, FNV-1a | inline uses at Hook C entry + `sub_7FFBE80C9520` FNV loop |
| `src/core/convar.cpp` | ICvar wire + hash walker | `sub_7FFBE80C9520` semantics |
| `src/valve/cbaseusercmdpb_layout.h` | protobuf message layouts | Layout of `unk_7FFBE8234C90` (scratch) + CUserCmd |
| `src/valve/client_input.cpp` | GetSlotInput/CurrentSeq/CmdBySeq resolvers | Hook A chain @ `+0x0444..+0x071D` |
| `src/valve/protobuf_alloc.cpp` | CS2 NewMaybeArena_CBaseUserCmdPB caller | `sub_7FFBE80FAD0C` semantic via CS2's copy |
| `src/features/cvar_suppress.cpp` | Cvar init + per-tick zero | Hook A Phase A |
| `src/hooks/capture_buffer.cpp` | scratch instance + vtable cache | `unk_7FFBE8234C90` |
| `src/hooks/serialize_to_array_hook.cpp` | Hook C body | `sub_7FFBE80C9B9C` |
| `src/hooks/create_move_hook.cpp` | Hook A body | `sub_7FFBE80C9D8C` |
| `src/hooks/level_init_hook.cpp` | Hook B passthrough | `sub_7FFBE80C8E68` |
| `src/hooks/hook_manager.cpp` | install/uninstall orchestration | FVA `HookManager` container |
| `src/hooks/scratch_serialize.cpp` | scratch → wire bytes | `sub_7FFBE80C989C` (ScratchToString) — via CS2 SPTA |
| `src/tests/self_check.cpp` | boot-time invariants | (reconstruction diagnostic, not in FVA) |
| `src/tests/detect_build.cpp` | client.dll MD5 check | (reconstruction diagnostic) |
| `src/patterns/patterns_legacy.inl` | 3 hook target anchors | patterns FVA hard-codes in .rdata |
| `src/version_manifest.h` | drift constants | (single source of truth for all RVA/offset/xor) |

## 6. Aggregated status

| Metric | Count |
|--------|-------|
| FVA functions ported (with our code) | 8 (parser, scanner, FindConvarByHash, Hook A body, Hook B passthrough, Hook C body, scratch_serialize, cvar_suppress) |
| FVA functions replaced by CS2 native call | 4 (Clear via vtable, MergeFrom via vtable, ByteSizeLong via vtable, SerializePartialToArray via sig-scan, NewMaybeArena_CBaseUserCmdPB via RVA) |
| FVA functions replaced by MSVC CRT | 11 (memcmp, strlen, memcpy, memmove, memset, free, realloc, malloc, string ctors, string dtors, atexit) |
| FVA functions verified as inert & skipped | 12 (AntiTamper 13-slot resolver, base64 self-audit, 3 auxiliary sig-resolvers, 3 debug-label installers + 3 destructors, 3 SerializeToArray thunks) |
| FVA functions we chose to skip pending future need | 2 (Hook B pattern resolves, Phase C aux mirrors) |

## 7. Open re-audit items (feeding into workflow wrb9k1fu0)

1. **Phase C aux mirrors** — are qword_7FFBE8234CC8 / qword_7FFBE8234CD0 read anywhere?  If yes → port.  If no → confirm skip.
2. **Phase B state read** — is byte_7FFBE823A9A0 consumed by anything?  Same decision framework.
3. **Update-proofing** — enumerate every hard-coded literal that would need to change on a client.dll bump.  Consolidate into `version_manifest.h`.
4. **Module snapshots** — plan for a versioned manifest recording MD5/RVA fingerprints so we detect drift on inject.

All 4 items are being investigated by the running verification workflow.
