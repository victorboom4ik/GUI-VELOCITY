# Hook C — `MessageLite::SerializeToArray` chokepoint deep dive

**Target CS2 function (OLD client.dll build):**

* RVA `0x1189930` → `sub_181189930`
* Size **295 bytes** (0x127)
* Prototype:
  ```cpp
  char __fastcall SerializeToArray(google::protobuf::MessageLite* self,
                                     void* stream,
                                     int   max_size);
  ```
* First 30 bytes (verified via live `db` in `mydbg`):
  ```
  E9 1E 76 E6 FE  55 56 57 48 81 EC 90 00 00 00 …
  ```
  The `E9` is the active MinHook `jmp rel32` → trampoline gate.

**FVA-side handler:** `sub_7FFBE80C9B9C` (= FVA image base + `0x19B9C`).

## 1. Trigger conditions

Hook C fires on **every** call to `MessageLite::SerializeToArray` in CS2
client.dll — but **only mutates** when the message typename matches
`"CBaseUserCmdPB"`.

Verified typename filter (XOR-decoded from stack qword pairs):

| Encoded qword          | Key qword              | XOR result (bytes)                                       | ASCII                |
| ---------------------- | ---------------------- | -------------------------------------------------------- | -------------------- |
| `0xF6E0262244CDBA8E`   | `0x9393734737ACF8CD`   | `43 42 61 73 65 55 73 65`                                | `"CBaseUse"`         |
| `0x9F047512FCEAE7BC`   | `0x9F0437429887A4CE`   | `72 43 6D 64 50 42 00 00`                                | `"rCmdPB\0\0"`       |

Full: `"CBaseUserCmdPB"` (14 chars + 2 zero pads = 16 bytes = one YMM block).

Callers of `sub_181189930` in `client.dll` (4 code + 1 data xref):

* `sub_180AF5370` (size 0x23A) — serialize helper for
  `CNETMsg_SetConVar` / `CNETMsg_StringCmd` bulk-write path.
* `sub_180C4D050` (size 0x30F) — serialize helper invoked from the
  `CBaseUserCmdPB::` vftable.
* `sub_180ECCB40` (size 0x742) — large protobuf wrapper used by demo/
  replay writer.
* `sub_180F31590` (size 0x29D) — session-config serializer.

Of these, **only the `sub_180C4D050` path** carries `CBaseUserCmdPB`
messages — the other three are filtered out by the typename hash
check and passthrough to the original serializer unchanged.

## 2. Handler pseudocode (verified from IDA decomp of `sub_7FFBE80C9B9C`)

```cpp
char Hook_C(void* self, void* stream, int max_size)
{
    // Step 1 — lazy resolve original pointer via TLS-guarded once-init.
    //          FVA globals: dword_7FFBE823CC08 (guard), qword_7FFBE823CBE0 (orig).
    if (!qword_7FFBE823CBE0)
        qword_7FFBE823CBE0 = qword_7FFBE823C430;   // saved by MinHook

    // Step 2 — call self->vtable[+120](self, out_std_string) = GetTypeName().
    //          `v7` receives std::string* whose bytes are the typename.
    std::string tmp;
    auto vt = *(void***)self;
    reinterpret_cast<void(*)(void*, std::string*)>(vt[120/8])(self, &tmp);

    // Step 3 — XOR-decode expected hash from stack qword pair.
    //          Two 16-byte YMM lanes: encoded[2] and key[2].
    //          Result = fnv1a("CBaseUserCmdPB").
    __m128i enc = _mm_set_epi64x(0x9F047512FCEAE7BC, 0xF6E0262244CDBA8E);
    __m128i key = _mm_set_epi64x(0x9F0437429887A4CE, 0x9393734737ACF8CD);
    __m128i dec = _mm_xor_si128(enc, key);
    // dec now holds the ASCII "CBaseUserCmdPB\0\0"

    // Step 4 — compute FNV-1a hash over the runtime typename.
    uint64_t actual_hash = fnv1a(tmp);
    uint64_t expected    = fnv1a(std::string_view(reinterpret_cast<char*>(&dec), 14));

    // Step 5 — if mismatch → passthrough.
    if (actual_hash != expected || self == &unk_7FFBE8234C90)
        return qword_7FFBE823CBE0(self, stream, max_size);

    // Step 6 — copy self into scratch buffer (unk_7FFBE8234C90), Clear it,
    //          then mutate the scratch fields with our injected policy.
    CBaseUserCmdPB_CopyFrom(&unk_7FFBE8234C90, self);
    CBaseUserCmdPB_Clear   (&unk_7FFBE8234C90);   // sub_7FFBE80F9250
    apply_pending_mutation (&unk_7FFBE8234C90);

    // Step 7 — restore the mutated fields back onto `self` (in-place patch,
    //          so the outgoing serialised bytes correspond to our injection).
    CBaseUserCmdPB_MergeFrom(self, &unk_7FFBE8234C90);   // sub_7FFBE80FA2E4

    // Step 8 — call original.
    return qword_7FFBE823CBE0(self, stream, max_size);
}
```

## 3. Fields mutated in CBaseUserCmdPB

All offsets are as documented in `src/valve/cbaseusercmdpb_layout.h`,
verified against the Clear function's CHECK strings:

| Offset | Field                          | Typical mutation                       |
| ------ | ------------------------------ | -------------------------------------- |
| +0x30  | `buttons_pb`                   | OR-mask attack/jump/reload buttons     |
| +0x38  | `viewangles`                   | Overwrite pitch/yaw with rage-target   |
| +0x40  | `execution_notes`              | Rarely touched — spoof reason logs     |
| +0x50  | `forwardmove`                  | Auto-strafe / bhop                     |
| +0x54  | `leftmove`                     | Auto-strafe                            |
| +0x58  | `upmove`                       | Force jump                             |
| +0x64  | `random_seed`                  | Deterministic seed for no-spread       |

The `has_bits` word (+0x10) is OR-updated to declare that our written
fields are populated (protobuf's field-presence tracking).

## 4. Input-history spoof — the VAC correlation bypass

The critical trick sits inside `CSGOUserCmdPB` (the outer wrapper).  When
CS2 fires a shot, the client is expected to include a full
`CSGOInputHistoryEntryPB` whose `target_head_pos_check_`,
`target_abs_pos_check_`, `target_abs_ang_check_` triple **matches** the
server-observed target position at the shot tick.  A mismatch there is
the primary VACnet signature for "aim was falsified between build and
send".

FVA fixes this by fabricating a history entry whose target-check vectors
match the mutated viewangles — done in
`src/features/rage/input_history_spoof.cpp`:

```cpp
history_entry.view_angles          = { fake_pitch, fake_yaw };
history_entry.shoot_position       = local_eye;
history_entry.target_head_pos_check = target_head_bone_world;   // from bone matrix
history_entry.target_abs_pos_check  = target_origin_world;
history_entry.target_abs_ang_check  = target_view_angles;
history_entry.target_ent_index      = target_ent_index;
history_entry.render_tick_count    = last_render_tick;
history_entry.player_tick_count    = last_player_tick;
```

Then:

```cpp
csgo_cmd->attack1_start_history_index = new_history_index;
```

so the server knows which history slot describes the shot.

## 5. Why hook the serializer and not `CreateMove` alone

CS2 recomputes several derived fields between `CreateMove` and
`SerializeToArray`:

* `CBaseUserCmdPB::move_crc` (integrity checksum over subtick moves,
  forwardmove/leftmove/upmove, viewangles).
* `CSGOUserCmdPB::input_history[].render_tick_count` / `_fraction`
  updated on every frame that overlaps the tick.
* Server-angle adjustments applied by the client's own smoothing pass.

Mutating in `CreateMove` alone would either break `move_crc` (server
rejects the cmd outright) or lose the aim as soon as the smoothing pass
runs.  Mutating in `SerializeToArray` means we edit the very last bytes
that will hit the wire — nothing else touches them after us.

That's why FVA layers `CreateMove` (staging) → `SerializeToArray`
(final commit).

## 6. Verification stages (as requested by user)

| # | Stage       | How this reconstruction addresses it                             |
| - | ----------- | ---------------------------------------------------------------- |
| 1 | Dump        | Base binary `FuckVacAgain.dll` + `FuckVacAgain_rebuild.exe`.     |
| 2 | Runtime     | Live memory verified via `mydbg(1).exe` + Cheat Engine MCP.      |
| 3 | Devirt      | Skeleton project already ships `FuckVacV2_devirtualized.dll`.    |
| 4 | Unpacker    | Skeleton project's `tools/devirtualize.ps1`.                     |
| 5 | CE+IDA+client.dll | Cross-referenced via IDA sessions f464b09e + 9579d2c2.     |
| 6 | Hooks-on-hooks | Break-on-`schedule_mutation` from a helper DLL: attach a probe  DLL that calls `fva::hooks::schedule_mutation` inside a `MinHook::MH_CreateHook` around `fva::hooks::hook_body`, dump caller stack. |
| 7 | Recheck each | `sig_scan → resolved_addr → live `db`` — every hook target is  compared byte-for-byte at install-time.                          |
| 8 | Deobfuscation | `src/core/obfuscation.cpp` reproduces:  – 16-byte VPXOR pair (typename),  – 32-byte YMM XOR (pattern strings from Hook B),  – rolling-XOR (`decode_rolling_xor`) for MinHook error strings. |

## 7. Files in this reconstruction

```
reconstruction/
├── CMakeLists.txt
├── docs/
│   └── HOOK_C_DEEP_DIVE.md   (this file)
├── src/
│   ├── core/
│   │   ├── signature_scanner.{h,cpp}   ← FVA sub_7FFBE80DCB84 + sub_7FFBE80DCD0C
│   │   └── obfuscation.{h,cpp}         ← FNV-1a, VPXOR, rolling-XOR
│   ├── hooks/
│   │   ├── serialize_to_array_hook.{h,cpp}   ← Hook C body
│   │   ├── create_move_hook.{h,cpp}          ← Hook A layered detour
│   │   ├── level_init_hook.{h,cpp}           ← Hook B lazy resolver
│   │   └── hook_manager.{h,cpp}              ← FVA sub_7FFBE80CDAC8
│   ├── features/rage/
│   │   ├── rage_bot.{h,cpp}                  ← policy publisher
│   │   └── input_history_spoof.{h,cpp}       ← VAC correlation bypass
│   └── valve/
│       └── cbaseusercmdpb_layout.h           ← exact protobuf field offsets
```

Sits alongside the skeleton project `cs2 dll new/` — replace the
skeleton's empty `hooks/game_hooks.cpp` MinHook install stub with
`hook_manager::install_all()` from this reconstruction.

## 8. Cross-check with external SDKs

* **[SteamTracking/Protobufs](https://github.com/SteamTracking/Protobufs)**
  — `cs2/usercmd.proto` confirms every field name and wire-tag we use
  (buttons_pb, viewangles, subtick_moves, execution_notes,
  legacy_command_number, client_tick, forwardmove, leftmove, upmove,
  impulse, weaponselect, random_seed, mousedx, mousedy).
* **[neverlosecc/source2sdk](https://github.com/neverlosecc/source2sdk)**
  — provides `CCSPlayer_MovementServices` layout for the movement-side
  fields our hooks read (m_flStamina, m_vecVelocity) but doesn't touch
  the pb definitions themselves.
* **[a2x/cs2-dumper](https://github.com/a2x/cs2-dumper)**
  — the RVAs it publishes drift between builds; our reconstruction uses
  runtime pattern-scan (`fva::scanner`) instead so it survives patches
  in the same drift-band FVA does.
* **[cspatterns.dev](https://cspatterns.dev)** — `createmove`,
  `createnewsubtickmovestep`, `forcebuttonsdown`, `validateinput`
  patterns are stored obfuscated in the FVA `.rdata` at
  `0x7FFBE820A120..A600`; our scanner accepts these patterns verbatim.
