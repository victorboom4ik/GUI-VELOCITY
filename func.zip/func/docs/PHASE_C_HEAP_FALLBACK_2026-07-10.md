# phase_c heap fallback — 2026-07-10 15:11

## Что закрыто

**Task #40**: phase_c sig-scan fallback + arena allocator sig-scan + rebuild — DONE.

Финальный лог инжекта (`C:\vmp\fva_recon.log` @ 2026-07-10 15:10:44):

```
[fva_recon] modules: client=... engine2=... networksystem=... animationsystem=...
[fva_recon] scratch_serialize ready
[fva_recon] protobuf_alloc ready
[fva_recon] phase_c CInButtonStatePB::New: prologue mismatch → sig-scan fallback
[fva_recon] phase_c CInButtonStatePB::New: fallback sig-scan miss
[fva_recon] phase_c: sig-scan also missed — installing heap fallback
[fva_recon] phase_c CMsgQAngle::New: same story → heap fallback
[fva_recon] phase_c ready                                         ← НОВОЕ
[fva_recon] phase_b2 ready
[fva_recon] SKIP self_check (phase_c reported drift; ...)         ← used_heap_fallback() гейт корректно скипает
[fva_recon] Hook A/B/C targets resolved + prologues match
[fva_recon] install_all returned: 1
[fva_recon] hooks installed
[fva_recon][B] game_state: interface=00007FFF056E6A60
[fva_recon] game_state resolved: interface=...
[fva_recon] CSubtickMoveStep vtable @ 00007FFEDEB36670
[fva_recon] Arena allocator @ 00007FFEDE3E8F80
[fva_recon][H1] first tick self=... nSlot=0 bFinal=1
[fva_recon][B] subobj probe: interface+0x90C @ 00007FFF056E736C raw16=00 00 ... (menu state, sub-object пуст)
[fva_recon][H1] tick=1024 ... alt_original=103                    ← alt_symbol снят, Section-J ARMED
[fva_recon][H1] tick=2048 ... (тихо — user в меню)
...
[fva_recon][H1] tick=13312 ...
```

Клин, никаких crash-ов, все три хука активны, phase_c apply() работает через
HeapAlloc-blocks.

## Что изменилось в коде

| Файл | Изменение |
|------|-----------|
| `src/hooks/phase_c.cpp` | Добавлены `heap_new_button_state` (0x30, HeapAlloc) и `heap_new_qangle` (0x28) как последний fallback |
| `src/hooks/phase_c.cpp` | Добавлен `g_used_heap_fallback` atomic — drift-канарейка |
| `src/hooks/phase_c.cpp` | scan_for_new теперь диагностирует miss на первой попытке (раньше молча возвращал nullptr) |
| `src/hooks/phase_c.cpp` | init(): manifest → sig-scan → heap fallback (никогда не return false) |
| `src/hooks/phase_c.h` | Добавлен `used_heap_fallback()` accessor |
| `src/dllmain.cpp` | self_check-гейт переключен с `!ready()` на `!used_heap_fallback()` |
| `src/hooks/game_state_resolver.cpp` | `subobj_ptr()` helper с 2-level deref: `*(void**)(interface+0x90C)`; fallback на embedded `interface+0x90C` если не pointer |
| `src/hooks/game_state_resolver.cpp` | `field_ptr()` для fire_flag / subtick_counter теперь идет через subobj_ptr |
| `src/hooks/create_move_hook.cpp` | Per-tick fire_flag + subtick_counter watchers с first-seen baseline (нет sentinel-шума на tick 52) |

## Что нужно, чтобы увидеть Section-J fire path в live

1. **User заходит в match** (текущий тест запускается через `+map de_dust2 +sv_cheats 1
   +mp_warmup_end 1`, что грузит карту но остается в меню/spectator без spawn).
2. **jointeam 2/3 + spawn** — через UI или консоль cs2.
3. **Нажать +attack** — тогда:
   - `fire_flag: 0 -> 1 (+ATTACK PRESSED)` появится в логе
   - `subtick_counter` начнет менять значения (game state регистрирует subtick clicks)
   - Section-J code path в create_move_hook.cpp (line 323, `if (alt_original != 0)`)
     станет наблюдаемым через phase_b2 логи (если добавить)

`alt_original` уже non-zero (103, 177, 223 — CS2-side random-inited per session),
значит Section-J **armed** — просто ждет non-empty raw_cmd_root с реальным
child.subtick_moves чтобы отработать.

## Оставшийся drift

Только phase_c CInButtonStatePB::New / CMsgQAngle::New (buttons_cache/angles_cache
теперь через HeapAlloc — не влияет на wire, поскольку эти кэши локальные приватные
буферы reconstruction'а которые никто не читает).

Prologue `48 89 5C 24 08 57 48 83 EC 20 48 8B F9 33 D2` не найден нигде в
client.dll — CS2 protobuf compiler для этого билда генерирует другую форму
`T::New(Arena*)`. Не блокирует функционал, но для полного parity с CS2's own
protobuf machinery в будущем можно добавить arena-caller heuristic
(`BA 30 00 00 00 ... E8 <rel32→arena_allocator>` walk-back to function entry).

## Reproducibility

```powershell
cd C:\vmp\implementation_theory\reconstruction
cmake --build build --config Release
Remove-Item C:\vmp\fva_recon.log -EA SilentlyContinue
& C:\Users\sshunko\source\repos\MyDriver23\scripts\inject_vaclivebypass.ps1 `
    -DllPath C:\vmp\implementation_theory\reconstruction\build\Release\fva_recon.dll `
    -CS2Args '-insecure -nojoy +map de_dust2 +sv_cheats 1 +mp_warmup_end 1'
Get-Content C:\vmp\fva_recon.log -Wait   # tail live
```
