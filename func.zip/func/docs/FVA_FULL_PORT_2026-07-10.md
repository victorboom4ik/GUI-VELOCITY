# Полный порт FVA Section-J — 2026-07-10 16:18

Все ключевые функции расшифрованы через IDA MCP из
`C:\vmp\FuckVacAgain.dll.i64` (session ea21efe4) и
`C:\vmp\fva_livedump\FuckVacAgain_rebuild.exe.i64` (session 33ec1c00).

## FVA function chain

| Sub | Роль |
|-----|------|
| `sub_7FFBE80C9D8C` | Handler A (0x14DC bytes) — не декомпилируется (слишком сложный); анализ через disasm |
| `sub_7FFBE80C9614` | Thunk — jmp `sub_7FFBE82E8C32` |
| `sub_7FFBE82E8C32` | **Real Section-J emitter** — цикл по remaining_slots, alloc+attach+append |
| `sub_7FFBE80C95B4` | Delta interpolator — fraction = (iter+1)/remaining, blend engine_view + fraction*delta |
| `sub_7FFBE80CB268` | RepeatedPtrField::Get(index) с bounds check |
| `sub_7FFBE80CB348` | AddAllocated slow path (arena-copy + grow) |
| `sub_7FFBE8101CC0` | Arena consistency: если arenas разные, alloc в target arena через vtable[+16], копия через vtable[+48] |
| `sub_7FFBE80DCB84` | Sig scanner — parses IDA-style hex pattern → bytes+mask → calls `sub_7FFBE80DCD0C` |
| `sub_7FFBE80DCD0C` | Actual PE-aware byte scanner |
| `sub_7FFBE80FABFC` | CSubtickMoveStep::NewInArena — 56 bytes, FVA vtable `unk_7FFBE8218F00` (не используется Handler A) |
| `sub_7FFBE80F6FEC` | CMsgQAngle::NewInArena — 40 bytes, FVA vtable `unk_7FFBE8218638` (не используется Handler A) |
| `sub_7FFBE80FAD0C` | CBaseUserCmdPB::NewInArena — 136 bytes, FVA vtable `unk_7FFBE8218C88` |
| `sub_7FFBE8103070` | Protobuf arena AllocateAligned wrapper |
| `sub_7FFBE80DC5A8` | Plain malloc wrapper |
| `sub_7FFBE8101EA0` | RepeatedPtrField::AddAllocated (используется MergeFromCoded, не Section-J) |
| `sub_7FFBE8102020` | RepeatedPtrField::Reserve/Grow |

## Как FVA обходит vtable-stamp проблему

FVA НЕ использует собственный vtable в Section-J. Она:

1. Сиг-сканит client.dll паттерном
   ```
   48 89 5C 24 ? 57 48 83 EC ? 33 DB 48 8B F9 48 85 C9 75 ? B9 ? ? ? ? E8
   ```
   Кэширует адрес в `qword_7FFBE823A9C0` (CS2's CSubtickMoveStep::New)
   и `qword_7FFBE823A9A8` (CS2's CMsgQAngle::New) через TLS-guarded init
   `sub_7FFBE819EFB0`/`sub_7FFBE819EF40`.

2. **Вызывает** CS2's функцию — CS2 сам стампит правильный vtable,
   metadata, arena. FVA только заполняет float поля и has_bits.

3. Insert в rep — inline swap-safe AddAllocated:
   ```c
   if (subs->arena == step->arena
       && subs->rep != nullptr
       && subs->rep->allocated_size < subs->total_size)
   {
       if (subs->current_size < subs->rep->allocated_size)
           subs->rep->elements[allocated_size] = subs->rep->elements[current_size];
       subs->rep->elements[current_size++] = new_step;
       subs->rep->allocated_size++;
   } else {
       sub_7FFBE80CB348(subs, new_step, step_arena, subs_arena);
   }
   ```

## Как мы обошли sig-scan проблему на нашем cs2 build

На нашем депоте sig-scan `48 89 5C 24 ? 57 48 83 EC ? 33 DB ...` матчит
только ОДНУ функцию (CBaseUserCmdPB::New) — CInButtonStatePB/CMsgQAngle/
CSubtickMoveStep::New имеют другой prologue (Valve компилятор).

**Наше решение**: extract vtable из ЖИВЫХ CS2 messages.

- `g_csubtick_vtable` ← copy from `subs->rep->elements[0]->vtable`
  (любая существующая CS2-emitted subtick step)
- `g_cmsgqangle_vtable` ← copy from `pb->viewangles->vtable`

Live-verified 2026-07-10 16:16:
- CSubtickMoveStep vtable @ **0x00007FFEDEBBE028** (NE `0x00007FFEDEB36670`
  который находил старый sig-scan → доказательство что sig ловил не тот)
- CMsgQAngle vtable @ **0x00007FFEDEB90820**

## Delta interpolator (sub_7FFBE80C95B4)

Точный algo:
```c
sub_7FFBE80C95B4(dst, engine_view, delta_buf, iter, remaining_slots) {
    fraction = float(iter + 1) / float(remaining_slots);
    dst[0]  = engine_view[0] + fraction * delta_buf[0];  // pitch
    dst[4]  = engine_view[4] + fraction * delta_buf[4];  // yaw
    dst[8]  = engine_view[8] + fraction * delta_buf[8];  // roll
    dst[12] = 0.0f          + fraction * const_82190BC;  // "when" fraction W
    return dst;
}
```

Так FVA спреды спуф по remaining_slots subticks с постепенно
нарастающими deltas и разными `when` timestamps — сервер видит
плавное вращение через несколько subticks вместо одного скачка.

## Реализация в phase_b2.cpp

Полная имплементация FVA Section-J emitter в `append_step`:

```cpp
if (!subs->rep) return false;
if (subs->current_size >= 16) return false;
if (subs->rep->allocated_size >= subs->total_size) return false;

void* arena = subs->arena;
if (!arena) return false;   // ← BLOCKER (см. ниже)

CSubtickMoveStep* step = alloc_and_init_step(arena);
if (!step) return false;

CMsgQAngle* qangle = alloc_and_init_qangle(nullptr);
if (!qangle) return false;

qangle->x = pitch_delta;
qangle->y = yaw_delta;
qangle->z = 0.0f;
qangle->has_bits |= 0x7;   // X|Y|Z

// FVA writes CMsgQAngle* at step+0x18 (extended CSubtickMoveStep layout)
*(void**)(step + 0x18) = qangle;

step->pitch_delta = pitch_delta;
step->yaw_delta   = yaw_delta;
step->when        = 1.0f;
step->has_bits   |= WHEN | PITCH_DELTA | YAW_DELTA;

// Inline swap-safe AddAllocated:
if (subs->current_size < subs->rep->allocated_size) {
    subs->rep->elements[subs->rep->allocated_size]
        = subs->rep->elements[subs->current_size];
}
subs->rep->elements[subs->current_size] = step;
subs->current_size    += 1;
subs->rep->allocated_size += 1;
return true;
```

Вызов `try_cache_vtables(pb, subs)` идёт в начале `apply()` — идемпотентно.

## Финальный блокер — arena=0 на этом depot

На каждом tick: `raw->arena_word = 0`, `subs->arena = 0`. Ни одна
protobuf arena не доступна.

Protobuf Rep трактует не-arena elements как OWNED → на destruction
вызовет `delete elements[i]`. Наш HeapAlloc-ed block не delete-
compatible → CRT heap corruption → crash через ~10-20 s.

**Проверено live 2026-07-10 16:16**: vtables cached correctly,
apply#1 succeeded (post_subs=3 (+1) appended=1), cs2 crashed ~11 s
later. При скипе append (arena=0 → return false) — 30+ секунд стабильно.

## Что закрывает финальный блокер

Три пути:

1. **Sig-scan CS2's operator delete** (или protobuf::internal::GenericTypeHandler::Delete)
   и использовать его для наших alloc'ов. CS2's Rep на cleanup вызовет
   тот же delete → компатибельно.

2. **Найти не-null arena выше по chain**. `raw->arena_word` имеет tag bits
   (`&1` = tagged pointer, deref для настоящего arena). Возможно FVA
   handles этот случай где-то, что мы не заметили.

3. **Reverse Rep's ownership tag**. Protobuf иногда использует high bit
   или low bit pointer'а как "not owned" маркер. Если найти этот механизм,
   можно marks наш HeapAlloc'd block как "external" → Rep не будет delete.

## Live diagnostic evidence

С последнего run (2026-07-10 16:18, cs2 alive 30s+):
```
[fva_recon][B2] cached CS2 CSubtickMoveStep vtable @ 00007FFEDEBBE028 from live entry
[fva_recon][B2] cached CS2 CMsgQAngle vtable @ 00007FFEDEB90820 from pb->viewangles
[fva_recon][B2] apply#1..N EXIT ... appended=0 (skipped: arena=0)
```

Vtable caching работает. Append skipping работает (arena=0 gate).
Готовы к arena resolution как только откроем один из 3 путей выше.
