# Depot Update Playbook — как пере-снять offsets когда cs2 обновится

Всё что нужно чтобы за 30 минут переснять всё для нового депота.

## 0. Baseline snapshot текущего депота

Каждый заведомо-рабочий депот сохраняется в
`depot_snapshots/depot_<BUILD>_<DATE>/` со следующим content:
- `client.dll` (бинарь целиком)
- `client.dll.md5` — MD5 hash
- `client.dll.stat` — size + mtime
- `engine2.dll`, `networksystem.dll`, `animationsystem.dll`, `tier0.dll`
- `cs2_dumper_output/` — весь дамп от cs2-dumper

Snapshot нужен чтобы после обновления сравнить бинарник и найти
"переехавшие" функции через diff.

## 1. Проверить действительно ли что-то изменилось

```bash
cd /c/vmp/implementation_theory/reconstruction/depot_snapshots
NEW_MD5=$(md5sum "/d/SteamLibrary/steamapps/common/Counter-Strike Global Offensive/game/csgo/bin/win64/client.dll" | cut -d' ' -f1)
OLD_MD5=$(cat depot_14167_2026-07-10/client.dll.md5 | cut -d' ' -f1)
[ "$NEW_MD5" = "$OLD_MD5" ] && echo "SAME BUILD, ничего делать не надо" || echo "NEW BUILD $NEW_MD5, продолжай"
```

Если MD5 совпал — новый билд идентичен, ничего делать не нужно.

## 2. Снапшот нового билда

```bash
BUILD=<new_build_number>  # смотри в cs2-dumper info.json после запуска
DATE=$(date +%Y-%m-%d)
mkdir -p depot_snapshots/depot_${BUILD}_${DATE}
cd depot_snapshots/depot_${BUILD}_${DATE}
cp "/d/SteamLibrary/.../client.dll" ./
md5sum ./client.dll > client.dll.md5
```

## 3. Запустить cs2-dumper для новых interface offsets

```bash
cd /c/vmp/cs_dumper
./cs2-dumper.exe   # cs2 должна быть RUNNING в этот момент
cp -r output/ ../implementation_theory/reconstruction/depot_snapshots/depot_${BUILD}_${DATE}/cs2_dumper_output/
```

`interfaces.json` даст все Source2Client*/GameResourceService*/etc.
адреса которые могут пригодиться.

## 4. Открыть новый client.dll в IDA MCP

```
mcp__plugin_ida-pro_idalib__idb_open
  input_path = D:\SteamLibrary\...\client.dll
  mode = force_headless
  idle_ttl_sec = 3600
```

Запомнить `session_id` — будет нужен для всех последующих запросов.

## 5. Найти T::New RVAs через RTTI (**НАДЁЖНО**)

Каждый protobuf T::New имеет unique RTTI ref. Поиск:

```
search_text pattern = "?AVCSGOInputHistoryEntryPB@@"
```

Найдёт RTTI descriptor + все xref'ы. Один из них будет в функции
```
lea r8, ??_R0?AVCSGOInputHistoryEntryPB@@@8   ← this
mov edx, 78h                                    ← size marker (0x78 = 120 bytes)
call sub_arena_alloc
```

Это тело `T::New(Arena*)`. Функция начинается на 0x41 байт выше:
```
48 89 5C 24 10 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 75 XX B9 <SIZE> 00 00 00 E8 ...
```

**Точный алгоритм**:
1. `search_text "?AVCSGOInputHistoryEntryPB@@"` → находит RTTI xrefs
2. Найти xref в теле `sub_XXXXXXXX` (не в vtable, не в data)
3. Функция начинается ~0x41 байт до xref, ищи prologue `48 89 5C 24 10 57`
4. Записать RVA — это `new_maybe_arena_csgoinputhistoryentrypb`

Аналогично для:
- `?AVCMsgQAngle@@` → `new_maybe_arena_cmsgqangle`
- `?AVCSubtickMoveStep@@` → `new_maybe_arena_csubtickmovestep`
- `?AVCBaseUserCmdPB@@` → `new_maybe_arena_cbaseusercmdpb`

## 6. Найти vtable RVAs

```
search_text pattern = "??_7CSGOInputHistoryEntryPB@@6B@"
```

Первый hit — vtable в .rdata. Взять его RVA → `vtable_csgoinputhistoryentrypb`.

Аналогично для `??_7CSubtickMoveStep@@6B@`, `??_7CMsgQAngle@@6B@` и т.д.

## 7. Найти hook targets

### CreateMove-inner (Hook A target — сложный)
Через UC forum pattern или FVA disasm.
Наш prologue `85 D2 0F 85 XX XX XX XX`.
На новом билде может дрейфануть — искать xref от известного вокрестного
кода (типа sub_180AE1DE0 или sub_180BDB8A0).

### CreateMove-outer
```
find_bytes "48 8B C4 4C 89 40 ?? 48 89 48 ?? 55 53 41 54"
```

### LevelInit
```
find_bytes "48 89 74 24 ?? 57 48 83 EC ?? 48 8B 0D ?? ?? ?? ?? 48 8B FA"
```

### SerializePartialToArray (Hook C)
Ищи xref в CBaseUserCmdPB serialize path.

## 8. Найти tier0 imports

```
imports_query filter = "MemAlloc"
```

Возвращает IAT offsets для MemAlloc_AllocFunc, MemAlloc_FreeFunc и т.д.
Использовать `GetProcAddress(GetModuleHandle("tier0.dll"), "MemAlloc_AllocFunc")`
на runtime — не нужны offsets.

## 9. Обновить version_manifest.h

Замени соответствующие константы в `known_rva` namespace:

```cpp
inline constexpr std::uintptr_t new_maybe_arena_csgoinputhistoryentrypb = 0xNEW_RVA;
inline constexpr std::uintptr_t vtable_csgoinputhistoryentrypb          = 0xNEW_RVA;
inline constexpr std::uintptr_t hook_a_target                            = 0xNEW_RVA;
// ...
```

## 10. Обновить `resolve_cs2_*_new()` в phase_b2.cpp

Fingerprint check остаётся тот же (первые 8 байт prologue не меняются
между T::New функциями). Меняем ТОЛЬКО `k_known_rva`.

## 11. Rebuild + inject + verify

```powershell
cd C:\vmp\implementation_theory\reconstruction
cmake --build build --config Release
Remove-Item C:\vmp\fva_recon.log -EA SilentlyContinue
& C:\Users\sshunko\source\repos\MyDriver23\scripts\inject_vaclivebypass.ps1 `
     -DllPath C:\vmp\implementation_theory\reconstruction\build\Release\fva_recon.dll `
     -CS2Args '-insecure -nojoy +sv_cheats 1'
```

**Ждать 30 секунд. Проверить лог:**
- `Hook A/B/C target=` — все три installed
- `resolved CS2 CSGOInputHistoryEntryPB::New @ ... [known-RVA hit]` — успешно resolved
- `resolved CS2 CMsgQAngle::New @ ... [known-RVA hit]`
- `game_state resolved: interface=`
- SectionJ fired + apply# EXIT lines

**Если `[sig fallback — may be WRONG]` в логе** — hardcoded RVA неверный.
Вернуться к шагу 5.

## 12. Live in-match verification

Зайти в CS2, зайти в match, стрелять. Проверить что fire_flag detection
работает (log покажет `pb->buttons_pb` transitions).

## 13. Обновить documentation

- `docs/MASTER_MAPPING_<DATE>.md` — новая master table
- `docs/CS2_LAYOUT_TRUTH_<DATE>.md` — обновить offsets если изменились
- Обновить `depot_snapshots/` README с новым build number

## Верификация от 2026-07-10 (baseline)

Все следующие ✅ verified на depot 14167:
- CSGOInputHistoryEntryPB::New @ RVA 0x742730 → **known-RVA hit**
- CMsgQAngle::New @ RVA 0x6840F0 → **known-RVA hit**
- Live vtable extraction = 0x1A1E028 (matches RTTI-derived RVA)
- 13 successful appends в Rep, cs2 alive 276+ секунд no crash
- 98000+ apply calls per session

## Быстрая шпаргалка (для будущих self'ов)

```
CS2 patterns    → find_bytes или find_regex
CS2 types       → search_text "CClassName" + follow RTTI
CS2 imports     → imports_query filter="MemAlloc"
CS2 vtable      → search_text "??_7CClassName@@6B@"
CS2 RTTI        → search_text "?AVCClassName@@"

Fingerprint для protobuf T::New (все идентичны первые 8 байт):
  48 89 5C 24 10 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 ...
Дифференциация: mov ecx, imm32 на offset +0x14 → размер экземпляра

Hardcoded-RVA fallback pattern (см. src/hooks/phase_b2.cpp):
  1. Читать первые 8 байт по known_rva
  2. Сравнить с fingerprint
  3. Match → use hardcoded RVA (авторитетно)
  4. Mismatch → sig-scan (может дать WRONG type — залогируй warning)
```
