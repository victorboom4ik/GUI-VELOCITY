# CS2 layout TRUTH — 2026-07-10 16:47

Через IDA MCP на cs2 client.dll (session a739d650) окончательно расшифрован
истинный layout. Все ПРЕДЫДУЩИЕ доки ошибочно называли input_history как
subtick_moves — они это ОДНО И ТО ЖЕ поле, просто мы неверно его именовали.

## Ключевое открытие

`raw` (CUserCmdBaseHost<CSGOUserCmdPB>) обёртка над **CSGOUserCmdPB**,
не CBaseUserCmdPB. Поле по offset `raw+0x28` — это
`CSGOUserCmdPB.input_history` (RepeatedPtrField<**CSGOInputHistoryEntryPB**>),
не `CBaseUserCmdPB.subtick_moves`.

### Доказательство:
- Live-extracted vtable: `0x00007FFEDEBBE028`
- Session client.dll base: `0x00007FFEDD1A0000`
- Difference (RVA): `0x1A1E028`
- IDA CSGOInputHistoryEntryPB vtable RVA: `0x181A1E028 - 0x180000000 = 0x1A1E028` ✅ **МАТЧ**

## CS2 functions — comprehensive mapping (IDA session a739d650)

| Функция | RVA | Size | Sig-scan pattern (unique size marker) |
|---------|-----|------|--------------------------------------|
| CBaseUserCmdPB::New | 0x4B21E0 | 136 (0x88) | `48 89 5C 24 ? 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 75 ? B9 88 00 00 00 E8` |
| CSubtickMoveStep::New | 0x4B22D0 | 56 (0x38) | `48 89 5C 24 ? 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 75 ? B9 38 00 00 00 E8` |
| CSGOInputHistoryEntryPB::New | 0x742730 | **120 (0x78)** ← правильный | `48 89 5C 24 ? 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 75 ? B9 78 00 00 00 E8` |
| CMsgQAngle::New | 0x6840F0 | 40 (0x28) | `48 89 5C 24 ? 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 75 ? B9 28 00 00 00 E8` |
| MemAlloc_AllocFunc (via tier0) | via GetProcAddress | — | Import from `tier0.dll` |
| MemAlloc_FreeFunc (via tier0) | via GetProcAddress | — | Import from `tier0.dll` |
| sub_180B931D0 (heap alloc) | 0xB931D0 | — | Wrapped MemAlloc_AllocFunc |
| sub_180B93230 (heap free) | 0xB93230 | — | Wrapped MemAlloc_FreeFunc |

## Vtable RVAs

| Class | vtable RVA |
|---|---|
| CBaseUserCmdPB | тбд (sub_1804B21E0 refs) |
| CSubtickMoveStep | 0x1995608 |
| CMsgQAngle | 0x18Bxxxx (sub_180680240) |
| CSGOInputHistoryEntryPB | **0x1A1E028** ← это то что мы кэшили |
| CSGOUserCmdPB | тбд (sub_180742670) |

## CSGOInputHistoryEntryPB layout (from user's proto + sub_1807429B0 init)

Init function `sub_1807429B0(mem, arena, tagged)` инициализирует:
- +0x00 = vftable (0x1A1E028)
- +0x08 = arena | (tagged ? 2 : 0)
- +0x10 = 0 (has_bits + cached_size)
- +0x18 = 0 (view_angles CMsgQAngle* ← FVA writes qangle here!)
- +0x20 = 0 (cl_interp CSGOInterpolationInfoPB_CL*)
- +0x28 = 0 (sv_interp0)
- +0x30 = 0 (sv_interp1)
- +0x38 = 0 (player_interp)
- +0x40 = 0 (shoot_position CMsgVector*)
- +0x48 = 0 (target_head_pos_check)
- +0x50 = 0 (target_abs_pos_check)
- +0x58 = 0 (target_abs_ang_check CMsgQAngle*)
- +0x60 = 0 (render_tick_count int32) ← FVA writes button here!
- +0x64 = 0 (render_tick_fraction float) ← FVA writes when here!
- +0x68 = 0 (player_tick_count) ← FVA writes 0 here!
- +0x70 = 0 (frame_number)
- +0x74 = -1 (target_ent_index — inited to -1)

**Total size: 120 bytes**. Confirms sub_180742730 = CSGOInputHistoryEntryPB::New.

## FVA Section-J emitter — истинный алгоритм (пересмотрено)

```c
// sub_7FFBE82E8C32 with fields at input_history entry:
for (iter = 0; iter < remaining_slots; ++iter) {
    interpolate_delta(&delta_buf, engine_view, delta, iter, remaining_slots);
    // xmm6/7/8/9 = interpolated pitch/yaw/roll/W

    // Allocate CSGOInputHistoryEntryPB (120 bytes) via CS2's New
    entry = cs2_input_history_entry_new(input_history_arena);
    if (!entry) continue;

    // Allocate CMsgQAngle (40 bytes) via CS2's New — heap allocation
    qangle = cs2_cmsgqangle_new(nullptr);
    if (!qangle) continue;

    // Fill qangle with x/y/z = pitch/yaw/roll
    qangle->x = xmm6;  qangle->y = xmm7;
    qangle->has_bits |= 0x7;  // X|Y|Z
    qangle->z = xmm8;

    // Arena consistency (sub_7FFBE8101CC0) — copy qangle into entry's arena if mismatch
    if (input_history_arena != qangle_arena)
        qangle = arena_copy(input_history_arena, qangle);

    // Attach qangle to entry.view_angles (offset +0x18)
    entry->view_angles = qangle;

    // Set additional entry fields
    entry->render_tick_count      = cached_render_tick;  // +0x60 = a5
    entry->render_tick_fraction   = xmm9;                // +0x64
    entry->player_tick_count      = 0;                   // +0x68
    entry->has_bits              |= 0x1E01;              // VIEW_ANGLES + RENDER_* + PLAYER_TICK_COUNT

    // Inline AddAllocated с swap-safe path
    if (subs->arena == entry->arena && subs->rep && subs->rep->allocated_size < subs->total_size) {
        if (subs->current_size < subs->rep->allocated_size)
            subs->rep->elements[subs->rep->allocated_size] = subs->rep->elements[subs->current_size];
        subs->rep->elements[subs->current_size++] = entry;
        subs->rep->allocated_size++;
    } else {
        sub_7FFBE80CB348(subs, entry, entry->arena, subs->arena);
    }
}
```

## Where our reconstruction was wrong

1. **Neверный тип**: allocate CSubtickMoveStep (56 bytes) вместо CSGOInputHistoryEntryPB (120 bytes) → Rep size mismatch → crash
2. **Неверные field writes**: писали step->pitch_delta at +0x30 (in 56-byte layout), а надо было писать в CSGOInputHistoryEntryPB structure с CMsgQAngle at +0x18
3. **Rep destructor** видит vtable в elements[i] (наш wrong vtable) → dispatches wrong destructor → crash

## Structure sizes summary

| Message | Size | Vtable RVA |
|---|---|---|
| CMsgQAngle | 40 | ~0x18Bxxxx |
| CSubtickMoveStep | 56 | 0x1995608 |
| CBaseUserCmdPB | 136 | (via sub_1804B21E0) |
| CSGOInputHistoryEntryPB | 120 | 0x1A1E028 |

## Allocator chain in CS2 client.dll

```
CS2's protobuf T::New(arena)
├── arena != nullptr → sub_18118BD40(arena, size, RTTI)  // Arena::AllocateAligned
└── arena == nullptr → sub_180B931D0(size)                // heap alloc
                                └── tier0::MemAlloc_AllocFunc(size)

CS2's protobuf ~T() destructor
├── vftable[0] = destructor
└── if (a2 & 1) → sub_180B93230(this, size)              // heap free
                                └── tier0::MemAlloc_FreeFunc(this)
```

**delete-compat**: любой блок аллоцированный через CS2's T::New освобождается
через MemAlloc_FreeFunc — тот же tier0 allocator. Match.

## Next actions

Task #50 (FUNDAMENTAL RE):
- [ ] Update phase_b2 to use CSGOInputHistoryEntryPB::New (RVA 0x742730)
- [ ] Update all offset writes to CSGOInputHistoryEntryPB layout (view_angles @ +0x18)
- [ ] Rebuild + inject + test with real spoof armed
