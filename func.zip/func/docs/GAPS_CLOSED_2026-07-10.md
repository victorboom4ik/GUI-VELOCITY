# Gap-closure report — 2026-07-10 ~15:00

Every open TODO in `reconstruction/src` is now fully specified.  Below is
what's in each, why it's still a "fill-me-in", and the exact
runtime/static observation needed to close it.

## TODO 1 — game_state_resolver.cpp: schema offset for alt_symbol hash

**Where**: `src/hooks/game_state_resolver.cpp:135` (in
`schema_offset_for_hash_stub`).

**What's needed**: the value FVA caches in `dword_7FFBE823A9CC` — i.e.
`sub_7FFBE80FB1C4(0xB6E8F068409FEF6C)` — for the current cs2 build.

**Why it's not yet filled**: closing this cleanly needs one of:
- one live cs2 tick with FVA loaded (we snapshot `dword_7FFBE823A9CC`
  via Python direct RPM), OR
- a full walk of CS2's schema tree mirroring FVA's
  `sub_7FFBE80FAEF0`, applied to CS2's schema base pointer.

**Static findings that pin this down**:

1. FVA's populator (`sub_7FFBE80FAEF0`) iterates a nested list at
   `schema_base + 1472 .. schema_base + 7616`, walking 24-byte outer nodes
   → linked-list inner nodes → 32-byte field descriptors.  For each field
   it reads `type_name` (u64 ptr @ inner+0x08) and `field_offset`
   (u32 @ desc+0x10), plus the parent class's name.

2. The hash key is exactly:

   ```
   key = std::string(type_name) + "->" + std::string(field_name);
   uint64_t h = 0xCBF29CE484222325;                            // FNV1a offset basis
   for (char c : key) h = 0x100000001B3ULL * (h ^ (uint8_t)c);
   ```

   The separator `"->"` is stored at `unk_7FFBE82190A8` in FVA
   (bytes `2D 3E 00`, verified).

3. Handler A calls `sub_7FFBE80FB1C4(0xB6E8F068409FEF6C)` at
   `sub_7FFBE80C9D8C + 0x1F7`.  The result is cached at
   `dword_7FFBE823A9CC`.  The subsequent read is
   `byte = *(uint8_t*)(qword_7FFBE823A988 + dword_7FFBE823A9CC)` — a
   1-byte field on the interface FVA's Handler B slot 2 resolved.

**How to close it**:

Option A — snapshot from a live run (recommended, one line):

```powershell
python3 -c "
import ctypes, ctypes.wintypes as wt
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[wt.DWORD,wt.BOOL,wt.DWORD]; k.OpenProcess.restype=wt.HANDLE
k.ReadProcessMemory.argtypes=[wt.HANDLE,wt.LPCVOID,wt.LPVOID,ctypes.c_size_t,ctypes.POINTER(ctypes.c_size_t)]
CS2_PID = <cs2 pid>
FVA_BASE = <fva base>                # runtime, e.g. 0x7FFEFA190000
h = k.OpenProcess(0x0410, False, CS2_PID)
buf = (ctypes.c_uint32*1)(); r = ctypes.c_size_t(0)
k.ReadProcessMemory(h, ctypes.c_void_p(FVA_BASE + 0x18A9CC), buf, 4, ctypes.byref(r))
print('schema offset =', hex(buf[0]))
"
```

Then paste the printed hex value into `schema_offset_for_hash_stub`:

```cpp
static std::int32_t schema_offset_for_hash_stub(std::uint64_t hash) noexcept {
    if (hash == fva::game_state::k_alt_symbol_field_hash) return 0x<offset>;
    return -1;
}
```

Option B — mirror the FVA populator in-process.  Write a full
schema-walker that iterates cs2's `CSchemaSystemV1` (whose base is
findable from client.dll's `libschemasystem` module) and materialises
the same `(FNV1a_of(type + "->" + field), offset)` table.  Bigger
lift; correctness only matters if we want the whole hash table
mirrored, not just the one field alt_symbol reads.

## TODO 2 — phase_b2.cpp: CSubtickMoveStep grow-when-full

**Where**: `src/hooks/phase_b2.cpp:73` (in `append_step`).

**What's needed**: an arena-aware `CSubtickMoveStep` allocator so that
when `subtick_moves.current_size == subtick_moves.rep->allocated_size`
we can create a fresh slot instead of no-oping.

**Static findings**:

FVA has its own allocator at RVA `0x60BFC` (`sub_7FFBE80FABFC` in
`fva_rebuild.i64`).  Verified layout — 56-byte instance:

| Offset | Size | Field |
|-------:|-----:|-------|
| 0x00   | 8    | vtable pointer (FVA's copy at `unk_7FFBE8218F00`) |
| 0x08   | 8    | arena pointer (nullable) |
| 0x10   | 8    | `has_bits` / `cached_size` packed |
| 0x18   | 8    | `button` (uint64) |
| 0x20   | 1    | `pressed` (bool) |
| 0x24   | 8    | `when` + `analog_forward_delta` packed |
| 0x2C   | 8    | `analog_left_delta` + `pitch_delta` packed |
| 0x34   | 4    | `yaw_delta` (float) |

Allocation strategy in FVA:
```c
mem = arena ? sub_7FFBE8103070(arena, 56, RTTI_CSubtickMoveStep)  // arena-aware
            : sub_7FFBE80DC5A8(56);                                // heap fallback
mem[0]   = &unk_7FFBE8218F00;                                       // vtable
mem[8]   = arena;
memset(mem+16, 0, 56-16);                                           // zero rest
```

**Why it's not yet filled**: FVA uses its own vtable pointer
(`unk_7FFBE8218F00` = FVA base + 0x168F00).  That address is only
meaningful inside the FVA module we're comparing against — we cannot
copy the qword and hand it to CS2 code, because CS2's own protobuf
runtime dispatches through vtables that live at CS2 addresses.

**How to close it**:

Sig-scan `client.dll` for `CSubtickMoveStep::default_instance()` — a
generated protobuf accessor that returns a pointer to the always-alive
`CSubtickMoveStep::_default_instance_` global; reading qword [ret+0]
gives the CS2-side vtable.  Cache that once at hook install (Hook B
detour is the natural place), then implement `append_step`'s growth
path as:

```cpp
if (subs->current_size >= subs->rep->allocated_size) {
    Arena* arena = /* propagate from caller CBaseUserCmdPB */;
    CSubtickMoveStep* fresh = alloc_subtick(arena);
    if (!fresh) return false;
    // grow rep vector (arena-realloc if needed)
    subs->rep->elements[subs->rep->allocated_size++] = fresh;
}
```

Impact of leaving it as-is: append_step is a no-op when the
subtick_moves field is at capacity, so on rare high-subtick ticks FVA
would have emitted an extra move-step that we skip.  This is not a
wire-corruption bug — the parent parser still sees a well-formed
message; we just under-emit.  Not required for baseline parity, only
for **exact** wire parity with FVA.

## Runtime observation attempts (2026-07-10)

Live capture of `dword_7FFBE823A9CC` was attempted three times today.
Each time cs2 crashed within seconds of FuckVacAgain.dll being injected
via `LdrLoadDll`.  The crashes are on `ntdll+0xAA83` in the loader
fastpath — an unrelated race between our LdrLoadDll shellcode and
FVA's VMP init.  A single successful window earlier in the day (13:22
– 13:50, cs2 PID 30464) proved the whole stack works — we just didn't
know at that point that `dword_7FFBE823A9CC` was the missing constant.
On the next stable window we'll snapshot it and close TODO 1
mechanically.

## Fully-closed hook parity table

| Item                                    | Status |
|-----------------------------------------|--------|
| Hook A body (create_move_hook.cpp)       | ✅ 1:1 |
| Hook A cvar suppress                     | ✅ 1:1 |
| Hook A client interface cache            | ✅ 1:1 |
| Hook A alt_symbol init/apply             | ✅ WIRED (populates from game_state_resolver — pending offset constant) |
| Hook A telemetry mirrors                 | ✅ 1:1 |
| Hook A phase_b2 subtick basic append     | ✅ 1:1 (pre-alloc case) |
| Hook A phase_b2 subtick grow             | ⚠  TODO 2 (documented; no wire corruption) |
| Hook A phase_c protobuf populate         | ✅ 1:1 |
| Hook A phase_d base64 anti-tamper trip   | ✅ 1:1 (diagnostic-only) |
| Hook A scratch_serialize                 | ✅ 1:1 |
| Hook B (level_init_hook.cpp)             | ✅ 1:1 |
| Hook B game_state resolver (sig+deref)   | ✅ NEW — this session |
| Hook C (serialize_to_array_hook.cpp)     | ✅ 1:1 |
| Hook C scratch capture direction         | ✅ 1:1 |
| Hook C self-recursion guard              | ✅ 1:1 |
| Hook D (animation)                       | ⏸ FVA's H4 slot is unpopulated, so we skip too |
</parameter>
