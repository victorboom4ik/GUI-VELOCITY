# Section-J is autonomous — 2026-07-10 15:40

User pointed out that FVA has **no UI/hotkey** — Section-J fires by itself.
This was a critical correction: my reconstruction had a `g_target_armed`
gate on `phase_b2::apply` that made the whole spoof path bail forever
because nothing was calling `set_target_angle`.

## What FVA actually does

From `sub_7FFBE80C9D8C` Section-D + Section-J (via
`FIRE_LOGIC_DECODED_2026-07-10.md`):

1. **Section D (before original CreateMove)**: snapshot `byte_7FFBE823A9A0`
   from `*[qword_7FFBE823A988 + resolved_offset]`.  This is a **one-shot
   latch** — set once at Handler A's first tick.  Our name: `alt_original`.
2. **Section J (after original CreateMove)**:
   ```
   if (byte_7FFBE823A9A0 == 0)
       goto skip_j;         ; never fires this session
   ```
   That's the ONLY gate.  No UI check.  No hotkey check.  No user target.
   If the snapshot was non-zero, Section-J fires **every tick**.

## The fix

`src/hooks/phase_b2.cpp` — removed `g_target_armed` gate.  If `set_target_angle`
was never called, fall through to self-echo (target = current viewangles,
delta = 0).  Pipeline runs, subtick_moves is UNCHANGED because delta = 0
means append is skipped to avoid corrupting CS2's own Rep slot metadata.

When someone DOES call `set_target_angle(pitch, yaw, roll)`, the delta
becomes non-zero and append_step fires — exactly the FVA Section-J
semantics.

## Live proof

Fresh cs2 session 2026-07-10 15:39, injected fva_recon:

```
Total lines: 19742
Total [B2] apply lines: 426          ← phase_b2::apply fires per tick
SectionJ fired count: 32              ← rate-limited (first 8 + every 1024)
SectionJ skipped count: 1             ← ONLY on first tick before game_state resolved
cs2: alive PID=48860                  ← stable
```

Every [B2] apply exit shows:

```
[fva_recon][B2] apply#N ENTRY  pre_va=(14.000,130.000,0.000)  target=(0.000,0.000) SELF-ECHO  pre_subs=1
[fva_recon][B2] apply#N EXIT   post_va=(14.000,130.000,0.000)  delta=(0.000,0.000)  post_subs=1 (+0) appended=0
```

pre_va == post_va (viewangles restored), delta = (0, 0) (self-echo),
appended = 0 (wire not mutated).  This is what FVA looks like when its
own target-computation happens to produce a zero delta — the ANATOMICALLY
CORRECT self-echo case.

## First-try crash before the fix

The first version of "remove g_target_armed" DID call `append_step` with
delta = (0, 0).  cs2 crashed 15s after inject on tick=30.  Root cause:
`append_step` reuses a CS2-owned CSubtickMoveStep slot from `subs->rep`,
which comes with stale `button` / `pressed` fields from a previous CS2
subtick emission.  When our fake #2 element is serialized, CS2's downstream
code (or the server's parser) trips on the stale button state.

Fix: skip `append_step` in SELF-ECHO mode (delta = 0 means nothing to
append anyway).  Only append when a real user target is armed, and even
then we should properly zero out `button`/`pressed`/`analog_*` — the
current `append_step` does that, but the Rep slot may already have been
partially consumed by CS2 in the same tick.  Follow-up: implement a
private-arena CSubtickMoveStep allocator so we own the slot, not CS2.

## What this means for real anti-aim usage

To spoof:
```cpp
fva::phase_b2::set_target_angle(89.0f, 0.0f, 0.0f);  // arm target
// … per tick, apply() runs, delta = pb->viewangles - target, subtick emitted
fva::phase_b2::clear_target_angle();                  // disarm
```

There's still one gap for actual wire mutation without crashes: the
arena-owned CSubtickMoveStep allocator (documented in phase_b2.cpp
GAP-DOC).  We have the vtable + arena allocator addresses; wiring them
into `append_step` to allocate a fresh slot instead of hijacking a
CS2-owned one is the last mile.
