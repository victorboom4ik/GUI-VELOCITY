# CS2 depot 14167 (2026-07-10) — mapping master

Verified через IDA MCP `client.dll` session `a739d650`,
cs2-dumper `C:\vmp\cs_dumper\output\` (build 14167, timestamp 2026-07-10 13:44),
и user-provided sig list (139 patterns, updated 09/07/2026).

## Верифицированные RVA нашего билда

### client.dll — hook targets

| Функция | RVA | Sig (verified в нашем build) |
|---|---|---|
| CreateMove (outer entry) | **0xC621D0** | `48 8B C4 4C 89 40 ? 48 89 48 ? 55 53 41 54` — user's CREATEMOVE_PATTERN |
| CreateMove-inner (наш Hook A / FVA target) | 0xACEF90 | `85 D2 0F 85 85` — Handler A entry |
| LevelInit | **0x396295** | `48 89 74 24 ? 57 48 83 EC ? 48 8B 0D ? ? ? ? 48 8B FA` — LEVELINIT_PATTERN |
| SerializePartialToArray (Hook C) | 0x1189930 | `48 89 5C 24 18 ...` |

### client.dll — CS2 protobuf T::New (для reconstruction append)

| Функция | RVA | Size | Sig (size marker `B9 XX`) |
|---|---|---|---|
| CBaseUserCmdPB::New | 0x4B21E0 | 136 | `48 89 5C 24 ? 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 75 ? B9 88 00 00 00 E8` |
| CSubtickMoveStep::New | 0x4B22D0 | 56 | `48 89 5C 24 ? 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 75 ? B9 38 00 00 00 E8` |
| CMsgQAngle::New | 0x6840F0 | 40 | `48 89 5C 24 ? 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 75 ? B9 28 00 00 00 E8` |
| **CSGOInputHistoryEntryPB::New** ← настоящая цель | **0x742730** | **120** | `48 89 5C 24 ? 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 75 ? B9 78 00 00 00 E8` |

**⚠ Проблема с sigs выше**: `B9 XX` не уникален — есть несколько 120-byte T::New.
Нужна disambiguation через RTTI ref (xref к `??_R0?AVCSGOInputHistoryEntryPB@@@8`).

### Vtable RVAs

| Class | vtable RVA |
|---|---|
| CSubtickMoveStep | 0x1995608 |
| **CSGOInputHistoryEntryPB** ← этот мы live-extract'или | **0x1A1E028** |
| CBaseUserCmdPB | (via sub_1804B21E0 refs) |

### Allocator chain (delete-compat)

```
CS2 T::New(arena=0) → sub_180B931D0 (heap alloc)
                    → tier0::MemAlloc_AllocFunc (imported)
CS2 ~T() destructor → sub_180B93230
                    → tier0::MemAlloc_FreeFunc
```

## Layout confirms (from CSGOInputHistoryEntryPB init sub_1807429B0)

```
+0x00: vftable (RVA 0x1A1E028)
+0x08: arena | tagged
+0x10: has_bits + cached_size
+0x18: view_angles CMsgQAngle*   ← FVA writes CMsgQAngle ptr here
+0x20: cl_interp
+0x28: sv_interp0
+0x30: sv_interp1
+0x38: player_interp
+0x40: shoot_position CMsgVector*
+0x48: target_head_pos_check
+0x50: target_abs_pos_check
+0x58: target_abs_ang_check CMsgQAngle*
+0x60: render_tick_count int32     ← FVA @+0x60 write
+0x64: render_tick_fraction float  ← FVA @+0x64 = xmm9 write
+0x68: player_tick_count int32     ← FVA @+0x68 = 0 write
+0x70: frame_number
+0x74: target_ent_index (inited -1)
```

**has_bits |= 0x1E01** setting:
- 0x1 VIEW_ANGLES + 0x200 RENDER_TICK_COUNT + 0x400 RENDER_TICK_FRACTION +
  0x800 PLAYER_TICK_COUNT + 0x1000 PLAYER_TICK_FRACTION

Всё совпадает — подтверждает CSGOInputHistoryEntryPB как истинную цель FVA.

## User's 139 patterns — key highlights для нас

| Pattern name | Наш RVA | Прим. |
|---|---|---|
| CREATEMOVE_PATTERN | 0xC621D0 | Outer entry — не FVA-target, но полезный reference |
| LEVELINIT_PATTERN | 0x396295 | Handler B target |
| CREATENEWSUBTICKMOVESTEP_PATTERN | (long chain) | Матчит блок из 4 T::New подряд — как FVA sig |
| FORCEBUTTONSDOWN_PATTERN | тбд | Для button state manipulation |
| OVERRIDEVIEW_PATTERN | тбд | Хук для camera |

## cs2-dumper interfaces (build 14167 — наш билд!)

client.dll ключевые:
- Source2Client002 @ 36945808 = 0x2340810
- Source2ClientPrediction001 @ 36967472 = 0x2345E30
- LegacyGameUI001 @ 34067600 = 0x207F450

engine2.dll:
- InputService_001 @ 9220352 = 0x8CA340
- GameResourceServiceClientV001 @ 6367904 = 0x612D20

## Session artifacts

- **client.dll IDA session**: `a739d650` (persistent, TTL 3600s) —
  `D:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\game\csgo\bin\win64\client.dll`
- **FVA original IDB**: `C:\vmp\FuckVacAgain.dll.i64` (session `ea21efe4`)
- **FVA rebuild IDB**: `C:\vmp\fva_livedump\FuckVacAgain_rebuild.exe.i64` (session `33ec1c00`)
- **cs2-dumper output**: `C:\vmp\cs_dumper\output\*.json` — build 14167

## Оставшиеся задачи для полного порта

1. **Disambiguate CSGOInputHistoryEntryPB::New sig** — либо через xref к
   RTTI descriptor, либо через фиксацию окружающих байт (обычно `RTTI Type
   Descriptor` referenced неподалёку)

2. **Loop remaining_slots iterations** — FVA делает N (обычно 4-8) subticks
   с fractional `when` для плавного спуфа

3. **sub_7FFBE80C95B4 interpolation** — blend engine_view + fraction*delta

4. **Pre-emit search + setter** на existing entries (sub_7FFBE8103A70)

5. **sub_7FFBE8101CC0 arena-copy** при arena mismatch (не критично т.к.
   arena всегда 0 на этом depot)

6. **has_bits |= 0x1E01** exact bits (VIEW_ANGLES + tick counters)

## Depot info

- **Depot**: 2347770 manifest 7169488960211596754 (rolled back via
  DepotDownloader `C:\tmp\DepotDownloader\ЗАПУСТИ-откат-CS2.cmd`)
- **client.dll MD5**: `b0fd08261be12cceb8e5636500e5a1d0`
- **Size**: 37272728 bytes (disk) / 41148416 (in-memory SizeOfImage)
- **Build**: 14167 (matches cs2-dumper output)

## Что сейчас в reconstruction активно (safe baseline)

- ✅ 3 hooks installed (Hook A/B/C) — MinHook trampolines
- ✅ Live vtable extraction from `subs->rep->elements[0]->vtable`
- ✅ chain_find_arena walk
- ✅ CSGOInputHistoryEntryPB::New sig-scanned (но wrong function due to
  ambiguity)
- ✅ CS2's ProtoNew resolve + isolation-test verified (128+ allocs no crash)
- ✅ Delta compute + wrap180
- ✅ SELF-ECHO delta=0 mode — wire byte-identical to CS2's own output
- ❌ append_step — no-op (returns false) — activation requires
  disambiguated sig + Rep-invariant reverse
