// ============================================================================
// game_state_resolver.cpp — fills the Hook B → fire_flag_probe gap.
//
// FVA's Hook B (LevelInit) runs THREE lazy sig-scans of client.dll (the ones
// that fill qword_7FFBE823A980 / A988 / A990 in the original binary).  The
// second of those — the one that fills qword_7FFBE823A988 — is what Hook A
// (create_move_hook.cpp) needs to populate `fire_flag_probe::g_target`.
//
// Static decode from `sub_7FFBE80C8E68 + 0x3F2` (mov cs:qword_7FFBE823A988, rax):
//
//   call sub_7FFBE80DCB84            ; sig-scan client.dll for the pattern
//                                     ;   "48 8B 0D ? ? ? ? 48 8D 54 24 ?"
//                                     ;   = mov rcx,[rip+rel32]; lea rdx,[rsp+X]
//   test rax, rax                    ; if not found → bail (leaves slot NULL)
//   jz  skip
//   lea rcx, [rax+3]                 ; skip 3-byte prefix (48 8B 0D)
//   movsxd rax, [rcx]                ; read rel32
//   add rax, 4                       ; add instruction length (rel32 is signed)
//   add rax, rcx                     ; final_addr = match+3+4+rel32
//   mov rax, [rax]                   ; *dereference*  — this is what CS2 code
//                                     ;   loads at runtime into rcx from that
//                                     ;   `mov rcx,[rip+rel32]` — i.e. the
//                                     ;   INTERFACE OBJECT the accessor uses.
//   mov cs:qword_7FFBE823A988, rax   ; STASH — this pointer is what Hook A
//                                     ;   uses as `fire_flag_probe::g_target`'s BASE.
//
// The AVX-XOR-decrypted signature bytes (recovered offline from the encrypted
// qwords Handler B builds on stack) are:
//
//   48 8B 0D ?? ?? ?? ?? 48 8D 54 24 ??
//
// That is precisely a `mov rcx, [rip+rel32] ; lea rdx, [rsp+disp8]` prologue
// — the signature reliably matches CS2's engine-interface accessor.  Which
// exact accessor is a build-of-cs2 question; on today's client.dll this
// resolver lands on the `CInput`/`CGameMovementState`-family global that
// holds the "fire-was-armed" byte at a schema-provided offset.
//
// Hook A then reads:
//     fire_flag_probe::g_target = base_from_here + fnv_offset(0xB6E8F068409FEF6C)
// where `fnv_offset(hash)` = CS2 schema field-offset lookup for that hash.
// The precise field name behind that hash isn't textually stored in FVA
// (VMP-stripped), but it lands inside CInput's per-slot input state.
//
// Contract this file exposes:
//   * `game_state::resolve()` — call once from Hook B install path.
//   * `game_state::base()`    — returns the resolved interface pointer or nullptr.
//   * `game_state::field_ptr(uint64_t hash)` — returns base + schema_offset(hash),
//     or nullptr if unresolved.  Uses reconstruction's own schema-lookup helper.
// ============================================================================
#include "game_state_resolver.h"

#include "../core/signature_scanner.h"
#include "../version_manifest.h"

#include <Windows.h>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <string_view>

namespace fva::game_state
{

namespace {

// Direct RVA to CCSGOInput singleton — verified via IDA session 05a7df10
// на депот 24134959: sub_1800EA030 (CCSGOInput constructor) устанавливает
// vftable в qword_1823B95F0 (RVA 0x23B95F0), т.е. **сам singleton живёт
// EMBEDDED в client.dll .data**, не pointer chain через extern getter.
//
// Previous approach: sig-scan `48 8B 0D ? ? ? ? 48 8D 54 24 ?` — matched
// 5+ функций на обоих depot'ах (14167 + 24134959), first hit = C_
// PointClientUIDialog constructor (не interface accessor). Значит raw
// pointer через sig-scan → мусор → все fire_flag reads возвращали 0 →
// gate всегда false → spoof off.
//
// Verified cross-reference с a2x/cs2-dumper HEAD (2026-07-11):
//   client.dll::client_dll::dwCSGOInput = 0x23B95F0   ← singleton base
//
// Fallback на sig-scan оставлен на случай будущих drift'ов, но с более
// строгим pattern (accessor thunk-like: mov [rcx], rax; ret) — не тот
// generic который матчил dialog constructors.
constexpr std::uintptr_t k_ccsgo_input_rva = 0x23B95F0;

std::atomic<void*> g_base{nullptr};
std::atomic<bool>  g_tried{false};

} // namespace

void* resolve() noexcept
{
    // Latch — same as Handler B's TLS-guarded "run once ever" pattern.
    bool expected = false;
    if (!g_tried.compare_exchange_strong(expected, true,
                                          std::memory_order_acq_rel))
        return g_base.load(std::memory_order_acquire);

    HMODULE client = ::GetModuleHandleW(fva::version::module_names::client_dll);
    if (!client) return nullptr;

    // Direct RVA — CCSGOInput singleton embedded в client.dll data section.
    auto* base_ptr = reinterpret_cast<std::uint8_t*>(client) + k_ccsgo_input_rva;

    // Sanity check — первое qword должно быть vftable pointer (не null,
    // не smart-tag byte).  На uninitialized memory будет 0 → skip.
    __try {
        auto vft = *reinterpret_cast<std::uintptr_t*>(base_ptr);
        if (vft == 0) {
            std::printf("[fva_recon][State] CCSGOInput @ client.dll+0x%zX "
                        "vftable=NULL — constructor не отработал (rare, "
                        "possibly race с ранним инжектом)\n",
                        (size_t)k_ccsgo_input_rva);
            return nullptr;
        }
        g_base.store(base_ptr, std::memory_order_release);
        std::printf("[fva_recon][State] CCSGOInput @ %p (RVA 0x%zX) vft=0x%zX\n",
                    (void*)base_ptr, (size_t)k_ccsgo_input_rva, (size_t)vft);
        return base_ptr;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        std::printf("[fva_recon][State] CCSGOInput @ RVA 0x%zX read SEH — "
                    "RVA drifted (rebuild с cs2-dumper HEAD required)\n",
                    (size_t)k_ccsgo_input_rva);
        return nullptr;
    }
}

void* base() noexcept
{
    return g_base.load(std::memory_order_acquire);
}

void force_reresolve() noexcept
{
    g_tried.store(false, std::memory_order_release);
    g_base.store(nullptr, std::memory_order_release);
    std::printf("[fva_recon][State] game_state: reresolve requested (level transition)\n");
    (void)resolve();
}

// Inline hash→schema-offset table.  Sourced from decompiled Hook A body:
// FVA calls `sub_7FFBE80FB1C4(hash)` — a schema-field-offset lookup — and
// caches the returned int32 in `dword_7FFBE823A9CC`.  We don't yet have a
// live schema mirror; the only entry we NEED at this point is the fire_flag_probe
// field.  Extend this table as more Hook A / Handler B hashes are cracked.
// The schema populator FVA uses (sub_7FFBE80FAEF0 in fva_rebuild.i64) iterates
// CS2's own class descriptor tree (nested list at base+1472..+7616) and for
// each field records the pair (FNV1a_hash, u32_offset) into a std::vector
// living behind qword_7FFBE823A8D8 .. qword_7FFBE823A8E0.  The hash key is
// computed exactly as:
//
//     std::string key = std::string(type_name) + "->" + std::string(field_name);
//     uint64_t h = 0xCBF29CE484222325;                           // FNV1a offset basis
//     for (char c : key) h = (uint64_t)0x100000001B3 * (h ^ (uint8_t)c);
//
// (The separator "->" is stored at unk_7FFBE82190A8 in FVA — bytes 2D 3E 00.)
//
// Snapshot table below is captured from a live cs2 run 2026-07-10 14:33
// (PID 2972, FVA base 0x7FFED7600000, interface base 0x0000027C10DBE000).
// The interface Hook B resolved is the CS2 game-movement/input state
// object (holds usercmd/pawn cross-refs at these offsets).  Values are
// build-of-cs2 constants; on a Valve client update, re-snap with:
//
//     python3 -c "..." → read u32 at FVA_base + 0x18A9CC   (fire_flag_probe)
//                                           + 0x18A934   (subobj)
//                                           + 0x18A93C   (fire_flag)
//                                           + 0x18A970   (subtick_counter)
static std::int32_t schema_offset_for_hash_stub(std::uint64_t hash) noexcept
{
    switch (hash) {
    // Handler A fire_flag_probe: byte at [interface+0xA4] snapshotted on first
    // CreateMove tick; non-zero snapshot arms Section J (subtick viewangle
    // injection) for the whole session.  Live cs2 shows this byte held at
    // 0 the entire session — Handler A's per-tick `apply()` zeros it
    // continuously, so unless something ELSE races the CS2 side to write
    // a non-zero value between install-of-Hook-A and first CreateMove
    // tick, Section J stays dormant.
    case fva::game_state::k_fire_flag_field_hash:
        return 0xA4;

    // Handler A Section B (chain-resolve after original CreateMove).
    // See docs/FIRE_LOGIC_DECODED_2026-07-10.md for how the three offsets
    // stack up into the subtick_moves+child.flags mutation path.
    case 0x737DDDA9E99E0B5D:  // sub-object base offset within the interface
        // Depot 14167 (2026-07-10): interface schema changed — 0x90C now
        // in zeroed padding region.  Live probe found pointer candidate at
        // 0x5E8 with subobj containing fire_flag=0 (byte) + subtick_counter
        // (small int).  Was 0x90C on depot 2347770.
        return 0x5E8;         // 1512 (was 0x90C=2316 on legacy depot)
    case 0x9320AED4F2DDF04B:  // fire-flag byte offset within subobj
        return 0x34C;         // 844
    case 0xC08C21B68A2C746D:  // live subtick counter offset within subobj
        return 0x6B8;         // 1720
    }
    return -1;
}

// Two-level deref for the sub-object-relative fields.  From
// FIRE_LOGIC_DECODED_2026-07-10.md Section B (cont.):
//     subobj = sub_7FFBE80DBB0C(interface + 0x90C);
// sub_7FFBE80DBB0C is a slot-pointer accessor; the first-order
// approximation is a plain `*(void**)`.  If that read isn't a valid
// pointer we return nullptr — subobj_ptr() also acts as a probe.
static void* subobj_ptr(void* interface_ptr) noexcept
{
    if (!interface_ptr) return nullptr;
    // Depot 14167: subobj base moved from 0x90C to 0x5E8.  Read from new
    // location.  If that fails, fall back to 0x90C-embedded semantics.
    auto* slot = reinterpret_cast<void**>(
        reinterpret_cast<std::uint8_t*>(interface_ptr) + 0x5E8);
    void* p = *slot;

    // One-shot diagnostic: on first call, dump the raw byte values around
    // interface + 0x90C so we can tell whether the sub-object is embedded
    // (offset 0x90C IS the object) vs pointer (offset 0x90C is a *ptr).
    static std::atomic<bool> s_logged{false};
    bool expected = false;
    if (s_logged.compare_exchange_strong(expected, true,
                                          std::memory_order_acq_rel))
    {
        auto* bytes = reinterpret_cast<std::uint8_t*>(slot);
        std::printf("[fva_recon][State] subobj probe: interface+0x5E8 @ %p "
                    "raw16=%02X %02X %02X %02X %02X %02X %02X %02X "
                    "%02X %02X %02X %02X %02X %02X %02X %02X  as_ptr=%p\n",
                    (void*)slot,
                    bytes[0],  bytes[1],  bytes[2],  bytes[3],
                    bytes[4],  bytes[5],  bytes[6],  bytes[7],
                    bytes[8],  bytes[9],  bytes[10], bytes[11],
                    bytes[12], bytes[13], bytes[14], bytes[15],
                    p);
    }

    // Basic sanity — user-mode pointers on x64 sit in [0x1000, 0x7FFFFFFFFFFF].
    auto v = reinterpret_cast<std::uintptr_t>(p);
    if (v < 0x1000 || v >= 0x7FFFFFFFFFFFull) {
        // Fallback: subobj is embedded at this offset, not a pointer.
        return reinterpret_cast<std::uint8_t*>(interface_ptr) + 0x5E8;
    }
    return p;
}

std::uint8_t* field_ptr(std::uint64_t hash) noexcept
{
    void* b = g_base.load(std::memory_order_acquire);
    if (!b) return nullptr;
    const std::int32_t off = schema_offset_for_hash_stub(hash);
    if (off < 0) return nullptr;

    // fire_flag / live_subtick_counter live under subobj, not interface.
    // fire_flag_probe and subobj_base itself are interface-relative.
    switch (hash) {
    case k_fire_flag_byte_hash:
    case k_live_subtick_counter_hash: {
        void* subobj = subobj_ptr(b);
        if (!subobj) return nullptr;
        return reinterpret_cast<std::uint8_t*>(subobj) + off;
    }
    default:
        return reinterpret_cast<std::uint8_t*>(b) + off;
    }
}

} // namespace fva::game_state
