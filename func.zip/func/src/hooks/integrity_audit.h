// ============================================================================
// integrity_audit.h
//
// Post-serialize self-check.  Compares две сериализации scratch protobuf
// (одну вручную, вторую через CS2's own SerializeToArrayImpl) чтобы поймать
// external hooks которые мутируют move_crc/arena tag между нашим write и
// финальным wire send.
//
// Схема:
//   Stream A = base64(arena_tag_reference bytes)
//   Stream B = base64(freshly-serialized scratch pb bytes)
//   compare byte-by-byte
//
// Trigger — mismatch:
//   * другой hook переписал scratch между Phase E serialize и нашей
//     re-serialization в integrity_audit::run(), ИЛИ
//   * move_crc был clobbered чужим write'ом
// Log + continue (diagnostic-only).  Оригинальный VMP-обфусцированный код
// на mismatch делал deliberate null-deref crash — мы это НЕ повторяем.
//
// Base64 wrap сохранён для parity с оригинальным telemetry форматом (можно
// сравнивать наши логи с origin-side логами напрямую); raw memcmp был бы
// эквивалентен.
// ============================================================================
#pragma once

#include <string>

namespace valve::pb::raw { struct CBaseUserCmdPB; }

namespace fva::hooks::integrity_audit
{

enum class Result : unsigned char
{
    Skipped,   // pre-req missing (no move_crc, scratch not ready, etc.)
    Match,     // both streams equal after base64 encode
    Mismatch,  // streams diverged — mismatch counter incremented + log line emitted
};

// Compare base->move_crc against a fresh serialize(scratch) via base64.
//
// `reference_bytes` — the raw wire bytes Phase E just wrote into
//   base->move_crc.  Passed through to avoid re-reading the std::string.
//   Pass an empty string to force integrity_audit to read from base->move_crc itself.
Result run(const valve::pb::raw::CBaseUserCmdPB* base,
           const std::string& reference_bytes) noexcept;

[[nodiscard]] unsigned long long mismatch_count() noexcept;
[[nodiscard]] unsigned long long pass_count() noexcept;

} // namespace fva::hooks::integrity_audit
