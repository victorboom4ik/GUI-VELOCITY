// ============================================================================
// Phase D — implementation.  See integrity_audit.h for FVA cross-reference.
//
// FVA reference region: sub_7FFBE80C9D8C @ +0x0D6A..+0x1213
//   base64 alphabet literal .rdata:0x7FFBE820AAC0
//   ScratchToString call    .text:0x7FFBE80CAC72
//   memcmp gate             .text:0x7FFBE80CAF7A (crash: mov [rax],1)
// ============================================================================
#include "integrity_audit.h"
#include "scratch_serialize.h"
#include "../schema/cbaseusercmdpb_layout.h"

#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>

namespace fva::hooks::integrity_audit
{

namespace {

// Byte-identical to aAbcdefghijklmn @ 0x7FFBE820AAC0.  Standard RFC 4648.
constexpr char k_b64_alphabet[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

void encode_b64(const std::uint8_t* src, std::size_t n, std::string& out)
{
    const std::size_t rem = n % 3;
    const std::size_t pad = rem ? 3 - rem : 0;
    out.resize(((n + pad) / 3) * 4);

    std::size_t i = 0, o = 0;
    for (; i + 3 <= n; i += 3, o += 4) {
        const std::uint8_t b0 = src[i], b1 = src[i + 1], b2 = src[i + 2];
        out[o + 0] = k_b64_alphabet[ b0 >> 2 ];
        out[o + 1] = k_b64_alphabet[ ((b0 & 0x03) << 4) | (b1 >> 4) ];
        out[o + 2] = k_b64_alphabet[ ((b1 & 0x0F) << 2) | (b2 >> 6) ];
        out[o + 3] = k_b64_alphabet[ b2 & 0x3F ];
    }
    if (rem == 2) {
        const std::uint8_t b0 = src[i], b1 = src[i + 1];
        out[o + 0] = k_b64_alphabet[ b0 >> 2 ];
        out[o + 1] = k_b64_alphabet[ ((b0 & 0x03) << 4) | (b1 >> 4) ];
        out[o + 2] = k_b64_alphabet[ (b1 & 0x0F) << 2 ];
        out[o + 3] = '=';
    } else if (rem == 1) {
        const std::uint8_t b0 = src[i];
        out[o + 0] = k_b64_alphabet[ b0 >> 2 ];
        out[o + 1] = k_b64_alphabet[ (b0 & 0x03) << 4 ];
        out[o + 2] = '=';
        out[o + 3] = '=';
    }
}

std::atomic<unsigned long long> g_mismatch_count{0};
std::atomic<unsigned long long> g_pass_count{0};

constexpr unsigned long long k_log_first_n = 8;
constexpr unsigned long long k_log_every   = 512;

} // namespace

Result run(const valve::pb::raw::CBaseUserCmdPB* base,
           const std::string& reference_bytes) noexcept
{
    if (!base || !base->move_crc) return Result::Skipped;
    if (!fva::scratch_serialize::ready()) return Result::Skipped;

    thread_local std::string s_scratch_bytes;
    if (!fva::scratch_serialize::serialize(s_scratch_bytes))
        return Result::Skipped;

    const std::uint8_t* pa;
    std::size_t         na;
    if (!reference_bytes.empty()) {
        pa = reinterpret_cast<const std::uint8_t*>(reference_bytes.data());
        na = reference_bytes.size();
    } else {
        pa = reinterpret_cast<const std::uint8_t*>(base->move_crc->data());
        na = base->move_crc->size();
    }

    const auto* pb = reinterpret_cast<const std::uint8_t*>(s_scratch_bytes.data());
    const auto  nb = s_scratch_bytes.size();

    thread_local std::string s_a, s_b;
    encode_b64(pa, na, s_a);
    encode_b64(pb, nb, s_b);

    const bool equal =
        s_a.size() == s_b.size() &&
        (s_a.empty() || std::memcmp(s_a.data(), s_b.data(), s_a.size()) == 0);

    if (equal) {
        g_pass_count.fetch_add(1, std::memory_order_relaxed);
        return Result::Match;
    }

    const auto n = g_mismatch_count.fetch_add(1, std::memory_order_relaxed);
    if (n < k_log_first_n || (n % k_log_every) == 0) {
        char head_a[33] = {0}, head_b[33] = {0};
        std::memcpy(head_a, s_a.data(), s_a.size() < 32 ? s_a.size() : 32);
        std::memcpy(head_b, s_b.data(), s_b.size() < 32 ? s_b.size() : 32);
        std::printf("[fva_recon][integrity_audit] tamper: move_crc(%zu)!=scratch(%zu) "
                    "a=%s%s b=%s%s hit#%llu\n",
                    na, nb,
                    head_a, s_a.size() > 32 ? "..." : "",
                    head_b, s_b.size() > 32 ? "..." : "",
                    static_cast<unsigned long long>(n + 1));
    }
    return Result::Mismatch;
}

unsigned long long mismatch_count() noexcept
{
    return g_mismatch_count.load(std::memory_order_relaxed);
}

unsigned long long pass_count() noexcept
{
    return g_pass_count.load(std::memory_order_relaxed);
}

} // namespace fva::hooks::integrity_audit
