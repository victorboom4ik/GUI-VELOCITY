// game_state_resolver.h — see game_state_resolver.cpp for full FVA-source
// commentary.  Fills the create_move_hook.cpp fire_flag_probe::g_target gap
// documented in that TU's header comment.
#pragma once

#include <cstdint>

namespace fva::game_state
{

// Resolve the accessor base pointer once.  Idempotent; safe to call from
// any hook install path.  Returns the interface pointer, or nullptr on
// failure (signature miss or NULL global at deref).
void* resolve() noexcept;

// Clear the once-latch and force a fresh resolve on the next call.
// Used by LevelInit hook because CS2 can rebuild the interface object
// across map loads; a stale pointer from the previous level would land
// on freed / relocated memory and read as zeros.
void force_reresolve() noexcept;

// Return the last-resolved base pointer, or nullptr if resolve() failed
// / hasn't been called yet.
void* base() noexcept;

// Compute base + schema_offset(hash).  Returns nullptr if either the base
// is unresolved or the schema layer doesn't recognise the hash.  The
// hash the create_move_hook fire_flag_probe path uses is
// 0xB6E8F068409FEF6C (from FVA @ sub_7FFBE80C9D8C +0x1F7).
std::uint8_t* field_ptr(std::uint64_t hash) noexcept;

// Convenience — the hash Handler A uses.  Kept here so create_move_hook.cpp
// doesn't have to hard-code magic.
inline constexpr std::uint64_t k_fire_flag_field_hash = 0xB6E8F068409FEF6C;

// The three sub-object offsets Handler A resolves after the CreateMove
// original returns (see Section B in FIRE_LOGIC_DECODED_2026-07-10.md).
// Callers (input_scratch_mirror / integrity_audit / scratch_serialize) should use field_ptr()
// with these hashes rather than hard-coded numeric offsets so that a
// Valve update needs edits only in game_state_resolver.cpp, not here.
inline constexpr std::uint64_t k_subobj_base_hash          = 0x737DDDA9E99E0B5D;
inline constexpr std::uint64_t k_fire_flag_byte_hash       = 0x9320AED4F2DDF04B;
inline constexpr std::uint64_t k_live_subtick_counter_hash = 0xC08C21B68A2C746D;

} // namespace fva::game_state
