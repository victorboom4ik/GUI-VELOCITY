#include "hook_manager.h"
#include "animation_hook.h"
#include "serialize_to_array_hook.h"
#include "create_move_hook.h"
#include "level_init_hook.h"

#include <MinHook.h>
#include <cstdio>

namespace fva::hooks
{

bool install_all()
{
    if (MH_Initialize() != MH_OK && MH_Initialize() != MH_ERROR_ALREADY_INITIALIZED)
        return false;

    // Install order matters: Hook B first (it resolves globals used by A/C
    // when it fires), then A (needs C wired up so its mutation pipeline works),
    // then C.  Hook D (animation) is optional — if animationsystem.dll isn't
    // loaded yet at install time we skip and log a warning; hook_manager
    // will not fail-fast on that.
    if (!install_level_init_hook())         return false;
    if (!install_create_move_hook())        return false;
    if (!install_serialize_to_array_hook()) return false;

    // H4 (ShouldUpdateSequences) — DISABLED 2026-07-10.
    //
    // IDA xref analysis on FVA-rebuild IDB session 8983afd1 confirmed that
    // FVA's H4 slot at xmmword_7FFBE823C3A0 has:
    //   target field (+0):  1 xref (only from constructor, sets to 0)
    //   detour field (+8):  0 xrefs — NEVER WRITTEN
    //   installed word:     1 xref (constructor sets to 0)
    // FVA never actually installs a hook on ShouldUpdateSequences — the slot
    // is a stub/vestigial/reserved.  Our previous E9 patch on
    // animationsystem.dll+0x14EFF0 was surplus.
    //
    // The animation_hook.cpp code is kept for documentation + future
    // re-enable if a new FVA version populates this slot.
    //
    // if (!install_animation_hook()) { ... }

    return true;
}

void uninstall_all()
{
    uninstall_animation_hook();   // no-op if install was skipped
    uninstall_serialize_to_array_hook();
    uninstall_create_move_hook();
    uninstall_level_init_hook();
    MH_Uninitialize();
}

} // namespace fva::hooks
