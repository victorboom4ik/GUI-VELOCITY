// ============================================================================
// Version manifest — every drift-prone constant lives here, so a Valve
// update touches exactly one file.
//
// MULTI-DEPOT SUPPORT (2026-07-10):
//   Build with `-DFVA_TARGET_DEPOT=14167` to target depot 14167 (baseline).
//   Default is `24134959` (current post-update depot).
//
//   The compile-time flag selects RVA / prologue / MD5 sets.  Vtable slots,
//   layout offsets, and struct sizes are IDENTICAL on both depots (verified
//   via slot-3/slot-7 disasm) so live in the shared section.
//
// After a NEW Valve update:
//   1. Snapshot the client.dll (depot_snapshots/depot_<buildid>_<date>/).
//   2. RVA-scan Hook A/B/C targets + protobuf T::New wrappers.
//   3. Add a new depot block below with the new values.
//   4. Update build_fingerprint::kExpectedClientMd5 for the new depot.
// ============================================================================
#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

// ------------------------------------------------------------------
// Depot selection.  Default = 24134959 (current live game).
// Rebuild with `cmake -DFVA_TARGET_DEPOT=14167 …` to target baseline.
// ------------------------------------------------------------------
#ifndef FVA_TARGET_DEPOT
#define FVA_TARGET_DEPOT 24134959
#endif

#if FVA_TARGET_DEPOT != 14167 && FVA_TARGET_DEPOT != 24134959
#error "FVA_TARGET_DEPOT must be 14167 or 24134959"
#endif

namespace fva::version
{

//--------------------------------------------------------------------------
// Category A — client.dll hook target RVAs.
// Sig-scans should always find the same function; if the scanner returns a
// different RVA, prefer the scanner and update these fallbacks.
//--------------------------------------------------------------------------
namespace known_rva
{

#if FVA_TARGET_DEPOT == 14167
    // ═══════════════════════════════════════════════════════════════════
    // DEPOT 14167 BASELINE — 2026-07-10 (pre-major-update)
    // client.dll MD5 = b0fd08261be12cceb8e5636500e5a1d0 (37 272 728 B)
    // Snapshot: depot_snapshots/depot_14167_2026-07-10_BASELINE/
    // Frozen after 163 840 ticks without crash, 100% append rate.
    // ═══════════════════════════════════════════════════════════════════

    // -- Hook targets --------------------------------------------------
    inline constexpr std::uintptr_t hook_a_target = 0xACEF90;   // CreateMove-inner
    inline constexpr std::uintptr_t hook_b_target = 0xAFDFB0;   // LevelInit
    inline constexpr std::uintptr_t hook_c_target = 0x1189930;  // SerializePartialToArray
    inline constexpr std::uintptr_t hook_d_target = 0x14EFF0;   // animationsystem.dll ShouldUpdateSequences

    // -- Alternative outer entry points -------------------------------
    inline constexpr std::uintptr_t create_move_outer          = 0xC65FE0;  // approximate — same offset shift
    inline constexpr std::uintptr_t level_init_pattern         = 0xAFDFB0;
    inline constexpr std::uintptr_t serialize_partial_to_array = 0x1189930;

    // -- CS2 protobuf T::New(Arena*) — DIRECT CALL RVAs ---------------
    inline constexpr std::uintptr_t new_maybe_arena_cbaseusercmdpb          = 0x4B21E0; // size 0x88=136
    inline constexpr std::uintptr_t new_maybe_arena_csubtickmovestep        = 0x4B22D0; // size 0x38=56
    inline constexpr std::uintptr_t new_maybe_arena_cinbuttonstatepb        = 0x4B2250; // size 0x30=48
    inline constexpr std::uintptr_t new_maybe_arena_cmsgqangle              = 0x6840F0; // size 0x28=40
    inline constexpr std::uintptr_t new_maybe_arena_csgoinputhistoryentrypb = 0x742730; // size 0x78=120  ★ FVA target ★

    // -- Vtable RVAs (in .rdata) --------------------------------------
    // Baseline: CBaseUserCmdPB vtable @ RVA 0x1995748.  Verified via ctor
    // sub_1804B2740 @ `lea rax, [byte_181995748]`.
    inline constexpr std::uintptr_t vtable_cbaseusercmdpb          = 0x1995748;
    inline constexpr std::uintptr_t vtable_csubtickmovestep        = 0x0;   // live extraction
    inline constexpr std::uintptr_t vtable_csgoinputhistoryentrypb = 0x1A1E028; // live-verified on baseline

    // -- Allocator chain (heap path) ----------------------------------
    inline constexpr std::uintptr_t heap_alloc_wrapper  = 0xB931D0;    // sub_180B931D0 → tier0::MemAlloc
    inline constexpr std::uintptr_t heap_free_wrapper   = 0xB93230;    // sibling
    inline constexpr std::uintptr_t arena_alloc_aligned = 0x1170000;   // approximate

    // -- RTTI Type Descriptor RVAs -----------------------------------
    // Not statically re-derived for baseline; used only for offline xref audit.
    inline constexpr std::uintptr_t rtti_cbaseusercmdpb          = 0x0; // TBV
    inline constexpr std::uintptr_t rtti_cinbuttonstatepb        = 0x0;
    inline constexpr std::uintptr_t rtti_csubtickmovestep        = 0x0;
    inline constexpr std::uintptr_t rtti_cmsgqangle              = 0x0;
    inline constexpr std::uintptr_t rtti_csgoinputhistoryentrypb = 0x0;

    // -- Static ConVar instance RVAs (baseline 14167) ----------------
    // Derived via LEA-xref trace 2026-07-10:
    //   .text @ RVA 0xDB3D0: lea rXX, [0x1AC0358]  (name "cl_pred_print_every_cmd")
    //   .text @ RVA 0xDB3D7: lea rXX, [0x2341620]  (ConVar object)
    //   .text @ RVA 0xD086D: lea rXX, [0x1AB0478]  (name "cl_showusercmd")
    //   .text @ RVA 0xD0874: lea rXX, [0x233C580]  (ConVar object)
    //
    // ConVar object layout: {vtable, ..., name@+0x18, ..., value@+0x58}.
    // cvar_suppress::resolve_static_cvar probes offsets 0x18/0x20/0x10/0x28/0x08
    // and verifies via strcmp against expected name — safe against layout drift.
    inline constexpr std::uintptr_t static_cvar_cl_pred_print_every_cmd = 0x2341620;
    inline constexpr std::uintptr_t static_cvar_cl_showusercmd          = 0x233C580;

    // -- CS2 protobuf ArenaStringPtr::Set (baseline) -----------------
    // Sig-scan `48 89 5C 24 20 57 48 83 EC 30 49 8B C0 48 8B DA 48 8B F9`
    // hit RVA 0x11712C0 on baseline.
    inline constexpr std::uintptr_t arena_string_ptr_set = 0x11712C0;

    // -- tier0.dll imports (via IAT) ---------------------------------
    inline constexpr std::uintptr_t iat_memalloc_allocfunc = 0x0; // not re-derived
    inline constexpr std::uintptr_t iat_memalloc_freefunc  = 0x0;

#elif FVA_TARGET_DEPOT == 24134959
    // ═══════════════════════════════════════════════════════════════════
    // DEPOT 24134959 (post-major-update) — 2026-07-10 19:50
    // client.dll MD5 = 16917fce6c15715434f6604e8086d38a (37 419 160 B)
    // Snapshot: depot_snapshots/depot_24134959_2026-07-10/
    //
    // Drift summary (14167 → 24134959):
    //   Hook A:                  +0x3A598 (0xACEF90  → 0xB09528)
    //   Hook B:                  +0x3C650 (0xAFDFB0  → 0xB3A600)
    //   Hook C:                  +0x23BB0 (0x1189930 → 0x11AD4E0)
    //   Allocator wrapper:       +0x37E70 (0xB931D0  → 0xBCB040)
    //   CBaseUserCmdPB::New:     +0x30120 (0x4B21E0  → 0x4E2300)
    //   CSubtickMoveStep::New:   +0x30120 (0x4B22D0  → 0x4E23F0)
    //   CInButtonStatePB::New:   +0x30120 (0x4B2250  → 0x4E2370)
    //   CMsgQAngle::New:         -0x28F00 (0x6840F0  → 0x65B1F0)
    //   CSGOInputHistoryEntryPB: +0x34CE0 (0x742730  → 0x777410)
    //   CBaseUserCmdPB vtable:   +0x3FE40 (0x1995748 → 0x19D5588)
    //   ArenaStringPtr::Set:     +0x23BB0 (0x11712C0 → 0x1194E70)
    // All values RTTI-verified via ".?AV{ClassName}@@" descriptor xrefs.
    // ═══════════════════════════════════════════════════════════════════

    // -- Hook targets --------------------------------------------------
    inline constexpr std::uintptr_t hook_a_target = 0xB09528;
    inline constexpr std::uintptr_t hook_b_target = 0xB3A600;
    inline constexpr std::uintptr_t hook_c_target = 0x11AD4E0;
    inline constexpr std::uintptr_t hook_d_target = 0x14EFF0;

    // -- Alternative outer entry points -------------------------------
    inline constexpr std::uintptr_t create_move_outer          = 0xC97750;
    inline constexpr std::uintptr_t level_init_pattern         = 0xB3A600;
    inline constexpr std::uintptr_t serialize_partial_to_array = 0x11AD4E0;

    // -- CS2 protobuf T::New(Arena*) — DIRECT CALL RVAs ---------------
    inline constexpr std::uintptr_t new_maybe_arena_cbaseusercmdpb          = 0x4E2300;
    inline constexpr std::uintptr_t new_maybe_arena_csubtickmovestep        = 0x4E23F0;
    inline constexpr std::uintptr_t new_maybe_arena_cinbuttonstatepb        = 0x4E2370;
    inline constexpr std::uintptr_t new_maybe_arena_cmsgqangle              = 0x65B1F0;
    inline constexpr std::uintptr_t new_maybe_arena_csgoinputhistoryentrypb = 0x777410;

    // -- Vtable RVAs (in .rdata) --------------------------------------
    inline constexpr std::uintptr_t vtable_cbaseusercmdpb          = 0x19D5588;
    inline constexpr std::uintptr_t vtable_csubtickmovestep        = 0x0;
    inline constexpr std::uintptr_t vtable_csgoinputhistoryentrypb = 0x0;

    // -- Allocator chain (heap path) ----------------------------------
    inline constexpr std::uintptr_t heap_alloc_wrapper  = 0xBCB040;
    inline constexpr std::uintptr_t heap_free_wrapper   = 0xBCB0A0;
    inline constexpr std::uintptr_t arena_alloc_aligned = 0x11B0000;

    // -- RTTI Type Descriptor RVAs -----------------------------------
    inline constexpr std::uintptr_t rtti_cbaseusercmdpb          = 0x213F870;
    inline constexpr std::uintptr_t rtti_cinbuttonstatepb        = 0x213F7E8;
    inline constexpr std::uintptr_t rtti_csubtickmovestep        = 0x213F810;
    inline constexpr std::uintptr_t rtti_cmsgqangle              = 0x2146AF0;
    inline constexpr std::uintptr_t rtti_csgoinputhistoryentrypb = 0x214E798;

    // -- Static ConVar instance RVAs ---------------------------------
    inline constexpr std::uintptr_t static_cvar_cl_pred_print_every_cmd = 0x23A4328;
    inline constexpr std::uintptr_t static_cvar_cl_showusercmd          = 0x239ECE8;

    // -- CS2 protobuf ArenaStringPtr::Set ----------------------------
    inline constexpr std::uintptr_t arena_string_ptr_set = 0x1194E70;

    // -- tier0.dll imports (via IAT) ---------------------------------
    inline constexpr std::uintptr_t iat_memalloc_allocfunc = 0x1917230;
    inline constexpr std::uintptr_t iat_memalloc_freefunc  = 0x1917238;

#endif

    // -- Common: fingerprint gate for T::New wrappers (SAME on both depots) --
    // All share prologue 48 89 5C 24 10 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 ...
    // Disambiguated by mov ecx,<size> immediate at offset +0x14.
    inline constexpr std::uint8_t protobuf_new_prologue_first8[8] = {
        0x48, 0x89, 0x5C, 0x24, 0x10, 0x57, 0x48, 0x83
    };

    // ═══════════════════════════════════════════════════════════════════
    // engine2.dll RVAs — verified on baseline; may drift on 24134959.
    // Not currently hooked by reconstruction; kept as ALTERNATIVE injection
    // points for hypothetical stronger anti-aim.  Prefer client.dll hooks.
    // ═══════════════════════════════════════════════════════════════════
    namespace engine2
    {
        inline constexpr std::uintptr_t send_move_packet = 0x64FA0;
        inline constexpr std::uintptr_t is_in_game       = 0x76470;
        inline constexpr std::uintptr_t is_connected     = 0x764A0;
    }
}

//--------------------------------------------------------------------------
// Category B — CBaseUserCmdPB layout offsets.  IDENTICAL on both depots
// (protobuf schema unchanged, only RVA drift between 14167 → 24134959).
//--------------------------------------------------------------------------
namespace layout
{
    inline constexpr std::size_t base_cmd_has_bits        = 0x10;
    inline constexpr std::size_t base_cmd_cached_size     = 0x14;
    inline constexpr std::size_t base_cmd_subtick_moves   = 0x18;
    inline constexpr std::size_t base_cmd_move_crc        = 0x30;
    inline constexpr std::size_t base_cmd_buttons_pb      = 0x38;
    inline constexpr std::size_t base_cmd_viewangles      = 0x40;
    inline constexpr std::size_t base_cmd_execution_notes = 0x48;
    inline constexpr std::size_t base_cmd_forwardmove     = 0x58;
    inline constexpr std::size_t base_cmd_random_seed     = 0x6C;
    inline constexpr std::size_t base_cmd_cmd_flags       = 0x80;
    inline constexpr std::size_t base_cmd_pawn_handle     = 0x84;

    // CS2 CUserCmd (raw_cmd, Hook A `rbx`)
    inline constexpr std::size_t user_cmd_arena_word          = 0x18;
    inline constexpr std::size_t user_cmd_flags               = 0x20;
    inline constexpr std::size_t user_cmd_base                = 0x40;
    inline constexpr std::size_t user_cmd_buttons_changed     = 0x60;
    inline constexpr std::size_t user_cmd_buttons_held        = 0x68;
    inline constexpr std::size_t user_cmd_buttons_pressed     = 0x70;
    inline constexpr std::size_t user_cmd_subtick_moves_field = 0x28;

    inline constexpr int subtick_moves_capacity = 16;
}

//--------------------------------------------------------------------------
// Category C — Google protobuf MessageLite vtable slots for CBaseUserCmdPB.
// IDENTICAL on both depots (verified via disasm of slot[3]/slot[6]/slot[7]
// on both binaries — same functional prologues at each slot).
//
// CBaseUserCmdPB vtable dump (offsets identical, RVAs differ):
//   slot[ 0] vt+0x00  ~destructor
//   slot[ 1] vt+0x08  DebugString-like (uses GetTypeName + emitter)
//   slot[ 2] vt+0x10  New(Arena*) — forwards to CBaseUserCmdPB::New
//   slot[ 3] vt+0x18  ★ Clear ★  (iterates subtick_moves rep, zeros
//                                  own count [rbx+0x20]=0, clears has_bits-guarded
//                                  fields at +0x30/+0x38)
//   slot[ 4] vt+0x20  IsInitialized (mov al,1; ret)
//   slot[ 5] vt+0x28  CheckTypeAndMergeFromCoded-like
//   slot[ 6] vt+0x30  ★ MergeFrom (public) ★  forwarder
//                     `mov rax, [rcx]; jmp [rax+0x60]` → slot[12].
//   slot[ 7] vt+0x38  ★ ByteSizeLong ★  (reads has_bits, iterates)
//   slot[ 8] vt+0x40  GetCachedSize (mov eax, [rcx+0x14]; ret)
//   slot[ 9] vt+0x48  _InternalParse
//   slot[10] vt+0x50  empty stub (ret 0)
//   slot[11] vt+0x58  SerializeInternalWithCachedSizesToArray
//   slot[12] vt+0x60  CheckTypeAndMergeFromMessageLite (metadata check)
//   slot[13] vt+0x68  (calls GetTypeName via slot[15])
//   slot[14] vt+0x70  SetCachedSize
//   slot[15] vt+0x78  GetTypeName (LazyString wrapper — RETURNS EMPTY
//                     on 24134959, LIKELY empty on 14167 too — never used).
//   slot[16] vt+0x80  GetMetadata (returns ptr to Metadata@vtable-0x18)
//
// Hook C uses vtable-pointer comparison INSTEAD OF GetTypeName since the
// LazyString wrapper is broken (returns empty std::string).  This is more
// reliable and works identically on both depots.
//--------------------------------------------------------------------------
namespace protobuf
{
    inline constexpr std::size_t vtbl_clear         = 0x18;  // slot[3]  Clear
    inline constexpr std::size_t vtbl_bytesize_long = 0x38;  // slot[7]  ByteSizeLong
    inline constexpr std::size_t vtbl_get_typename  = 0x78;  // slot[15] LazyString — do not use
    inline constexpr std::size_t vtbl_merge_from    = 0x30;  // slot[6]  MergeFrom (public forwarder)
}

//--------------------------------------------------------------------------
// Category D — FVA obfuscation constants (SAME across depots since they
// derive from FVA's own build, not CS2's).
//--------------------------------------------------------------------------
namespace obfuscation
{
    inline constexpr std::uint64_t encoded_typename[2] = {
        0xF6E0262244CDBA8E,
        0x9F047512FCEAE7BC
    };
    inline constexpr std::uint64_t xor_key[2] = {
        0x9393734737ACF8CD,
        0x9F0437429887A4CE
    };
}

//--------------------------------------------------------------------------
// Category E — Module names (SAME across depots).
//--------------------------------------------------------------------------
namespace module_names
{
    inline constexpr wchar_t client_dll[]          = L"client.dll";
    inline constexpr wchar_t engine2_dll[]         = L"engine2.dll";
    inline constexpr wchar_t networksystem_dll[]   = L"networksystem.dll";
    inline constexpr wchar_t tier0_dll[]           = L"tier0.dll";
    inline constexpr wchar_t animationsystem_dll[] = L"animationsystem.dll";
}

//--------------------------------------------------------------------------
// Category F — Build fingerprint for drift detection.
// Depot-specific — MD5 and hook prologues differ between depots.
//--------------------------------------------------------------------------
namespace build_fingerprint
{

#if FVA_TARGET_DEPOT == 14167
    // Depot 14167 BASELINE (2026-07-10).
    inline constexpr char        kExpectedClientMd5[] =
        "b0fd08261be12cceb8e5636500e5a1d0";
    inline constexpr std::size_t kExpectedClientSize = 37'272'728;

    // Hook A entry (RVA 0xACEF90, depot 14167) — `test edx, edx; jnz +N`.
    // The 5 pre-patch bytes at function entry.
    inline constexpr std::array<std::uint8_t, 5> kHookAPrePatch = {
        0x85, 0xD2, 0x0F, 0x85, 0x85
    };
    // Hook B entry (RVA 0xAFDFB0, depot 14167) — `push rbp; push rsi; push r14; lea rbp, [rsp-47h]`.
    inline constexpr std::array<std::uint8_t, 5> kHookBPrePatch = {
        0x40, 0x55, 0x56, 0x41, 0x56
    };
    // Hook C entry (RVA 0x1189930, depot 14167) — hotpatch-friendly `mov [rsp+18h], rbx`.
    // IDENTICAL to 24134959 — Hook C prologue survived the update.
    inline constexpr std::array<std::uint8_t, 5> kHookCPrePatch = {
        0x48, 0x89, 0x5C, 0x24, 0x18
    };
    // Hook D entry (animationsystem.dll RVA 0x14EFF0) — `mov [rsp+08h], rbx`.
    inline constexpr std::array<std::uint8_t, 5> kHookDPrePatch = {
        0x48, 0x89, 0x5C, 0x24, 0x08
    };

    // SerializePartialToArray @ RVA 0x1189930 (baseline) — same 5-byte prologue.
    inline constexpr std::array<std::uint8_t, 5> kSerializePartialPrologue = {
        0x48, 0x89, 0x5C, 0x24, 0x18
    };

#elif FVA_TARGET_DEPOT == 24134959
    // Depot 24134959 (post-major-update, 2026-07-10).
    inline constexpr char        kExpectedClientMd5[] =
        "16917fce6c15715434f6604e8086d38a";
    inline constexpr std::size_t kExpectedClientSize = 37'419'160;

    // Hook A entry (RVA 0xB09528, depot 24134959) — `mov rax, rsp; mov [rax+18h], r8b`.
    inline constexpr std::array<std::uint8_t, 5> kHookAPrePatch = {
        0x48, 0x8B, 0xC4, 0x44, 0x88
    };
    // Hook B entry (RVA 0xB3A600, depot 24134959) — `mov [rsp+10h], rsi; push rdi`.
    inline constexpr std::array<std::uint8_t, 5> kHookBPrePatch = {
        0x48, 0x89, 0x74, 0x24, 0x10
    };
    // Hook C entry (RVA 0x11AD4E0, depot 24134959) — hotpatch-friendly `mov [rsp+18h], rbx`.
    inline constexpr std::array<std::uint8_t, 5> kHookCPrePatch = {
        0x48, 0x89, 0x5C, 0x24, 0x18
    };
    // Hook D entry (animationsystem.dll RVA 0x14EFF0) — `mov [rsp+08h], rbx`.
    inline constexpr std::array<std::uint8_t, 5> kHookDPrePatch = {
        0x48, 0x89, 0x5C, 0x24, 0x08
    };

    // SerializePartialToArray @ RVA 0x11AD4E0 (24134959).
    inline constexpr std::array<std::uint8_t, 5> kSerializePartialPrologue = {
        0x48, 0x89, 0x5C, 0x24, 0x18
    };

#endif

    // -- Common prologues (SAME across depots — MSVC codegen stable) --

    // NewMaybeArena_CBaseUserCmdPB prologue — 20 bytes covering null-arena gate.
    inline constexpr std::array<std::uint8_t, 20> kNewMaybeArenaPrologue = {
        0x48, 0x89, 0x5C, 0x24, 0x10,       // mov [rsp+10h], rbx
        0x57,                                // push rdi
        0x48, 0x83, 0xEC, 0x20,              // sub rsp, 20h
        0x33, 0xDB,                          // xor ebx, ebx
        0x48, 0x8B, 0xF9,                    // mov rdi, rcx
        0x48, 0x85, 0xC9,                    // test rcx, rcx
        0x75, 0x2D,                          // jnz +45 (arena-path branch)
    };

    // CInButtonStatePB::New — 48-byte alloc.  Fingerprint gate checks
    // the first 8 bytes only + size immediate at +0x14.
    inline constexpr std::array<std::uint8_t, 8> kNewCInButtonStatePrologue = {
        0x48, 0x89, 0x5C, 0x24, 0x10, 0x57, 0x48, 0x83
    };
    inline constexpr std::array<std::uint8_t, 5> kNewCInButtonStateSizeImm = {
        0xB9, 0x30, 0x00, 0x00, 0x00
    };

    // CMsgQAngle::New — 40-byte alloc.
    inline constexpr std::array<std::uint8_t, 8> kNewCMsgQAnglePrologue = {
        0x48, 0x89, 0x5C, 0x24, 0x10, 0x57, 0x48, 0x83
    };
    inline constexpr std::array<std::uint8_t, 5> kNewCMsgQAngleSizeImm = {
        0xB9, 0x28, 0x00, 0x00, 0x00
    };
}

// Runtime helper — expose target depot as a compile-time value for logging.
constexpr int kTargetDepot = FVA_TARGET_DEPOT;

} // namespace fva::version
