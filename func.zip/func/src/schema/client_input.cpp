// ============================================================================
// CInput / CUserCmd chain resolver — implementation.
// ============================================================================
#include "client_input.h"
#include "../core/signature_scanner.h"
#include "../version_manifest.h"

#include <Windows.h>
#include <cstdio>

namespace fva::client_input
{

namespace {

// Function typedefs.
using GetSlotInputFn        = void*  (__fastcall*)(int slot);
using GetCurrentSequenceFn  = int    (__fastcall*)(void* input);
using GetCmdBySequenceFn    = valve::pb::raw::CUserCmd* (__fastcall*)(void* input, int seq);

GetSlotInputFn        g_fn_get_slot_input        = nullptr;
GetCurrentSequenceFn  g_fn_get_current_sequence  = nullptr;
GetCmdBySequenceFn    g_fn_get_cmd_by_sequence   = nullptr;

// The three patterns FVA hard-codes in its .rdata (0x7FFBE820A000 /
// 0x7FFBE820A0E0 / 0x7FFBE820A120).  Hook A `sub_7FFBE80C9D8C` passes each
// verbatim to the FVA pattern parser `sub_7FFBE80DCB84`.  We hold the same
// strings verbatim so that `signature_scanner::find_in_module` resolves to
// the byte-identical client.dll addresses FVA stores in its own
// qword_7FFBE823A948/A950/A968 globals.  GetSlotInput's pattern has 2 valid
// hits in client.dll; FVA and we both take the first.
inline constexpr std::string_view k_sig_get_slot_input =
    "48 83 EC ? 83 F9 ? 75 ? 48 8B 0D ? ? ? ? 48 8D 54 24 ? 48 8B 01 FF 90 "
    "? ? ? ? 8B 08 48 63 C1 48 8D 0D ? ? ? ? 48 8B 04 C1 48 83 C4 ? C3";
inline constexpr std::string_view k_sig_get_current_sequence =
    "48 83 EC 28 E8 ? ? ? ? 8B 80";
inline constexpr std::string_view k_sig_get_cmd_by_sequence =
    "40 53 48 83 EC 20 8B DA E8 ? ? ? ? 4C";

} // namespace

bool init()
{
    HMODULE client = ::GetModuleHandleW(fva::version::module_names::client_dll);
    if (!client) return false;

    if (auto* p = fva::scanner::find_in_module(client, k_sig_get_slot_input))
        g_fn_get_slot_input = reinterpret_cast<GetSlotInputFn>(p);
    if (auto* p = fva::scanner::find_in_module(client, k_sig_get_current_sequence))
        g_fn_get_current_sequence = reinterpret_cast<GetCurrentSequenceFn>(p);
    if (auto* p = fva::scanner::find_in_module(client, k_sig_get_cmd_by_sequence))
        g_fn_get_cmd_by_sequence = reinterpret_cast<GetCmdBySequenceFn>(p);

    std::printf("[fva_recon] client_input: get_slot_input=%p current_seq=%p get_cmd=%p\n",
                (void*)g_fn_get_slot_input, (void*)g_fn_get_current_sequence,
                (void*)g_fn_get_cmd_by_sequence);

    return g_fn_get_slot_input && g_fn_get_current_sequence && g_fn_get_cmd_by_sequence;
}

void* get_slot_input(int slot) noexcept
{
    return g_fn_get_slot_input ? g_fn_get_slot_input(slot) : nullptr;
}

int get_current_sequence(void* input) noexcept
{
    return (g_fn_get_current_sequence && input) ? g_fn_get_current_sequence(input) : -1;
}

valve::pb::raw::CUserCmd* get_cmd_by_sequence(void* input, int seq) noexcept
{
    return (g_fn_get_cmd_by_sequence && input && seq >= 0)
             ? g_fn_get_cmd_by_sequence(input, seq)
             : nullptr;
}

valve::pb::raw::CUserCmd* current_local_cmd() noexcept
{
    void* input = get_slot_input(0);
    if (!input) return nullptr;
    int seq = get_current_sequence(input);
    if (seq < 0) return nullptr;
    return get_cmd_by_sequence(input, seq);
}

} // namespace fva::client_input
