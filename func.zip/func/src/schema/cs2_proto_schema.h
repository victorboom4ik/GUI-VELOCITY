// ============================================================================
// CS2 Google Protobuf message schema — user-provided authoritative layout.
//
// Source: user-provided schema (2026-07-10). This file mirrors the exact
// field order, types, and BITS constants of the CS2 protobuf messages that
// FVA and our reconstruction touch.
//
// Layout invariants:
//   - PBMessage base = 16 bytes (vtable + metadata)
//   - RepeatedPtrField<T> = 24 bytes (arena + current_size + total_size + rep)
//   - has_bits + cached_size = 8 bytes at start of every derived message
//
// Verified derived offsets (from user schema):
//   CBaseUserCmdPB = 136 bytes total  (matches sub_7FFBE80FAD0C ctor "136-byte
//     init" from workflow wf_49f9ef9b line 4 callee catalog).
// ============================================================================
#pragma once

#define NOMINMAX
#undef max
#include <Windows.h>
#include <stdint.h>
#include <limits>
#include <string>

template <typename T>
struct RepeatedPtrField_t
{
    struct Rep_t
    {
        int allocated_size;
        T* elements[(std::numeric_limits<int>::max() - 2 * sizeof(int)) / sizeof(void*)];
    };

    void* arena;
    int current_size;
    int total_size;
    Rep_t* rep;
};

struct PBMessage
{
    void* vtable;
    void* metadata;
};

// ---- Enums ---------------------------------------------------------------

enum ENetworkDisconnectionReason : uint32_t
{
    NETWORK_DISCONNECT_INVALID = 0,
    NETWORK_DISCONNECT_SHUTDOWN = 1,
    NETWORK_DISCONNECT_DISCONNECT_BY_USER = 2,
    NETWORK_DISCONNECT_DISCONNECT_BY_SERVER = 3,
    NETWORK_DISCONNECT_LOST = 4,
    NETWORK_DISCONNECT_OVERFLOW = 5,
    NETWORK_DISCONNECT_STEAM_BANNED = 6,
    NETWORK_DISCONNECT_STEAM_INUSE = 7,
    NETWORK_DISCONNECT_STEAM_TICKET = 8,
    NETWORK_DISCONNECT_STEAM_LOGON = 9,
    NETWORK_DISCONNECT_STEAM_AUTHCANCELLED = 10,
    NETWORK_DISCONNECT_STEAM_AUTHALREADYUSED = 11,
    NETWORK_DISCONNECT_STEAM_AUTHINVALID = 12,
    NETWORK_DISCONNECT_STEAM_VACBANSTATE = 13,
    NETWORK_DISCONNECT_STEAM_LOGGED_IN_ELSEWHERE = 14,
    NETWORK_DISCONNECT_STEAM_VAC_CHECK_TIMEDOUT = 15,
    NETWORK_DISCONNECT_STEAM_DROPPED = 16,
    NETWORK_DISCONNECT_STEAM_OWNERSHIP = 17,
    NETWORK_DISCONNECT_KICKED_INSECURECLIENT = 164
};

enum SignonState_t : uint32_t
{
    SIGNONSTATE_NONE = 0,
    SIGNONSTATE_CHALLENGE = 1,
    SIGNONSTATE_CONNECTED = 2,
    SIGNONSTATE_NEW = 3,
    SIGNONSTATE_PRESPAWN = 4,
    SIGNONSTATE_SPAWN = 5,
    SIGNONSTATE_FULL = 6,
    SIGNONSTATE_CHANGELEVEL = 7
};

// ---- Small proto types --------------------------------------------------

constexpr uint32_t CMSGVECTOR_BITS_X = 0x1;
constexpr uint32_t CMSGVECTOR_BITS_Y = 0x2;
constexpr uint32_t CMSGVECTOR_BITS_Z = 0x4;
constexpr uint32_t CMSGVECTOR_BITS_W = 0x8;

struct CMsgVector : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    float x;
    float y;
    float z;
    float w;
};

constexpr uint32_t CMSGVECTOR2D_BITS_X = 0x1;
constexpr uint32_t CMSGVECTOR2D_BITS_Y = 0x2;

struct CMsgVector2D : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    float x;
    float y;
};

constexpr uint32_t CMSGQANGLE_BITS_X = 0x1;
constexpr uint32_t CMSGQANGLE_BITS_Y = 0x2;
constexpr uint32_t CMSGQANGLE_BITS_Z = 0x4;

struct CMsgQAngle : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    float x;
    float y;
    float z;
};

// ---- Core UserCmd chain -------------------------------------------------

constexpr uint32_t CINBUTTONSTATEPB_BITS_BUTTONSTATE1 = 0x1;
constexpr uint32_t CINBUTTONSTATEPB_BITS_BUTTONSTATE2 = 0x2;
constexpr uint32_t CINBUTTONSTATEPB_BITS_BUTTONSTATE3 = 0x4;

struct CInButtonStatePB : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    uint64_t buttonstate1;
    uint64_t buttonstate2;
    uint64_t buttonstate3;
};

constexpr uint32_t CSUBTICKMOVESTEP_BITS_BUTTON = 0x1;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_PRESSED = 0x2;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_WHEN = 0x4;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_ANALOG_FORWARD_DELTA = 0x8;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_ANALOG_LEFT_DELTA = 0x10;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_PITCH_DELTA = 0x20;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_YAW_DELTA = 0x40;

struct CSubtickMoveStep : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    uint64_t button;
    bool pressed;
    float when;
    float analog_forward_delta;
    float analog_left_delta;
    float pitch_delta;
    float yaw_delta;
};

constexpr uint32_t CBASEUSERCMDEXECUTIONNOTES_BITS_IGNORED_REASON = 0x1;

struct CBaseUserCmdExecutionNotes : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    std::string* ignored_reason;
};

constexpr uint32_t CBASEUSERCMDPB_BITS_MOVE_CRC = 0x1;
constexpr uint32_t CBASEUSERCMDPB_BITS_BUTTONS_PB = 0x2;
constexpr uint32_t CBASEUSERCMDPB_BITS_VIEWANGLES = 0x4;
constexpr uint32_t CBASEUSERCMDPB_BITS_EXECUTION_NOTES = 0x8;
constexpr uint32_t CBASEUSERCMDPB_BITS_LEGACY_COMMAND_NUMBER = 0x10;
constexpr uint32_t CBASEUSERCMDPB_BITS_CLIENT_TICK = 0x20;
constexpr uint32_t CBASEUSERCMDPB_BITS_FORWARDMOVE = 0x40;
constexpr uint32_t CBASEUSERCMDPB_BITS_LEFTMOVE = 0x80;
constexpr uint32_t CBASEUSERCMDPB_BITS_UPMOVE = 0x100;
constexpr uint32_t CBASEUSERCMDPB_BITS_IMPULSE = 0x200;
constexpr uint32_t CBASEUSERCMDPB_BITS_WEAPONSELECT = 0x400;
constexpr uint32_t CBASEUSERCMDPB_BITS_RANDOM_SEED = 0x800;
constexpr uint32_t CBASEUSERCMDPB_BITS_MOUSEDX = 0x1000;
constexpr uint32_t CBASEUSERCMDPB_BITS_MOUSEDY = 0x2000;
constexpr uint32_t CBASEUSERCMDPB_BITS_PREDICTION_OFFSET_TICKS_X256 = 0x4000;
constexpr uint32_t CBASEUSERCMDPB_BITS_CONSUMED_SERVER_ANGLE_CHANGES = 0x8000;
constexpr uint32_t CBASEUSERCMDPB_BITS_CMD_FLAGS = 0x10000;
constexpr uint32_t CBASEUSERCMDPB_BITS_PAWN_ENTITY_HANDLE = 0x20000;

struct CBaseUserCmdPB : PBMessage                                   // +0: vtable, +8: metadata
{
    uint32_t has_bits;                                              // +16
    uint32_t cached_size;                                           // +20
    RepeatedPtrField_t<CSubtickMoveStep> subtick_moves;             // +24: arena, +32:cur/tot, +40:rep
    std::string* move_crc;                                          // +48
    CInButtonStatePB* buttons_pb;                                   // +56
    CMsgQAngle* viewangles;                                         // +64
    CBaseUserCmdExecutionNotes* execution_notes;                    // +72
    int32_t legacy_command_number;                                  // +80
    int32_t client_tick;                                            // +84
    float forwardmove;                                              // +88
    float leftmove;                                                 // +92
    float upmove;                                                   // +96
    int32_t impulse;                                                // +100
    int32_t weaponselect;                                           // +104
    int32_t random_seed;                                            // +108
    int32_t mousedx;                                                // +112
    int32_t mousedy;                                                // +116
    uint32_t prediction_offset_ticks_x256;                          // +120
    uint32_t consumed_server_angle_changes;                         // +124
    int32_t cmd_flags;                                              // +128
    uint32_t pawn_entity_handle;                                    // +132
};                                                                  // total = 136 bytes ✓

constexpr uint32_t CUSERCMDBASEPB_BITS_BASE = 0x1;

struct CUserCmdBasePB : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    CBaseUserCmdPB* base;
};

constexpr uint32_t CSGOINTERPOLATIONINFOPB_BITS_FRAC = 0x1;
constexpr uint32_t CSGOINTERPOLATIONINFOPB_BITS_SRC_TICK = 0x2;
constexpr uint32_t CSGOINTERPOLATIONINFOPB_BITS_DST_TICK = 0x4;

struct CSGOInterpolationInfoPB : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    float frac;
    int32_t src_tick;
    int32_t dst_tick;
};

constexpr uint32_t CSGOINTERPOLATIONINFOPB_CL_BITS_FRAC = 0x1;

struct CSGOInterpolationInfoPB_CL : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    float frac;
};

constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_VIEW_ANGLES = 0x1;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_CL_INTERP = 0x2;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_SV_INTERP0 = 0x4;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_SV_INTERP1 = 0x8;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_PLAYER_INTERP = 0x10;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_SHOOT_POSITION = 0x20;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_TARGET_HEAD_POS_CHECK = 0x40;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_TARGET_ABS_POS_CHECK = 0x80;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_TARGET_ABS_ANG_CHECK = 0x100;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_RENDER_TICK_COUNT = 0x200;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_RENDER_TICK_FRACTION = 0x400;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_PLAYER_TICK_COUNT = 0x800;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_PLAYER_TICK_FRACTION = 0x1000;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_FRAME_NUMBER = 0x2000;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_TARGET_ENT_INDEX = 0x4000;

struct CSGOInputHistoryEntryPB : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    CMsgQAngle* view_angles;
    CSGOInterpolationInfoPB_CL* cl_interp;
    CSGOInterpolationInfoPB* sv_interp0;
    CSGOInterpolationInfoPB* sv_interp1;
    CSGOInterpolationInfoPB* player_interp;
    CMsgVector* shoot_position;
    CMsgVector* target_head_pos_check;
    CMsgVector* target_abs_pos_check;
    CMsgQAngle* target_abs_ang_check;
    int32_t render_tick_count;
    float render_tick_fraction;
    int32_t player_tick_count;
    float player_tick_fraction;
    int32_t frame_number;
    int32_t target_ent_index;
};

constexpr uint32_t CSGOUSERCMDPB_BITS_BASE = 0x1;
constexpr uint32_t CSGOUSERCMDPB_BITS_LEFT_HAND_DESIRED = 0x2;
constexpr uint32_t CSGOUSERCMDPB_BITS_IS_PREDICTING_BODY_SHOT_FX = 0x4;
constexpr uint32_t CSGOUSERCMDPB_BITS_IS_PREDICTING_HEAD_SHOT_FX = 0x8;
constexpr uint32_t CSGOUSERCMDPB_BITS_IS_PREDICTING_KILL_RAGDOLLS = 0x10;
constexpr uint32_t CSGOUSERCMDPB_BITS_ATTACK1_START_HISTORY_INDEX = 0x20;
constexpr uint32_t CSGOUSERCMDPB_BITS_ATTACK2_START_HISTORY_INDEX = 0x40;

struct CSGOUserCmdPB : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    RepeatedPtrField_t<CSGOInputHistoryEntryPB> input_history;
    CBaseUserCmdPB* base;
    bool left_hand_desired;
    bool is_predicting_body_shot_fx;
    bool is_predicting_head_shot_fx;
    bool is_predicting_kill_ragdolls;
    int32_t attack1_start_history_index;
    int32_t attack2_start_history_index;
};
