// ============================================================================
// CS2 protobuf arena allocator wrapper.
//
// Reproduces FVA `sub_7FFBE80FAD0C` (NewMaybeArena_CBaseUserCmdPB) by
// calling CS2's IDENTICAL implementation compiled into client.dll.
//
// Live-verified on legacy depot 2347770 (client.dll MD5
// b0fd08261be12cceb8e5636500e5a1d0):
//    RVA 0x4B21E0  → live 0x7FFB65A821E0
//
// Disambiguated from other 0x88-byte protobuf NewMaybeArena wrappers via
// the RTTI type descriptor string `.?AVCBaseUserCmdPB@@` at RVA 0x211F1910
// (referenced by the function's arena-path `lea r8, [rip+…]`).
//
// Signature: `void* __fastcall(google::protobuf::Arena* arena)`.
//   - If arena != null: arena-allocate 0x88 bytes + in-place init
//   - If arena == null: heap-allocate 0x88 bytes + in-place init
//   - Init installs vtable, sets numeric-block sentinel 0xFFFFFF at +0x84
// ============================================================================
#pragma once

namespace valve::pb::raw { struct CBaseUserCmdPB; }

namespace fva::protobuf_alloc
{

// Resolve CS2's NewMaybeArena_CBaseUserCmdPB pointer.  Verifies the byte
// fingerprint at the expected RVA to catch client.dll drift; returns false
// if the prologue bytes don't match, in which case the allocator is not
// wired and the caller must skip the null-base path.
bool init();

// Allocate a new CBaseUserCmdPB.  If `arena` is non-null it goes into
// the CS2 protobuf arena; otherwise it's heap-allocated.  Returns null on
// failure.  Requires init() to have succeeded.
[[nodiscard]] valve::pb::raw::CBaseUserCmdPB* new_cbaseusercmdpb(void* arena);

[[nodiscard]] bool ready() noexcept;

} // namespace fva::protobuf_alloc
