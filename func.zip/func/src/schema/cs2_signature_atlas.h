// ============================================================================
// CS2 signature atlas — 139 patterns for all functions FVA / rage cheats
// commonly hook or read.  User-provided authoritative reference (2026-07-10).
//
// Source depot:  C:\tmp\DepotDownloader   (community-shared CS2 build)
// Pattern check:  09/07/2026 - all 139 verified UPDATED
// Coverage:  GameOverlayRenderer64.dll (1), client.dll (~110),
//            materialsystem2.dll (1), soundsystem.dll (1), scenesystem.dll (7),
//            engine2.dll (7), tier0.dll (1)
//
// NOTE: These are the WIDER cheat-relevant surface, not FVA-specific.  FVA
// only hooks 4 targets (H1..H4) of which 3 are real.  The others are useful
// for future feature parity or diagnostic reads.
// ============================================================================
#pragma once

namespace cs2::sigs
{

// ---- GameOverlayRenderer64.dll (Steam DXGI overlay) ---------------------
constexpr const char* kPresent =
    "48 89 5C 24 ? 48 89 6C 24 ? 56 57 41 54 41 56 41 57 48 83 EC ? 41 8B E8";

// ---- client.dll — hook targets FVA actually cares about -----------------

// H1 candidate — CreateMove (double return, 3 args).  Compare vs FVA's H1
// entry-signature "48 8B C4 44 88 40 18 89" which does NOT match this
// pattern's second byte — FVA's H1 is likely CreateMovePrePrediction,
// an INNER helper invoked from CreateMove, not CreateMove itself.
constexpr const char* kCreateMove =
    "48 8B C4 4C 89 40 ? 48 89 48 ? 55 53 41 54";

constexpr const char* kOverrideView =
    "40 57 48 83 EC ? 48 8B FA E8 ? ? ? ? BA";
constexpr const char* kDrawScopeOverlay =
    "48 8B C4 53 57 48 83 EC ? 48 8B FA";
constexpr const char* kDrawLegs =
    "40 55 53 56 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? F2 0F 10 42";
constexpr const char* kValidateInput =
    "40 53 48 83 EC ? 48 8B D9 E8 ? ? ? ? 33 C0 C6 83 ? ? ? ? 00 48 C7 83";
constexpr const char* kGetViewAngles =
    "4C 8B C1 85 D2 74 ? 48 8D 05";
constexpr const char* kSetViewAngles =
    "85 D2 75 ? 48 63 81";
constexpr const char* kForceButtonsDown =
    "40 53 57 41 56 48 81 EC ? ? ? ? 48 83 79 ? 00";
constexpr const char* kCreateNewSubtickMoveStep =
    "48 89 5C 24 ? 57 48 83 EC ? 33 DB 48 8B F9 48 85 C9 75 ? B9 ? ? ? ? "
    "E8 ? ? ? ? 48 85 C0 74 ? 45 33 C0 33 D2 48 8B C8 E8 ? ? ? ? 48 8B D8";
constexpr const char* kFrameStageNotify =
    "48 89 5C 24 ? 48 89 6C 24 ? 57 48 83 EC ? 48 8B F9 33 ED";
constexpr const char* kLevelInit =
    "48 89 74 24 ? 57 48 83 EC ? 48 8B 0D ? ? ? ? 48 8B FA";
constexpr const char* kLevelShutdown =
    "48 83 EC ? 48 8B 0D ? ? ? ? 48 8D 15 ? ? ? ? 45 33 C9 45 33 C0";

// ---- Signatures used by FVA callees (Phase 4 mutations etc.) ------------
constexpr const char* kComputeRandomSeed =
    "48 89 5C 24 ? 57 48 81 EC ? ? ? ? ? ? ? ? 48 8D 8C 24";
constexpr const char* kUpdateGlobalVars =
    "48 8B 0D ? ? ? ? 4C 8D 05 ? ? ? ? 48 85 D2";
constexpr const char* kGetLocalPawn =
    "48 83 EC ? 83 F9 ? 75 ? 48 8B 0D ? ? ? ? 48 8D 54 24 ? ? ? ? "
    "FF 90 ? ? ? ? ? ? 48 63 C1 4C 8D 05";
constexpr const char* kGetLocalController =
    "48 83 EC ? 83 F9 ? 75 ? 48 8B 0D ? ? ? ? 48 8D 54 24 ? ? ? ? "
    "FF 90 ? ? ? ? ? ? 48 63 C1 48 8D 0D";
constexpr const char* kGetEntityByIndex =
    "4C 8D 49 ? 81 FA";

// ---- engine2.dll --------------------------------------------------------
constexpr const char* kIsInGame =
    "48 8B 05 ? ? ? ? 48 85 C0 74 ? 80 B8 ? ? ? ? 00 75 ? 83 B8 ? ? ? ? ? 7C";
constexpr const char* kIsConnected =
    "48 8B 05 ? ? ? ? 48 85 C0 74 ? 83 B8 ? ? ? ? ? 0F 9D C0";
constexpr const char* kGetLevelName =
    "48 83 EC ? E8 ? ? ? ? 84 C0 74 ? 48 8D 05 ? ? ? ? 48 83 C4 ? C3 "
    "48 8B 0D ? ? ? ? 48 85 C9 74 ? 83 B9 ? ? ? ? ? 7C ? 48 8B 89";

// ---- tier0.dll ----------------------------------------------------------
constexpr const char* kLoadKV3Export =
    "?LoadKV3@@YA_NPEAVKeyValues3@@PEAVCUtlString@@PEBDAEBUKV3ID_t@@2I@Z";

// ---- materialsystem2.dll / soundsystem.dll / scenesystem.dll ------------
constexpr const char* kCreateMaterial =
    "48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 "
    "48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 8B F2";
constexpr const char* kPlayVSND =
    "48 89 5C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 55 48 8D 6C 24 ? "
    "48 81 EC ? ? ? ? 33 F6 C7 45 ? ? ? ? ? 4C 8B C1";

} // namespace cs2::sigs
