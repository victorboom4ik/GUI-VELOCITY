// ============================================================================
// CInput / CUserCmd chain resolver.
//
// Verified DIRECTLY against FuckVacAgain.dll (session aefd8b88, base
// 0x7FFBE80B0000).  Hook A handler `sub_7FFBE80C9D8C` calls the FVA pattern
// parser `sub_7FFBE80DCB84` three times at +0x4EE / +0x5EA / +0x6E6, each
// passing a plain-text IDA-style sig from FVA .rdata and storing the
// resolved address into a dedicated global.
//
// Pattern strings (stored plain-text in FVA .rdata — only the module name
// "client.dll" is XOR-encoded via the 4-qword key):
//
//   sub_7FFBE80CA26C  →  rdx = &"48 83 ec ?? 83 f9 ?? 75 ?? …"    (0x7FFBE820A000)
//                       → qword_7FFBE823A948 = GetSlotInput
//   sub_7FFBE80CA368  →  rdx = &"48 83 EC 28 E8 ?? ?? ?? ?? 8B 80" (0x7FFBE820A0E0)
//                       → qword_7FFBE823A968 = GetCurrentSequence
//   sub_7FFBE80CA464  →  rdx = &"40 53 48 83 EC 20 8B DA E8 ?? ?? ?? ?? 4C"
//                                                              (0x7FFBE820A120)
//                       → qword_7FFBE823A950 = GetCmdBySequence
//
// Live-verified in CS2 pid 79568 on 2026-07-10:
//   qword_7FFBE823A948 = 0x7FFB65EB3930  (client.dll+0x8E3930)  GetSlotInput
//   qword_7FFBE823A950 = 0x7FFB65E905E0  (client.dll+0x8C05E0)  GetCmdBySequence
//   qword_7FFBE823A968 = 0x7FFB65E8D900  (client.dll+0x8BD900)  GetCurrentSequence
//
// Our reconstruction uses the SAME plain-text patterns and the SAME
// signature scanner, so `init()` resolves to the byte-identical addresses.
// ============================================================================
#pragma once

#include "cbaseusercmdpb_layout.h"
#include <cstdint>

namespace fva::client_input
{

// One-shot init — pattern-scan the three functions inside client.dll.
// Returns true iff all three resolved.  Idempotent.
bool init();

// Wrappers.  Return null if init() failed or the underlying call returned
// null (menu-state / invalid slot).
[[nodiscard]] void*                          get_slot_input(int slot) noexcept;
[[nodiscard]] int                            get_current_sequence(void* input) noexcept;
[[nodiscard]] valve::pb::raw::CUserCmd*      get_cmd_by_sequence(void* input, int seq) noexcept;

// Convenience: full chain slot=0 → cmd for the local player.  Returns null
// if any step in the chain fails.
[[nodiscard]] valve::pb::raw::CUserCmd*      current_local_cmd() noexcept;

} // namespace fva::client_input
