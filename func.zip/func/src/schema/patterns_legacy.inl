// ============================================================================
// Legacy-depot pattern manifest — only the anchors we actually use.
//
// Runtime-verified via CheatEngine aob_scan_module on cs2 pid 79568 attached
// to the DepotDownloader legacy build:
//    app 730
//    depot 2347770 manifest 7169488960211596754
//    depot 2347771 manifest 3747240284300062741
//
// Live client.dll module base @ 0x7FFB655D0000.
// ============================================================================
#pragma once

#include <string_view>

namespace fva::patterns_legacy
{

// ------ Hook target anchors (all in client.dll) -----------------------------

// Hook A — CInput::CreateMove side.  RVA 0xACEF90 → live 0x7FFB6609EF90.
inline constexpr std::string_view HookA_CreateMoveSide =
    "48 8B C4 44 88 40 ? 89 50 ? 48 89 48 ? 55 53 41 54 41 57 48 8D A8 ?";

// Hook B — CBaseClientState::FireLevelInitEvent.  RVA 0xAFDFB0 → live 0x7FFB660CDFB0.
inline constexpr std::string_view HookB_FireLevelInit =
    "48 8D 6C 24 B9 48 81 EC E0 00 00 00 48 8B 0D ? ? ? ? 4C 8B F2 45 33 C9";

// Hook C — MessageLite::SerializeToArray helper.  RVA 0x1189930 → live 0x7FFB66759930.
// POST-PATCH form: matches whether or not FVA already installed its own E9;
// caller must subtract 5 from the returned pointer.  See HookC_offset below.
inline constexpr std::string_view HookC_SerializeToArray =
    "55 56 57 48 81 EC 90 00 00 00 48 8B 05 ? ? ? ? 48 33 C4 48 89 84 24 80 00 00";
inline constexpr std::intptr_t    HookC_offset          = -5;

// ------ Legacy build identification ----------------------------------------

// client.dll on-disk MD5 for the depot 2347770 build.
inline constexpr char kExpectedClientMd5[] =
    "B0FD08261BE12CCEB8E5636500E5A1D0";

// client.dll on-disk size (bytes) — quick sanity check.
inline constexpr std::size_t kExpectedClientSize = 37'272'728;

} // namespace fva::patterns_legacy
