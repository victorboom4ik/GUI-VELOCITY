// ============================================================================
// Ground-truth CS2 protobuf message layout (user-supplied, verified against
// runtime FVA scratch @ 0x7FFBE8234C90 in the legacy depot build).
//
// Design differences from the earlier draft:
//   * All messages inherit from a common `PBMessage` base { vtable, metadata }
//     — matches how Valve's generated protobuf code lays out the vpointer +
//     internal-metadata pair for every message.  16 bytes total.
//   * `RepeatedPtrField_t<T>` = 24 bytes (arena, current_size, total_size,
//     Rep*) — Google-protobuf 3.21.8's real layout.  Earlier draft had the
//     size wrong by 8 bytes; fixed 2026-07-10.
//   * `move_crc` is a `std::string*` field (protobuf `bytes` value), not a
//     CRC32 integer.  Hook A does NOT need to recompute a CRC — the server
//     validates the string as raw bytes.
//   * Every has_bits mask is now enumerated as a named constant so the
//     mutation code reads like the .proto definition instead of magic
//     numbers.
// ============================================================================
#pragma once

// The project defines NOMINMAX from the top-level CMake — do NOT redefine here.
#include <Windows.h>
#include <cstdint>
#include <cstddef>
#include <limits>
#include <string>

namespace valve::pb::raw
{

//----------------------------------------------------------------------------
// Google-protobuf primitives
//----------------------------------------------------------------------------

template <typename T>
struct RepeatedPtrField_t
{
    struct Rep_t
    {
        int allocated_size;
        T*  elements[(std::numeric_limits<int>::max() - 2 * sizeof(int)) / sizeof(void*)];
    };

    void*  arena;         // +0x00
    int    current_size;  // +0x08
    int    total_size;    // +0x0C
    Rep_t* rep;           // +0x10
};

struct PBMessage
{
    void* vtable;      // +0x00
    void* metadata;    // +0x08  (== google::protobuf::internal::InternalMetadata)
};

//----------------------------------------------------------------------------
// Vector / Angle wrappers
//----------------------------------------------------------------------------

constexpr uint32_t CMSGVECTOR_BITS_X = 0x1;
constexpr uint32_t CMSGVECTOR_BITS_Y = 0x2;
constexpr uint32_t CMSGVECTOR_BITS_Z = 0x4;
constexpr uint32_t CMSGVECTOR_BITS_W = 0x8;

struct CMsgVector : PBMessage
{
    uint32_t has_bits;      // +0x10
    uint32_t cached_size;   // +0x14
    float    x;             // +0x18
    float    y;             // +0x1C
    float    z;             // +0x20
    float    w;             // +0x24  (unused for QAngle)
};

constexpr uint32_t CMSGQANGLE_BITS_X = 0x1;
constexpr uint32_t CMSGQANGLE_BITS_Y = 0x2;
constexpr uint32_t CMSGQANGLE_BITS_Z = 0x4;

struct CMsgQAngle : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    float    x;             // pitch
    float    y;             // yaw
    float    z;             // roll
};

//----------------------------------------------------------------------------
// Button-state / subtick-move
//----------------------------------------------------------------------------

constexpr uint32_t CINBUTTONSTATEPB_BITS_BUTTONSTATE1 = 0x1;
constexpr uint32_t CINBUTTONSTATEPB_BITS_BUTTONSTATE2 = 0x2;
constexpr uint32_t CINBUTTONSTATEPB_BITS_BUTTONSTATE3 = 0x4;

struct CInButtonStatePB : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    uint64_t buttonstate1;
    uint64_t buttonstate2;
    uint64_t buttonstate3;
};

constexpr uint32_t CSUBTICKMOVESTEP_BITS_BUTTON               = 0x01;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_PRESSED              = 0x02;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_WHEN                 = 0x04;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_ANALOG_FORWARD_DELTA = 0x08;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_ANALOG_LEFT_DELTA    = 0x10;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_PITCH_DELTA          = 0x20;
constexpr uint32_t CSUBTICKMOVESTEP_BITS_YAW_DELTA            = 0x40;

struct CSubtickMoveStep : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    uint64_t button;
    bool     pressed;
    float    when;
    float    analog_forward_delta;
    float    analog_left_delta;
    float    pitch_delta;      // ← FVA writes here
    float    yaw_delta;        // ← FVA writes here
};

//----------------------------------------------------------------------------
// Execution notes (optional metadata payload attached to a usercmd)
//----------------------------------------------------------------------------

constexpr uint32_t CBASEUSERCMDEXECUTIONNOTES_BITS_IGNORED_REASON = 0x01;

struct CBaseUserCmdExecutionNotes : PBMessage
{
    uint32_t     has_bits;
    uint32_t     cached_size;
    std::string* ignored_reason;
};

//----------------------------------------------------------------------------
// CBaseUserCmdPB — main target of FVA mutation.
//----------------------------------------------------------------------------

constexpr uint32_t CBASEUSERCMDPB_BITS_MOVE_CRC                       = 0x00001;
constexpr uint32_t CBASEUSERCMDPB_BITS_BUTTONS_PB                     = 0x00002;
constexpr uint32_t CBASEUSERCMDPB_BITS_VIEWANGLES                     = 0x00004;
constexpr uint32_t CBASEUSERCMDPB_BITS_EXECUTION_NOTES                = 0x00008;
constexpr uint32_t CBASEUSERCMDPB_BITS_LEGACY_COMMAND_NUMBER          = 0x00010;
constexpr uint32_t CBASEUSERCMDPB_BITS_CLIENT_TICK                    = 0x00020;
constexpr uint32_t CBASEUSERCMDPB_BITS_FORWARDMOVE                    = 0x00040;
constexpr uint32_t CBASEUSERCMDPB_BITS_LEFTMOVE                       = 0x00080;
constexpr uint32_t CBASEUSERCMDPB_BITS_UPMOVE                         = 0x00100;
constexpr uint32_t CBASEUSERCMDPB_BITS_IMPULSE                        = 0x00200;
constexpr uint32_t CBASEUSERCMDPB_BITS_WEAPONSELECT                   = 0x00400;
constexpr uint32_t CBASEUSERCMDPB_BITS_RANDOM_SEED                    = 0x00800;
constexpr uint32_t CBASEUSERCMDPB_BITS_MOUSEDX                        = 0x01000;
constexpr uint32_t CBASEUSERCMDPB_BITS_MOUSEDY                        = 0x02000;
constexpr uint32_t CBASEUSERCMDPB_BITS_PREDICTION_OFFSET_TICKS_X256   = 0x04000;
constexpr uint32_t CBASEUSERCMDPB_BITS_CONSUMED_SERVER_ANGLE_CHANGES  = 0x08000;
constexpr uint32_t CBASEUSERCMDPB_BITS_CMD_FLAGS                      = 0x10000;
constexpr uint32_t CBASEUSERCMDPB_BITS_PAWN_ENTITY_HANDLE             = 0x20000;

struct CBaseUserCmdPB : PBMessage
{
    uint32_t                              has_bits;              // +0x10
    uint32_t                              cached_size;           // +0x14
    RepeatedPtrField_t<CSubtickMoveStep>  subtick_moves;         // +0x18 (24 bytes)
    std::string*                          move_crc;              // +0x30  ← protobuf bytes, NOT a computed CRC
    CInButtonStatePB*                     buttons_pb;            // +0x38  ← FVA writes
    CMsgQAngle*                           viewangles;            // +0x40  ← FVA writes
    CBaseUserCmdExecutionNotes*           execution_notes;       // +0x48  ← FVA writes
    int32_t                               legacy_command_number; // +0x50
    int32_t                               client_tick;           // +0x54
    float                                 forwardmove;           // +0x58  ← movement
    float                                 leftmove;              // +0x5C  ← movement
    float                                 upmove;                // +0x60  ← movement (jump/duck)
    int32_t                               impulse;               // +0x64
    int32_t                               weaponselect;          // +0x68
    int32_t                               random_seed;           // +0x6C  ← FVA writes (predictable RNG)
    int32_t                               mousedx;               // +0x70
    int32_t                               mousedy;               // +0x74
    uint32_t                              prediction_offset_ticks_x256;   // +0x78
    uint32_t                              consumed_server_angle_changes;  // +0x7C
    int32_t                               cmd_flags;             // +0x80
    uint32_t                              pawn_entity_handle;    // +0x84
};

//----------------------------------------------------------------------------
// CSGO input history — VAC correlation triplet target
//----------------------------------------------------------------------------

constexpr uint32_t CSGOINTERPOLATIONINFOPB_BITS_FRAC     = 0x1;
constexpr uint32_t CSGOINTERPOLATIONINFOPB_BITS_SRC_TICK = 0x2;
constexpr uint32_t CSGOINTERPOLATIONINFOPB_BITS_DST_TICK = 0x4;

struct CSGOInterpolationInfoPB : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    float    frac;
    int32_t  src_tick;
    int32_t  dst_tick;
};

constexpr uint32_t CSGOINTERPOLATIONINFOPB_CL_BITS_FRAC = 0x1;

struct CSGOInterpolationInfoPB_CL : PBMessage
{
    uint32_t has_bits;
    uint32_t cached_size;
    float    frac;
};

constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_VIEW_ANGLES           = 0x0001;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_CL_INTERP             = 0x0002;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_SV_INTERP0            = 0x0004;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_SV_INTERP1            = 0x0008;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_PLAYER_INTERP         = 0x0010;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_SHOOT_POSITION        = 0x0020;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_TARGET_HEAD_POS_CHECK = 0x0040;  // VAC
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_TARGET_ABS_POS_CHECK  = 0x0080;  // VAC
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_TARGET_ABS_ANG_CHECK  = 0x0100;  // VAC
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_RENDER_TICK_COUNT     = 0x0200;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_RENDER_TICK_FRACTION  = 0x0400;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_PLAYER_TICK_COUNT     = 0x0800;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_PLAYER_TICK_FRACTION  = 0x1000;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_FRAME_NUMBER          = 0x2000;
constexpr uint32_t CSGOINPUTHISTORYENTRYPB_BITS_TARGET_ENT_INDEX      = 0x4000;

struct CSGOInputHistoryEntryPB : PBMessage
{
    uint32_t                     has_bits;
    uint32_t                     cached_size;
    CMsgQAngle*                  view_angles;               // +0x18
    CSGOInterpolationInfoPB_CL*  cl_interp;                 // +0x20
    CSGOInterpolationInfoPB*     sv_interp0;                // +0x28
    CSGOInterpolationInfoPB*     sv_interp1;                // +0x30
    CSGOInterpolationInfoPB*     player_interp;             // +0x38
    CMsgVector*                  shoot_position;            // +0x40
    CMsgVector*                  target_head_pos_check;     // +0x48  ← VAC
    CMsgVector*                  target_abs_pos_check;      // +0x50  ← VAC
    CMsgQAngle*                  target_abs_ang_check;      // +0x58  ← VAC
    int32_t                      render_tick_count;         // +0x60
    float                        render_tick_fraction;      // +0x64
    int32_t                      player_tick_count;         // +0x68
    float                        player_tick_fraction;      // +0x6C
    int32_t                      frame_number;              // +0x70
    int32_t                      target_ent_index;          // +0x74
};

//----------------------------------------------------------------------------
// CSGOUserCmdPB — wraps CBaseUserCmdPB + input_history
//----------------------------------------------------------------------------

constexpr uint32_t CSGOUSERCMDPB_BITS_BASE                        = 0x01;
constexpr uint32_t CSGOUSERCMDPB_BITS_LEFT_HAND_DESIRED            = 0x02;
constexpr uint32_t CSGOUSERCMDPB_BITS_IS_PREDICTING_BODY_SHOT_FX   = 0x04;
constexpr uint32_t CSGOUSERCMDPB_BITS_IS_PREDICTING_HEAD_SHOT_FX   = 0x08;
constexpr uint32_t CSGOUSERCMDPB_BITS_IS_PREDICTING_KILL_RAGDOLLS  = 0x10;
constexpr uint32_t CSGOUSERCMDPB_BITS_ATTACK1_START_HISTORY_INDEX  = 0x20;
constexpr uint32_t CSGOUSERCMDPB_BITS_ATTACK2_START_HISTORY_INDEX  = 0x40;

struct CSGOUserCmdPB : PBMessage
{
    uint32_t                                    has_bits;
    uint32_t                                    cached_size;
    RepeatedPtrField_t<CSGOInputHistoryEntryPB> input_history;               // +0x18 (24 bytes)
    CBaseUserCmdPB*                             base;                        // +0x30  ← FVA Hook C target
    bool                                        left_hand_desired;           // +0x38
    bool                                        is_predicting_body_shot_fx;  // +0x39
    bool                                        is_predicting_head_shot_fx;  // +0x3A
    bool                                        is_predicting_kill_ragdolls; // +0x3B
    int32_t                                     attack1_start_history_index; // +0x3C
    int32_t                                     attack2_start_history_index; // +0x40
};

//----------------------------------------------------------------------------
// CUserCmd — CS2's INTERNAL C++ wrapper (NOT a protobuf message).
//
// Layout derived DIRECTLY from FVA Hook A disasm
// (sub_7FFBE80C9D8C @ +0x11FE .. +0x1470):
//   +0x11FE  or dword ptr [rbx+20h], 1        ← flags |= 1
//   +0x1202  mov rax, [rbx+40h]               ← base pointer
//   +0x1206  test rax, rax
//   +0x1220  mov rax, [rbx+40h]               ← re-read base
//   +0x123X  mov rcx, [rbx+18h]               ← arena tag
//   +0x125X  test byte ptr [rbx+18h], 1       ← arena tag low bit
//
// This struct is what CS2 hands to Hook A as `raw_cmd` (rbx).  It holds
// CS2-side game state PLUS a pointer to the wire-format CBaseUserCmdPB at
// +0x40.
//
// Offsets (from FVA rbx-relative accesses):
//   +0x08 tick_field (uint32)
//   +0x18 arena_word (tagged pointer to Google-protobuf arena)
//   +0x20 flags   ← Hook A sets bit 0 to signal "mutated"
//   +0x28 subtick_moves_repeated_field   ← Hook A subtick target
//   +0x30 input_history.current_size
//   +0x38 input_history.rep (pointer to RepeatedPtrField Rep struct)
//   +0x40 base (CBaseUserCmdPB*)   ← wire-format payload
//
// NOTE: This is NOT the same as CSGOUserCmdPB (which is what goes on the
// wire).  CSGOUserCmdPB has base at +0x30 per user ground truth; CS2's
// CUserCmd wrapper stores it at +0x40.  The wire-time CSGOUserCmdPB is
// constructed by Valve serialization glue from CUserCmd; Hook A intercepts
// before that step.
//----------------------------------------------------------------------------

struct CUserCmd {
    void*    vtable;                 // +0x00
    uint32_t tick_field;             // +0x08 (with padding to +0x18)
    // +0x0C..+0x18 padded / other CS2 fields (not touched by FVA)
    uint8_t  pad_0x0C[0x0C];
    uintptr_t arena_word;            // +0x18 (tagged pointer)
    uint32_t flags;                  // +0x20 (Hook A sets bit 0)
    uint32_t pad_0x24;
    void*    subtick_moves_field;    // +0x28 — treated as RepeatedPtrField
    uint32_t input_history_size;     // +0x30 (RepeatedPtrField.current_size)
    uint32_t input_history_total;    // +0x34
    void*    input_history_rep;      // +0x38
    CBaseUserCmdPB* base;            // +0x40 — the wire-format payload
};

static_assert(offsetof(CUserCmd, arena_word)         == 0x18, "CUserCmd.arena_word offset");
static_assert(offsetof(CUserCmd, flags)              == 0x20, "CUserCmd.flags offset");
static_assert(offsetof(CUserCmd, input_history_size) == 0x30, "CUserCmd.input_history_size offset");
static_assert(offsetof(CUserCmd, base)               == 0x40, "CUserCmd.base offset");

//----------------------------------------------------------------------------
// Static-size assertions (protect against layout drift)
//----------------------------------------------------------------------------

static_assert(sizeof(PBMessage)        == 0x10, "PBMessage size drifted");
static_assert(sizeof(CInButtonStatePB) == 0x30, "CInButtonStatePB size drifted");
static_assert(sizeof(RepeatedPtrField_t<CSubtickMoveStep>) == 0x18,
              "RepeatedPtrField_t size drifted (expected 24)");

static_assert(offsetof(CBaseUserCmdPB, has_bits)      == 0x10, "has_bits offset");
static_assert(offsetof(CBaseUserCmdPB, subtick_moves) == 0x18, "subtick_moves offset");
static_assert(offsetof(CBaseUserCmdPB, move_crc)      == 0x30, "move_crc offset");
static_assert(offsetof(CBaseUserCmdPB, buttons_pb)    == 0x38, "buttons_pb offset");
static_assert(offsetof(CBaseUserCmdPB, viewangles)    == 0x40, "viewangles offset");
static_assert(offsetof(CBaseUserCmdPB, forwardmove)   == 0x58, "forwardmove offset");
static_assert(offsetof(CBaseUserCmdPB, random_seed)   == 0x6C, "random_seed offset");

static_assert(offsetof(CSGOInputHistoryEntryPB, target_head_pos_check) == 0x48,
              "history target_head_pos_check offset");
static_assert(offsetof(CSGOInputHistoryEntryPB, target_ent_index)      == 0x74,
              "history target_ent_index offset");

static_assert(offsetof(CSGOUserCmdPB, input_history) == 0x18, "input_history offset");
static_assert(offsetof(CSGOUserCmdPB, base)          == 0x30, "base offset");
static_assert(offsetof(CSGOUserCmdPB, attack1_start_history_index) == 0x3C,
              "attack1_start_history_index offset");

} // namespace valve::pb::raw
