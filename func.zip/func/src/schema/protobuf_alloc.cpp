// ============================================================================
// CS2 protobuf arena allocator wrapper — implementation.
//
// Resolution order (mirrors update-proofing recommendation from workflow
// wn61kvd0q Agent 4):
//   1. Sig-scan for the anchor pattern in client.dll .text.
//   2. Fall back to known_rva::new_maybe_arena_cbaseusercmdpb.
//   3. Regardless of which path won, memcmp the first 20 bytes against
//      build_fingerprint::kNewMaybeArenaPrologue.  Any mismatch → init
//      returns false → the null-base guard in create_move_hook.cpp becomes
//      a no-op instead of us calling into the wrong function.
// ============================================================================
#include "protobuf_alloc.h"
#include "cbaseusercmdpb_layout.h"
#include "../core/signature_scanner.h"
#include "../version_manifest.h"

#include <Windows.h>
#include <atomic>
#include <cstdint>
#include <cstring>

namespace fva::protobuf_alloc
{

namespace {

// void* __fastcall(void* arena)
using AllocFn = void*(__fastcall*)(void*);
std::atomic<AllocFn> g_alloc{nullptr};

// Anchor for CS2's NewMaybeArena_CBaseUserCmdPB — same 20-byte prologue as
// the manifest fingerprint (see build_fingerprint::kNewMaybeArenaPrologue).
constexpr std::string_view k_sig_anchor =
    "48 89 5C 24 10 57 48 83 EC 20 33 DB 48 8B F9 48 85 C9 75 2D";

} // namespace

bool init()
{
    HMODULE client = ::GetModuleHandleW(fva::version::module_names::client_dll);
    if (!client) return false;

    // 1. Sig-scan first.
    std::uint8_t* p = static_cast<std::uint8_t*>(
        fva::scanner::find_in_module(client, k_sig_anchor));

    // 2. Fall back to RVA if scan came up empty.
    if (!p) {
        p = reinterpret_cast<std::uint8_t*>(client) +
            fva::version::known_rva::new_maybe_arena_cbaseusercmdpb;
    }

    // 3. Fingerprint gate — the manifest's 20-byte prologue is authoritative
    //    regardless of how we got here.
    namespace bf = fva::version::build_fingerprint;
    if (std::memcmp(p, bf::kNewMaybeArenaPrologue.data(),
                     bf::kNewMaybeArenaPrologue.size()) != 0)
        return false;

    g_alloc.store(reinterpret_cast<AllocFn>(p), std::memory_order_release);
    return true;
}

valve::pb::raw::CBaseUserCmdPB* new_cbaseusercmdpb(void* arena)
{
    auto fn = g_alloc.load(std::memory_order_acquire);
    if (!fn) return nullptr;
    return static_cast<valve::pb::raw::CBaseUserCmdPB*>(fn(arena));
}

bool ready() noexcept
{
    return g_alloc.load(std::memory_order_acquire) != nullptr;
}

} // namespace fva::protobuf_alloc
