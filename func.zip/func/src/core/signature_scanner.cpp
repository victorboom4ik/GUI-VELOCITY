// ============================================================================
// Implementation of the FVA-style signature scanner.
//
// Reversed from FuckVacAgain.dll sub_7FFBE80DCB84 (parser) and
// sub_7FFBE80DCD0C (scanner).  See workflow #1 findings.
// ============================================================================
#include "signature_scanner.h"

#include <Windows.h>
#include <cctype>

namespace fva::scanner
{

namespace {

constexpr int hex_nibble(char c) noexcept
{
    if (c >= '0' && c <= '9') return c - '0';
    const char lower = static_cast<char>(c | 0x20);
    if (lower >= 'a' && lower <= 'f') return lower - 'a' + 10;
    return -1;
}

} // namespace

Pattern parse(std::string_view ida)
{
    Pattern out;
    out.bytes.reserve(ida.size() / 3 + 1);
    out.wildcards.reserve(ida.size() / 3 + 1);

    // FVA's sub_7FFBE80DCB84 tolerates leading/embedded whitespace and
    // '?' as either single-char or "??" wildcard.
    for (std::size_t i = 0; i < ida.size(); )
    {
        const char c = ida[i];
        if (std::isspace(static_cast<unsigned char>(c))) { ++i; continue; }

        if (c == '?')
        {
            out.bytes.push_back(0x00);
            out.wildcards.push_back(true);
            ++i;
            if (i < ida.size() && ida[i] == '?') ++i; // skip "??"
            continue;
        }

        const int hi = hex_nibble(c);
        if (hi < 0) { ++i; continue; } // FVA drops invalid chars silently

        if (i + 1 >= ida.size()) break;
        const int lo = hex_nibble(ida[i + 1]);
        if (lo < 0) { i += 2; continue; }

        out.bytes.push_back(static_cast<std::uint8_t>((hi << 4) | lo));
        out.wildcards.push_back(false);
        i += 2;
    }
    return out;
}

std::uint8_t* find(std::span<std::uint8_t> region, const Pattern& pat) noexcept
{
    if (pat.bytes.empty() || region.size() < pat.bytes.size())
        return nullptr;

    const std::size_t hay_len = region.size();
    const std::size_t pat_len = pat.bytes.size();
    const std::size_t last = hay_len - pat_len;

    // FVA uses a straight forward-scan with wildcard skip.
    // No Boyer-Moore acceleration — this matches the reversed loop exactly.
    for (std::size_t i = 0; i <= last; ++i)
    {
        bool matched = true;
        for (std::size_t j = 0; j < pat_len; ++j)
        {
            if (pat.wildcards[j]) continue;
            if (region[i + j] != pat.bytes[j]) { matched = false; break; }
        }
        if (matched)
            return region.data() + i;
    }
    return nullptr;
}

std::uint8_t* find_in_module(void* module_base, const Pattern& pat) noexcept
{
    if (!module_base || pat.bytes.empty()) return nullptr;

    auto* base = static_cast<std::uint8_t*>(module_base);
    const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return nullptr;

    const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return nullptr;

    // Restrict scan to executable sections (.text and any RX segment).
    const auto* section = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; ++i, ++section)
    {
        if (!(section->Characteristics & IMAGE_SCN_MEM_EXECUTE))
            continue;
        std::span<std::uint8_t> region{
            base + section->VirtualAddress,
            section->Misc.VirtualSize
        };
        if (auto* p = find(region, pat)) return p;
    }
    return nullptr;
}

void* resolve_rip_rel32(std::uint8_t* insn_ptr,
                          std::size_t offset_pos,
                          std::size_t insn_len) noexcept
{
    if (!insn_ptr) return nullptr;
    const std::int32_t rel = *reinterpret_cast<const std::int32_t*>(insn_ptr + offset_pos);
    return insn_ptr + insn_len + rel;
}

} // namespace fva::scanner
