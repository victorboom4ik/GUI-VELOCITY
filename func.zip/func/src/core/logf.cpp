// core/logf.cpp — tiny file-sink helper.
//
// По умолчанию — DEBUG режим: stdout/stderr пишутся в C:\vmp\fva_recon.log,
// session header фиксирует старт сессии.
//
// Отключить (retail без disk IO): FVA_QUIET=1 env-var, или файл
// C:\vmp\.fva_quiet. См. core/debug.h.

#include "signature_scanner.h"
#include "debug.h"

#include <Windows.h>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <io.h>
#include <share.h>

namespace fva::log
{

void install_file_sink()
{
    const bool dbg = fva::debug::enabled();

    // По умолчанию (retail): stdout/stderr → NUL. Cost = ~0 per printf
    // потому что MSVCRT сразу discardит. Alternative — hook printf в no-op —
    // это ~200 call sites рефакторить. NUL-routing даёт тот же эффект без
    // изменений остального кода.
    const char* target = dbg ? "C:\\vmp\\fva_recon.log" : "NUL";

    FILE* f = ::_fsopen(target, "a", _SH_DENYNO);
    if (!f) return;
    std::setvbuf(f, nullptr, _IONBF, 0);

    int fd = ::_fileno(f);
    if (fd >= 0) {
        ::_dup2(fd, ::_fileno(stdout));
        ::_dup2(fd, ::_fileno(stderr));
        std::setvbuf(stdout, nullptr, _IONBF, 0);
        std::setvbuf(stderr, nullptr, _IONBF, 0);
    }

    if (dbg) {
        SYSTEMTIME st{}; ::GetLocalTime(&st);
        std::fprintf(stdout,
            "\n=== fva_recon session %04u-%02u-%02u %02u:%02u:%02u pid=%lu ===\n",
            st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond,
            ::GetCurrentProcessId());
        std::fflush(stdout);
    }
}

// Probe for CSubtickMoveStep's default_instance vtable pointer.  Approach:
// look for the standard protobuf-generated constructor prologue that stores
// the vtable qword at [rcx+0] — the classical shape in a Valve build is:
//     lea rax, cs:CSubtickMoveStep_vtable  ; 48 8D 05 rel32
//     mov [rcx], rax                        ; 48 89 01
// which becomes the byte pattern "48 8D 05 ?? ?? ?? ?? 48 89 01".  It may
// appear more than once (constructor + placement-new helpers); we take the
// first hit and follow the LEA rel32.  Returns nullptr on miss.
void* find_csubtick_vtable()
{
    HMODULE client = ::GetModuleHandleW(L"client.dll");
    if (!client) return nullptr;
    void* hit = fva::scanner::find_in_module(client,
        "48 8D 05 ? ? ? ? 48 89 01", 0);
    if (!hit) return nullptr;
    auto* p = reinterpret_cast<std::uint8_t*>(hit);
    std::int32_t rel32;
    std::memcpy(&rel32, p + 3, 4);
    // LEA is 7 bytes total (48 8D 05 imm32).
    return p + 7 + rel32;
}

// Probe for CS2's protobuf Arena::AllocateAligned.  This is the equivalent
// of FVA's sub_7FFBE81029A0 (which sub_7FFBE8103070 is a thunk to).
//
// CORRECTED 2026-07-11 via IDA disasm verification of FVA sub_7FFBE81029A0:
//     mov  [rsp+8], rbx                48 89 5C 24 08
//     push rbp                          55
//     push rsi                          56
//     push rdi                          57
//     push r14                          41 56
//     push r15                          41 57
//     sub  rsp, 30h                     48 83 EC 30
//     test byte ptr [rcx+8], 2          F6 41 08 02   ← distinctive: arena flags check
//     mov  r14, r8                      4C 8B F0      (rtti_type_descriptor in r8)
//     mov  rdi, rdx                     48 8B FA      (size in rdx)
//     mov  rbx, rcx                     48 8B D9      (arena in rcx)
//
// The prior sig (`48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 20 49 8B F0 ...`)
// was WRONG — it misread the arg-save area order and used the wrong
// destination register for the r8→rXX save.  Corrected below.
//
// Returns nullptr if the pattern misses (Valve reorganised the arena API).
using ArenaAllocFn = void*(__fastcall*)(void* arena, std::size_t size,
                                          const void* rtti);
void* find_arena_allocator()
{
    HMODULE client = ::GetModuleHandleW(L"client.dll");
    if (!client) return nullptr;
    void* hit = fva::scanner::find_in_module(client,
        "48 89 5C 24 08 55 56 57 41 56 41 57 48 83 EC 30 F6 41 08 02 "
        "4C 8B F0 48 8B FA 48 8B D9",
        0);
    return hit;
}

} // namespace fva::log
