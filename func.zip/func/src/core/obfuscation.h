// ============================================================================
// FVA obfuscation primitives — reproduces the two mechanisms the shipped
// FuckVacAgain.dll uses in its own code:
//
//   1. Stack-slotted XOR pair — FVA loads two 8-byte immediates on the
//      stack (encrypted), then loads a two-qword key from another slot pair,
//      then does `vpxor xmm1, xmm0, xmm_key` to decode 16 bytes in place.
//      Used at Hook C entry for the "CBaseUserCmdPB" typename comparison
//      (sub_7FFBE80C9B9C at +0x84..+0xA0).
//
//   2. FNV-1a 64-bit — used at
//      Hook A `sub_7FFBE80C9520` (FindConvarByHash) which hashes each ConVar
//      name and compares against the caller-supplied constant.
//
// Anything not in this list is invented and does NOT live in this file.
// ============================================================================
#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>

namespace fva::obf
{

// Decode a 16-byte stack-slot pair into ASCII.  Reproduces FVA's
// `vpxor xmm1, xmm0, xmmword ptr [key]` decode used at Hook C entry.
// The two decoded qwords are read in little-endian byte order and trailing
// NULs are trimmed (protobuf typenames are NUL-padded to 16 bytes).
inline std::string decode_qword_pair(std::uint64_t enc0, std::uint64_t enc1,
                                       std::uint64_t key0, std::uint64_t key1)
{
    std::array<std::uint8_t, 16> out{};
    const std::uint64_t p0 = enc0 ^ key0;
    const std::uint64_t p1 = enc1 ^ key1;
    for (int i = 0; i < 8; ++i)
    {
        out[i]     = static_cast<std::uint8_t>((p0 >> (i * 8)) & 0xFF);
        out[i + 8] = static_cast<std::uint8_t>((p1 >> (i * 8)) & 0xFF);
    }
    std::string s(reinterpret_cast<const char*>(out.data()), 16);
    while (!s.empty() && s.back() == '\0') s.pop_back();
    return s;
}

// FNV-1a 64-bit (basis 0xCBF29CE484222325, prime 0x100000001B3).
// Reproduces the exact loop inside FVA `sub_7FFBE80C9520`:
//   h = basis
//   for c in name:
//     h = (h ^ c) * prime
[[nodiscard]] constexpr std::uint64_t fnv1a(std::string_view s) noexcept
{
    std::uint64_t h = 0xCBF29CE484222325ULL;
    for (unsigned char c : s) {
        h ^= c;
        h *= 0x100000001B3ULL;
    }
    return h;
}

} // namespace fva::obf
