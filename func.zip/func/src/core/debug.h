// core/debug.h — единая точка контроля debug-режима fva_recon.
//
// По умолчанию — ON: пишется C:\vmp\fva_recon.log с полной диагностикой.
//
// Отключить (retail без disk IO):
//   set FVA_QUIET=1     ИЛИ    создать файл C:\vmp\.fva_quiet
//
// Кэш at first-call, cheap thereafter (`static bool`).

#pragma once

#include <windows.h>
#include <cstdio>

namespace fva::debug {

inline bool enabled() noexcept
{
    static const bool cached = []() -> bool {
        // Explicit quiet opt-out через env-var
        char buf[8] = {};
        DWORD n = ::GetEnvironmentVariableA("FVA_QUIET", buf, sizeof(buf));
        if (n > 0 && (buf[0] == '1' || buf[0] == 'y' || buf[0] == 'Y')) {
            return false;
        }
        // Или file marker (можно создать без перезапуска cs2)
        DWORD attr = ::GetFileAttributesA("C:\\vmp\\.fva_quiet");
        if (attr != INVALID_FILE_ATTRIBUTES) return false;
        // Default: enabled (debug logging on)
        return true;
    }();
    return cached;
}

}  // namespace fva::debug
