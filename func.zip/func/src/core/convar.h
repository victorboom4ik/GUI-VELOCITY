// ============================================================================
// FVA CVar lookup.
//
// Reproduces FVA `sub_7FFBE80C9520` (FindConvarByHash): a walk over a
// 16-byte hash-node table rooted at what FVA caches in
// `qword_7FFBE823A9B0`.  FVA fills that root by dereferencing
// tier0!VEngineCvar007 → +0x48 (legacy hash-root ptr).
//
// Live-verified 2026-07-10 on legacy depot 2347770:
//   qword_7FFBE823A9B0  = 0x7FFC610C93B0 (tier0.dll+0x3A93B0)
//   root+0x48 (table)   = 0x04DB960B0000
//   root+0x50 (start)   = 0x0FAA (4010)
//   first walked ConVar = "nav_corner_adjust_adjacent"
// ============================================================================
#pragma once

#include <cstdint>

namespace fva::convar
{

// One-shot init — resolve tier0.dll!CreateInterface, call VEngineCvar007,
// derive the legacy hash root from icvar+0x48.  Must be called after
// tier0.dll is loaded.  Idempotent.
bool wire_icvar();

// Return the ConVar* whose name FNV-1a-hashes to `fnv_hash`, or nullptr.
[[nodiscard]] void* find_by_hash(std::uint64_t fnv_hash);

// Byte offset of the CVar value slot on the OLD depot build (2347770).
// FVA writes a single 0 byte here to zero the ConVar during Phase 1.
inline constexpr std::uintptr_t k_convar_value_offset = 0x58;

} // namespace fva::convar
