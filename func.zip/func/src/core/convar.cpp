// ============================================================================
// FVA CVar lookup — implementation.
// See convar.h for context.  Reproduces FVA `sub_7FFBE80C9520` semantics.
// ============================================================================
#include "convar.h"
#include "obfuscation.h"

#include <Windows.h>
#include <algorithm>
#include <cstdint>
#include <cstddef>
#include <cstdio>

namespace fva::convar
{

namespace {

using CreateInterfaceFn = void*(__cdecl*)(const char* name, int* return_code);

// Runtime cache — mirrors FVA's own `qword_7FFBE823A9B0` (hash-root pointer).
void* g_hash_root = nullptr;

//----------------------------------------------------------------------------
// Safe-memory helpers — VirtualQuery-gated readers so we never fault on a
// bogus pointer from a stale build.  Enforce the same invariants FVA relies
// on: 8-byte alignment, userspace canonical range, MEM_COMMIT, no
// PAGE_NOACCESS/PAGE_GUARD.
//----------------------------------------------------------------------------
bool is_plausible_user_ptr(const void* p) noexcept
{
    if (!p) return false;
    const std::uintptr_t u = reinterpret_cast<std::uintptr_t>(p);
    if (u < 0x10000 || u > 0x00007FFFFFFFFFFFULL) return false;
    if ((u & 7) != 0) return false;
    return true;
}

// Byte-alignment safe: DOES NOT require 8-byte alignment on `p` itself
// (that check applies only to structural pointers via is_plausible_user_ptr).
// Cvar-name pointers live in .rdata as C-string literals and can start at
// any byte offset — enforcing 8-alignment here would kill the walker on the
// very first entry.
bool can_read_bytes(const void* p, std::size_t n) noexcept
{
    if (!p || !n) return false;
    const std::uintptr_t u = reinterpret_cast<std::uintptr_t>(p);
    if (u < 0x10000 || u > 0x00007FFFFFFFFFFFULL) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!::VirtualQuery(p, &mbi, sizeof(mbi))) return false;
    if (mbi.State != MEM_COMMIT) return false;
    if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) return false;
    const std::uint8_t* begin = static_cast<const std::uint8_t*>(p);
    const std::uint8_t* end   = begin + n;
    const std::uint8_t* rend  = static_cast<const std::uint8_t*>(mbi.BaseAddress) + mbi.RegionSize;
    return end <= rend;
}

bool can_read_cstr(const char* s, std::size_t max_len = 512) noexcept
{
    if (!s) return false;
    const std::uintptr_t u = reinterpret_cast<std::uintptr_t>(s);
    if (u < 0x10000 || u > 0x00007FFFFFFFFFFFULL) return false;
    for (std::size_t i = 0; i < max_len; ++i) {
        if (!can_read_bytes(s + i, 1)) return false;
        if (!s[i]) return true;
    }
    return false;
}

//----------------------------------------------------------------------------
// tier0.dll!CreateInterface resolver — FVA obtains the ICvar pointer via
// the standard Source-2 factory export, then reaches through it to the
// hash-root at icvar+0x48.
//----------------------------------------------------------------------------
void* resolve_create_interface(const wchar_t* module_name) noexcept
{
    HMODULE m = ::GetModuleHandleW(module_name);
    if (!m) return nullptr;
    return reinterpret_cast<void*>(::GetProcAddress(m, "CreateInterface"));
}

} // namespace

// Depot 24134959 auto-probe helpers ---------------------------------------
//
// The ICvar object layout drifts between CS2 depots.  On 14167 the ConVar
// hash-table pointer lived at root+72 (0x48).  On 24134959 that slot now
// holds a packed-index value, and the table pointer moved elsewhere.
//
// Instead of hard-coding the new offset, we probe every 8-byte-aligned slot
// in the first 0x200 bytes of the ICvar object and pick the one whose
// dereferenced value looks like a valid ConVar hash-table:
//   * plausible user pointer, readable for 16 bytes
//   * first entry is a plausible user pointer
//   * that entry's first field dereferences to a readable C-string
//     (ConVar entries start with `const char* name`)
//   * that string looks like a ConVar name (printable, underscore-only-alpha)
//
// We also record the "idx" slot — a u16 at some fixed distance from the
// table pointer that seeds the hash walker.  On 14167 idx lived 8 bytes
// after the table slot (root+0x50).  We probe both +8 and +16 offsets.
struct HashRootLayout {
    std::size_t table_off;   // offset in root where table pointer lives
    std::size_t idx_off;     // offset in root where u16 seed index lives
    bool        valid;
};

bool looks_like_cvar_name(const char* s) noexcept
{
    if (!can_read_cstr(s, 128)) return false;
    std::size_t len = 0;
    for (const char* p = s; *p && len < 128; ++p, ++len) {
        const unsigned char c = static_cast<unsigned char>(*p);
        // ConVars use [a-zA-Z0-9_] almost exclusively.
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '_' || c == '.')) {
            return false;
        }
    }
    return len >= 3 && len < 96;
}

HashRootLayout probe_layout(void* root) noexcept
{
    HashRootLayout result{0, 0, false};
    auto* base = static_cast<std::uint8_t*>(root);

    for (std::size_t off = 0x08; off <= 0x200; off += 8) {
        if (!can_read_bytes(base + off, 8)) continue;
        void* candidate = *reinterpret_cast<void**>(base + off);
        if (!is_plausible_user_ptr(candidate)) continue;
        if (!can_read_bytes(candidate, 32)) continue;

        // The first entry of the ConVar table is a pointer-to-object at
        // table[0].  Each object starts with `const char* name` at +0x00.
        // On CUtlLinkedList<T, u16> the layout is a flat array of
        // { T value, u16 prev, u16 next } elements — inspect the first
        // few to confirm.
        void* first_entry = *reinterpret_cast<void**>(candidate);
        if (!is_plausible_user_ptr(first_entry)) continue;
        if (!can_read_bytes(first_entry, 8)) continue;
        const char* name = *reinterpret_cast<const char**>(first_entry);
        if (!looks_like_cvar_name(name)) continue;

        // Table candidate confirmed.  Look for u16 idx seed 8/16 bytes
        // after the table slot (matches FVA layout root+0x48/root+0x50).
        for (std::size_t idx_off : {std::size_t{8}, std::size_t{16},
                                    std::size_t{4},  std::size_t{2}}) {
            if (!can_read_bytes(base + off + idx_off, 2)) continue;
            std::uint16_t idx = *reinterpret_cast<std::uint16_t*>(
                                    base + off + idx_off);
            if (idx == 0xFFFF) continue;
            // Seed idx must point at an in-range table slot.  We accept
            // any idx < 0x8000 — the walker's per-step bounds check will
            // catch bogus values.
            if (idx >= 0x8000) continue;
            result.table_off = off;
            result.idx_off   = off + idx_off;
            result.valid     = true;
            std::printf("[fva_recon] wire_icvar: probe found layout — "
                        "table @ root+0x%zX, idx @ root+0x%zX, "
                        "first_name=\"%s\"\n",
                        off, off + idx_off, name);
            return result;
        }
    }
    return result;
}

// Cached layout offsets — populated by wire_icvar's auto-probe, consumed
// by find_by_hash so we don't re-scan every lookup.
std::size_t g_table_off = 0x48;  // legacy 14167 default; overridden by probe
std::size_t g_idx_off   = 0x50;  // legacy 14167 default; overridden by probe

bool wire_icvar()
{
    void* create = resolve_create_interface(L"tier0.dll");
    if (!create) { std::printf("[fva_recon] wire_icvar: tier0.dll CreateInterface not found\n"); return false; }
    auto ci = reinterpret_cast<CreateInterfaceFn>(create);
    void* icvar = ci("VEngineCvar007", nullptr);
    if (!icvar) { std::printf("[fva_recon] wire_icvar: ICvar factory returned nullptr for VEngineCvar007\n"); return false; }
    if (!can_read_bytes(icvar, 0x58)) { std::printf("[fva_recon] wire_icvar: icvar %p not readable\n", icvar); return false; }
    std::printf("[fva_recon] wire_icvar: icvar=%p\n", icvar);

    // On CS2 Source-2 the factory-returned ICvar object IS the hash-root.
    void* root = icvar;

    // Try the legacy 14167 layout first (root+72 = table pointer, root+80 = idx).
    // On 24134959 this fails — auto-probe finds the new offsets.
    void* table = *reinterpret_cast<void**>(static_cast<std::uint8_t*>(root) + 72);
    if (is_plausible_user_ptr(table) && can_read_bytes(table, 16)) {
        void* first_entry = *reinterpret_cast<void**>(table);
        if (is_plausible_user_ptr(first_entry) &&
            can_read_bytes(first_entry, 8) &&
            looks_like_cvar_name(*reinterpret_cast<const char**>(first_entry))) {
            g_table_off = 72;
            g_idx_off   = 80;
            g_hash_root = root;
            std::printf("[fva_recon] wire_icvar: table=%p (legacy layout root+72)\n",
                        table);
            return true;
        }
    }

    // Legacy layout failed — auto-probe the ICvar object for the new offsets.
    std::printf("[fva_recon] wire_icvar: legacy root+72 layout invalid, probing...\n");
    HashRootLayout layout = probe_layout(root);
    if (!layout.valid) {
        std::printf("[fva_recon] wire_icvar: probe failed — no valid ConVar table found in icvar+0x08..0x200\n");
        return false;
    }
    g_table_off = layout.table_off;
    g_idx_off   = layout.idx_off;
    g_hash_root = root;

    // One-shot diagnostic: count how many entries the linear scan can
    // walk (bounded by first null or unreadable slot).  Tells us if the
    // table is dense enough for the target ConVars to actually be
    // reachable at their expected indices.
    std::uint8_t* table_ptr = *reinterpret_cast<std::uint8_t**>(
        static_cast<std::uint8_t*>(root) + g_table_off);
    if (is_plausible_user_ptr(table_ptr)) {
        std::size_t count = 0;
        for (std::size_t i = 0; i < 65535; ++i) {
            if (!can_read_bytes(table_ptr + 16 * i, 8)) break;
            void* e = *reinterpret_cast<void**>(table_ptr + 16 * i);
            if (e && is_plausible_user_ptr(e) && can_read_bytes(e, 8)) ++count;
        }
        std::printf("[fva_recon] wire_icvar: table dense-count=%zu (walked stride=16)\n",
                    count);
    }
    return true;
}

//----------------------------------------------------------------------------
// Legacy 16-byte hash-node walker.  1:1 with FVA `sub_7FFBE80C9520`:
//   idx = *(u16*)(root + 0x50)
//   table = *(u8**)(root + 0x48)
//   loop:
//     entry = *(void**)(table + 16*idx)
//     name  = *(char**)entry
//     if fnv1a(name) == target: return entry
//     idx = *(u16*)(table + 16*idx + 10)
//----------------------------------------------------------------------------
// Linear-scan walker — treats `table` as a flat array of Element*, indexed
// 0..N.  Robust against linked-list layout drift between depots since it
// doesn't follow prev/next indices at all.  The array is bounded by the
// caller's `can_read_bytes` check, and stops on the first entry where the
// name field is either null or unreadable.
// Linear-scan walker — treats `table` as a flat array of Element*, indexed
// 0..N.  Robust against linked-list layout drift since it doesn't follow
// prev/next indices at all.  CS2 has 6-10k ConVars; the CUtlLinkedList's
// u16 idx type caps the walk at 65535.  We tolerate long runs of empty
// slots (Valve's ConVar registrations sometimes have gaps).
void* linear_scan_for_hash(std::uint8_t* table, std::uint64_t fnv_hash,
                            std::size_t stride = 16,
                            std::size_t max_scan = 65535)
{
    std::size_t consecutive_nulls = 0;
    std::size_t consecutive_unreadable = 0;
    for (std::size_t i = 0; i < max_scan; ++i) {
        const std::size_t off = stride * i;
        if (!can_read_bytes(table + off, 8)) {
            // Walked off the mapped region — stop after a few consecutive
            // unreadable slots to survive spurious VirtualQuery misses.
            if (++consecutive_unreadable > 4) return nullptr;
            continue;
        }
        consecutive_unreadable = 0;

        void* entry = *reinterpret_cast<void**>(table + off);
        if (!entry) {
            // Empty slot — keep scanning; only give up after a really long
            // dead run since CS2's ConVar registry is contiguous with rare
            // holes from unregistered slots.
            if (++consecutive_nulls > 1024) return nullptr;
            continue;
        }
        consecutive_nulls = 0;

        if (!is_plausible_user_ptr(entry) || !can_read_bytes(entry, 8))
            continue;   // bad pointer — skip, don't terminate

        const char* name = *reinterpret_cast<const char**>(entry);
        if (can_read_cstr(name) && fva::obf::fnv1a(name) == fnv_hash)
            return entry;
    }
    return nullptr;
}

void* find_by_hash(std::uint64_t fnv_hash)
{
    void* root = g_hash_root;
    if (!root) return nullptr;

    const std::size_t max_off = std::max(g_table_off, g_idx_off) + 8;
    if (!can_read_bytes(root, max_off)) return nullptr;

    std::uint8_t* table =
        *reinterpret_cast<std::uint8_t**>(static_cast<std::uint8_t*>(root) + g_table_off);
    if (!is_plausible_user_ptr(table)) return nullptr;

    // Legacy linked-list walk (works on 14167).  On 24134959 the walk
    // may terminate early or loop in a way that misses target ConVars,
    // so we always fall through to linear scan on miss.
    std::uint16_t idx =
        *reinterpret_cast<std::uint16_t*>(static_cast<std::uint8_t*>(root) + g_idx_off);
    if (idx != 0xFFFF) {
        for (int guard = 0; guard < 65536; ++guard) {
            if (idx == 0xFFFF) break;
            const std::size_t off = static_cast<std::size_t>(16) * idx;
            if (!can_read_bytes(table + off, 16)) break;

            void* entry = *reinterpret_cast<void**>(table + off);
            if (!entry) break;
            if (!is_plausible_user_ptr(entry) || !can_read_bytes(entry, 8)) break;

            const char* name = *reinterpret_cast<const char**>(entry);
            if (can_read_cstr(name) && fva::obf::fnv1a(name) == fnv_hash)
                return entry;

            std::uint16_t next =
                *reinterpret_cast<std::uint16_t*>(table + off + 10);
            if (next == idx) break;  // self-loop guard
            idx = next;
        }
    }

    // Linked-list walk didn't find it — do a linear scan of the table.
    // CS2 has ~6-10k ConVars; the CUtlLinkedList<T, u16> element stride is
    // 16 bytes (verified via probe enumeration on 24134959).  Cap at 65535
    // because the u16 idx type can't index further anyway.
    return linear_scan_for_hash(table, fnv_hash, 16, 65535);
}

} // namespace fva::convar
