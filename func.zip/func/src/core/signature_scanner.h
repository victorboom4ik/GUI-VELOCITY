// ============================================================================
// Signature scanner — 1:1 recreation of FVA's sub_7FFBE80DCB84 pattern parser
// and sub_7FFBE80DCD0C memory scanner.
//
// Accepts IDA-style hex-string patterns like:
//   "48 8B C4 4C 89 40 ? 48 89 48 ? 55 53 41 54"
// where '?' is a wildcard byte and hex pairs are the exact bytes.
// ============================================================================
#pragma once

#include <cstdint>
#include <cstddef>
#include <span>
#include <string_view>
#include <vector>

namespace fva::scanner
{

struct Pattern {
    std::vector<std::uint8_t> bytes;
    std::vector<bool>         wildcards;
    [[nodiscard]] std::size_t length() const noexcept { return bytes.size(); }
};

// Parse "48 8B C4 ? ? 55" → Pattern.
// Ported from sub_7FFBE80DCB84: for each 2-char hex → byte, '?' → wildcard.
// Matches FVA's tolerant parser: spaces optional, case-insensitive.
Pattern parse(std::string_view ida_style);

// Scan a memory range for the first match. `region` = raw bytes to search.
// Returns absolute pointer inside the region, or nullptr if not found.
[[nodiscard]] std::uint8_t* find(std::span<std::uint8_t> region, const Pattern& pat) noexcept;

// Convenience: scan a loaded module's .text section.
[[nodiscard]] std::uint8_t* find_in_module(void* module_base, const Pattern& pat) noexcept;

// Convenience: parse+scan in one call.
[[nodiscard]] inline std::uint8_t* find_in_module(void* module_base, std::string_view ida)
{
    return find_in_module(module_base, parse(ida));
}

// Convenience: parse+scan+offset in one call.  Use when an anchor is placed
// N bytes into a function (typical for POST-PATCH anchors that skip the
// first 5 bytes overwritten by a MinHook E9 jmp).
[[nodiscard]] inline std::uint8_t* find_in_module(void* module_base,
                                                    std::string_view ida,
                                                    std::intptr_t offset)
{
    auto* p = find_in_module(module_base, parse(ida));
    return p ? p + offset : nullptr;
}

// Resolve a rip-relative operand at the given call/lea/mov instruction pointer.
// insn_ptr must point to the opcode (0xE8/E9 for call/jmp, 0x48 0x8D for lea rip+, etc.)
// offset_pos = byte offset from insn_ptr to the 4-byte rel32
// insn_len   = full instruction length
[[nodiscard]] void* resolve_rip_rel32(std::uint8_t* insn_ptr,
                                       std::size_t offset_pos,
                                       std::size_t insn_len) noexcept;

} // namespace fva::scanner
