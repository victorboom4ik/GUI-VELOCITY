// ============================================================================
// Boot-time self-check.
//
// Reproduces the invariants FVA implicitly relies on, verified at hook-
// install time so a stale-build/drift bug fails LOUD (log line) rather than
// silently corrupting outgoing usercmds:
//
//   1. XOR-decoded typename matches "CBaseUserCmdPB".  If it doesn't, the
//      typename qwords in obfuscation.encoded_typename must be re-decoded
//      from a fresh FVA image.
//   2. CBaseUserCmdPB layout offsets — enforced by static_asserts at
//      compile-time but re-checked at boot in case /Zp packing tricks fool
//      the header.
//   3. Client.dll build fingerprint — file size + MD5 vs kExpectedClient*.
//   4. Hook target prologues — first 5 bytes match kHookAPrePatch/B/C or
//      the E9 sentinel installed by MinHook.
//   5. CS2 helper prologues — first 20 / 7 bytes of NewMaybeArena +
//      SerializePartialToArray match the fingerprint copies in the manifest.
// ============================================================================
#include "self_check.h"
#include "../version_manifest.h"
#include "../core/obfuscation.h"
#include "../schema/cbaseusercmdpb_layout.h"

#include <Windows.h>
#include <bcrypt.h>
#include <cstdarg>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>

#pragma comment(lib, "bcrypt.lib")

namespace fva::self_check
{

namespace {

int  s_failures = 0;
char s_log_buf[512];

void logf(const char* fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    _vsnprintf_s(s_log_buf, _TRUNCATE, fmt, ap);
    va_end(ap);
    ::OutputDebugStringA(s_log_buf);
    std::fprintf(stderr, "%s", s_log_buf);
}

// Compute MD5 of the file at `path`, hex-encode into `hex_out` (33 bytes:
// 32 chars + NUL), and report file size via `out_size`.  Returns false on
// any Win32 / CNG failure.
bool compute_client_md5(const wchar_t* path,
                        char           hex_out[33],
                        std::uint64_t* out_size) noexcept
{
    HANDLE h = ::CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                              nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return false;

    LARGE_INTEGER fsz{};
    if (!::GetFileSizeEx(h, &fsz)) { ::CloseHandle(h); return false; }
    *out_size = static_cast<std::uint64_t>(fsz.QuadPart);

    BCRYPT_ALG_HANDLE  alg  = nullptr;
    BCRYPT_HASH_HANDLE hash = nullptr;
    if (::BCryptOpenAlgorithmProvider(&alg, BCRYPT_MD5_ALGORITHM, nullptr, 0) != 0)
        { ::CloseHandle(h); return false; }
    if (::BCryptCreateHash(alg, &hash, nullptr, 0, nullptr, 0, 0) != 0)
        { ::BCryptCloseAlgorithmProvider(alg, 0); ::CloseHandle(h); return false; }

    std::uint8_t buf[64 * 1024];
    DWORD n = 0;
    while (::ReadFile(h, buf, sizeof(buf), &n, nullptr) && n) {
        ::BCryptHashData(hash, buf, n, 0);
    }

    std::uint8_t digest[16] = {};
    ::BCryptFinishHash(hash, digest, sizeof(digest), 0);
    ::BCryptDestroyHash(hash);
    ::BCryptCloseAlgorithmProvider(alg, 0);
    ::CloseHandle(h);

    static const char hexc[] = "0123456789abcdef";
    for (int i = 0; i < 16; ++i) {
        hex_out[i * 2 + 0] = hexc[digest[i] >> 4];
        hex_out[i * 2 + 1] = hexc[digest[i] & 0xF];
    }
    hex_out[32] = 0;
    return true;
}

void check_typename_decode()
{
    const auto enc = fva::version::obfuscation::encoded_typename;
    const auto key = fva::version::obfuscation::xor_key;
    const std::string decoded =
        fva::obf::decode_qword_pair(enc[0], enc[1], key[0], key[1]);
    if (decoded == "CBaseUserCmdPB") {
        logf("[ok]   XOR-decoded typename = \"CBaseUserCmdPB\"\n");
    } else {
        logf("[fail] XOR-decoded typename = \"%s\" (expected \"CBaseUserCmdPB\")\n",
             decoded.c_str());
        ++s_failures;
    }
}

void check_layout()
{
    namespace L = fva::version::layout;
    struct Item { const char* name; std::size_t expected; std::size_t actual; };
    Item items[] = {
        {"has_bits",      L::base_cmd_has_bits,
                          offsetof(valve::pb::raw::CBaseUserCmdPB, has_bits)},
        {"subtick_moves", L::base_cmd_subtick_moves,
                          offsetof(valve::pb::raw::CBaseUserCmdPB, subtick_moves)},
        {"move_crc",      L::base_cmd_move_crc,
                          offsetof(valve::pb::raw::CBaseUserCmdPB, move_crc)},
        {"buttons_pb",    L::base_cmd_buttons_pb,
                          offsetof(valve::pb::raw::CBaseUserCmdPB, buttons_pb)},
        {"viewangles",    L::base_cmd_viewangles,
                          offsetof(valve::pb::raw::CBaseUserCmdPB, viewangles)},
        {"forwardmove",   L::base_cmd_forwardmove,
                          offsetof(valve::pb::raw::CBaseUserCmdPB, forwardmove)},
        {"random_seed",   L::base_cmd_random_seed,
                          offsetof(valve::pb::raw::CBaseUserCmdPB, random_seed)},
    };
    for (const auto& it : items) {
        if (it.actual == it.expected) {
            logf("[ok]   layout %-16s @ 0x%zX\n", it.name, it.actual);
        } else {
            logf("[fail] layout %-16s @ 0x%zX (expected 0x%zX)\n",
                 it.name, it.actual, it.expected);
            ++s_failures;
        }
    }
}

void check_client_dll_fingerprint()
{
    HMODULE m = ::GetModuleHandleW(fva::version::module_names::client_dll);
    if (!m) {
        logf("[fail] client.dll not loaded — cannot fingerprint\n");
        ++s_failures;
        return;
    }
    wchar_t path[MAX_PATH];
    if (!::GetModuleFileNameW(m, path, MAX_PATH)) {
        logf("[fail] GetModuleFileNameW(client.dll) failed\n");
        ++s_failures;
        return;
    }

    char          md5_hex[33] = {0};
    std::uint64_t size        = 0;
    if (!compute_client_md5(path, md5_hex, &size)) {
        logf("[fail] compute_client_md5 failed for client.dll\n");
        ++s_failures;
        return;
    }

    namespace bf = fva::version::build_fingerprint;
    const bool size_ok = (size == bf::kExpectedClientSize);
    const bool md5_ok  = (std::strcmp(md5_hex, bf::kExpectedClientMd5) == 0);

    logf("[%s] client.dll size = %llu (expected %llu)\n",
         size_ok ? "ok" : "fail",
         static_cast<unsigned long long>(size),
         static_cast<unsigned long long>(bf::kExpectedClientSize));
    logf("[%s] client.dll md5  = %s\n"
         "                       expected %s\n",
         md5_ok ? "ok" : "fail", md5_hex, bf::kExpectedClientMd5);

    if (!size_ok) ++s_failures;
    if (!md5_ok)  ++s_failures;
}

void check_hook_prologues()
{
    HMODULE client = ::GetModuleHandleW(fva::version::module_names::client_dll);
    if (!client) return;
    auto* base = reinterpret_cast<std::uint8_t*>(client);

    namespace bf = fva::version::build_fingerprint;
    namespace kr = fva::version::known_rva;

    struct Probe {
        const char*         name;
        std::uintptr_t      rva;
        const std::uint8_t* expected;
        std::size_t         len;
    };
    Probe probes[] = {
        {"Hook A CreateMove",  kr::hook_a_target, bf::kHookAPrePatch.data(), bf::kHookAPrePatch.size()},
        {"Hook B LevelInit",   kr::hook_b_target, bf::kHookBPrePatch.data(), bf::kHookBPrePatch.size()},
        {"Hook C Serialize",   kr::hook_c_target, bf::kHookCPrePatch.data(), bf::kHookCPrePatch.size()},
    };

    for (const auto& p : probes) {
        const auto* addr = base + p.rva;
        // 0xE9 means the site is already hooked (either by us on re-inject or
        // by another injector).  We accept it as "not-drift".
        if (addr[0] == 0xE9) {
            logf("[ok]   %-19s prologue @ RVA 0x%zX = E9 (already hooked)\n",
                 p.name, p.rva);
            continue;
        }
        if (std::memcmp(addr, p.expected, p.len) == 0) {
            logf("[ok]   %-19s prologue @ RVA 0x%zX matches pre-patch\n",
                 p.name, p.rva);
        } else {
            logf("[fail] %-19s prologue @ RVA 0x%zX DRIFT: "
                 "got %02X %02X %02X %02X %02X\n",
                 p.name, p.rva, addr[0], addr[1], addr[2], addr[3], addr[4]);
            ++s_failures;
        }
    }
}

void check_helper_prologues()
{
    HMODULE client = ::GetModuleHandleW(fva::version::module_names::client_dll);
    if (!client) return;
    auto* base = reinterpret_cast<std::uint8_t*>(client);

    namespace bf = fva::version::build_fingerprint;
    namespace kr = fva::version::known_rva;

    struct Probe {
        const char*         name;
        std::uintptr_t      rva;
        const std::uint8_t* expected;
        std::size_t         len;
    };
    Probe probes[] = {
        {"NewMaybeArena_CBaseUserCmdPB", kr::new_maybe_arena_cbaseusercmdpb,
                                          bf::kNewMaybeArenaPrologue.data(),
                                          bf::kNewMaybeArenaPrologue.size()},
        {"SerializePartialToArray",      kr::serialize_partial_to_array,
                                          bf::kSerializePartialPrologue.data(),
                                          bf::kSerializePartialPrologue.size()},
    };

    for (const auto& p : probes) {
        const auto* addr = base + p.rva;
        if (std::memcmp(addr, p.expected, p.len) == 0) {
            logf("[ok]   %s fingerprint @ RVA 0x%zX matches\n", p.name, p.rva);
        } else {
            logf("[fail] %s fingerprint @ RVA 0x%zX DRIFT (first 4 = "
                 "%02X %02X %02X %02X)\n",
                 p.name, p.rva, addr[0], addr[1], addr[2], addr[3]);
            ++s_failures;
        }
    }
}

} // namespace

bool run_all()
{
    s_failures = 0;
    logf("[fva-selfcheck] starting\n");
    check_typename_decode();
    check_layout();
    check_client_dll_fingerprint();
    check_hook_prologues();
    check_helper_prologues();
    logf("[fva-selfcheck] %d failures\n", s_failures);
    return s_failures == 0;
}

} // namespace fva::self_check
