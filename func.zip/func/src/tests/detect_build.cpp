// ============================================================================
// Build detection — pick between patterns_legacy.inl and patterns.inl.
//
// Uses the client.dll MD5 recorded at the top of patterns_legacy.inl as the
// primary heuristic; falls back to size, then to size-range in case of minor
// drift.
// ============================================================================
#include "self_check.h"
#include "../schema/patterns_legacy.inl"

#include <Windows.h>
#include <wincrypt.h>
#include <cstdio>
#include <cstdint>
#include <cstring>

namespace fva::self_check
{

namespace {

bool md5_of_file(const wchar_t* path, char out_hex[33]) noexcept
{
    HANDLE h = ::CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, nullptr,
                              OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return false;

    HCRYPTPROV prov = 0;
    HCRYPTHASH hash = 0;
    bool ok = false;

    do {
        if (!::CryptAcquireContextW(&prov, nullptr, nullptr, PROV_RSA_FULL,
                                      CRYPT_VERIFYCONTEXT | CRYPT_SILENT))
            break;
        if (!::CryptCreateHash(prov, CALG_MD5, 0, 0, &hash)) break;

        std::uint8_t buf[64 * 1024];
        DWORD read = 0;
        while (::ReadFile(h, buf, sizeof(buf), &read, nullptr) && read) {
            if (!::CryptHashData(hash, buf, read, 0)) goto done;
        }

        std::uint8_t md5[16];
        DWORD len = 16;
        if (!::CryptGetHashParam(hash, HP_HASHVAL, md5, &len, 0)) goto done;
        for (int i = 0; i < 16; ++i)
            std::snprintf(out_hex + 2 * i, 3, "%02X", md5[i]);
        out_hex[32] = 0;
        ok = true;
    } while (0);

done:
    if (hash) ::CryptDestroyHash(hash);
    if (prov) ::CryptReleaseContext(prov, 0);
    ::CloseHandle(h);
    return ok;
}

const wchar_t* resolve_client_dll_path()
{
    static wchar_t path[MAX_PATH];
    HMODULE client = ::GetModuleHandleW(L"client.dll");
    if (!client) return nullptr;
    if (::GetModuleFileNameW(client, path, MAX_PATH) == 0) return nullptr;
    return path;
}

} // namespace

bool detect_legacy_build()
{
    const wchar_t* path = resolve_client_dll_path();
    if (!path) return false;

    // Primary: MD5.
    char hex[33] = {};
    if (md5_of_file(path, hex)) {
        if (std::strcmp(hex, fva::patterns_legacy::kExpectedClientMd5) == 0)
            return true;
    }

    // Fallback: exact size match.
    HANDLE h = ::CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, nullptr,
                              OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return false;
    LARGE_INTEGER sz{};
    ::GetFileSizeEx(h, &sz);
    ::CloseHandle(h);
    return sz.QuadPart == static_cast<LONGLONG>(fva::patterns_legacy::kExpectedClientSize);
}

} // namespace fva::self_check
