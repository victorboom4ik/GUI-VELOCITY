// ============================================================================
// Boot-time self-check — runs at DllMain attach.
// Verifies that every drift-prone value in the reconstruction still matches
// the running client.dll.  Any failure means: game update happened, re-scan.
// ============================================================================
#pragma once

namespace fva::self_check
{
    // Returns true if all checks passed.  Otherwise writes findings to
    // OutputDebugString / stderr and returns false.
    bool run_all();

    // Fingerprints client.dll and picks the pattern set — legacy depot vs
    // live Steam build.  Called from hook_manager::install_all() to decide
    // which anchor namespace to use.
    bool detect_legacy_build();
}
