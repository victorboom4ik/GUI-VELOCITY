// ============================================================================
// fva_recon.dll — entrypoint.
//
// Ported and slimmed from
//   VacLiveBypass/dllmain.original.cpp:4761-4894 (Main + DllMain).
//
// Semantics preserved:
//   - DisableThreadLibraryCalls
//   - Optional AllocConsole (behind FVA_CONSOLE)
//   - Main worker thread
//   - Wait ≤ 10 s for client.dll / engine2.dll / networksystem.dll
//   - hooks::install_all() then self_check::run_all()
//   - Poll END key to unload
//   - hooks::uninstall_all() → FreeLibraryAndExitThread
//
// Cvar suppression and pattern resolution are wired in during Phases 2 and 3
// and will attach here between module-wait and install_all.
// ============================================================================
#include "hooks/engine2_bindings.h"
#include "hooks/hook_manager.h"
#include "hooks/view_angle_spoofer.h"
#include "hooks/input_scratch_mirror.h"
#include "hooks/scratch_serialize.h"
#include "hooks/game_state_resolver.h"
#include "features/cvar_suppress.h"
#include "features/console_exec.h"
#include "features/isvalveds_check.h"
#include "core/signature_scanner.h"
#include "schema/client_input.h"
#include "schema/protobuf_alloc.h"
#include "tests/self_check.h"

#include <Windows.h>
#include <cstdio>

namespace fva::log { extern void install_file_sink(); void* find_csubtick_vtable(); void* find_arena_allocator(); }

namespace {

#if defined(FVA_CONSOLE)
void open_console()
{
    if (::AllocConsole()) {
        FILE* f = nullptr;
        ::freopen_s(&f, "CONOUT$", "w+", stdout);
        ::freopen_s(&f, "CONOUT$", "w+", stderr);
        std::printf("[fva_recon] console attached\n");
    }
}
#else
inline void open_console() {}
#endif

bool wait_for_modules()
{
    for (int i = 0; i < 40; ++i) {
        HMODULE c = ::GetModuleHandleW(L"client.dll");
        HMODULE e = ::GetModuleHandleW(L"engine2.dll");
        HMODULE n = ::GetModuleHandleW(L"networksystem.dll");
        HMODULE a = ::GetModuleHandleW(L"animationsystem.dll");
        if (c && e && n) {
            // animationsystem.dll is nice-to-have (H4 anim hook); if it
            // isn't loaded at this point install_all skips Hook D with a
            // warning.  Not fatal.
            std::printf("[fva_recon] modules: client=%p engine2=%p "
                        "networksystem=%p animationsystem=%p\n",
                        (void*)c, (void*)e, (void*)n, (void*)a);
            return true;
        }
        ::Sleep(250);
    }
    return false;
}

DWORD WINAPI main_thread(LPVOID module_handle)
{
    open_console();
    fva::log::install_file_sink();
    std::printf("[fva_recon] waiting for CS2 modules...\n");

    if (!wait_for_modules()) {
        std::printf("[fva_recon] FATAL: modules not present after 10 s — abort\n");
        ::FreeLibraryAndExitThread(reinterpret_cast<HMODULE>(module_handle), 1);
        return 1;
    }

    if (!fva::client_input::init())
        std::printf("[fva_recon] WARN: client_input::init failed — mutation will be a no-op\n");
    else
        std::printf("[fva_recon] client_input ready\n");

    // cvar_suppress::apply() is intentionally NOT called here — Hook A owns
    // the per-tick zero (create_move_hook.cpp:71).  Doing it a second time
    // pre-install would mean one tick of behaviour exists in state no
    // self_check gate has approved.  Init only.
    if (!fva::cvar_suppress::init())
        std::printf("[fva_recon] WARN: cvar_suppress::init failed — cvar zeroing disabled\n");
    else
        std::printf("[fva_recon] cvar_suppress init ok\n");

    if (!fva::console::init())
        std::printf("[fva_recon] WARN: console::init failed — auto-test harness disabled\n");
    else
        std::printf("[fva_recon] console ready — can inject exec/map commands\n");

    if (!fva::scratch_serialize::init())
        std::printf("[fva_recon] WARN: scratch_serialize::init failed — move_crc regen disabled\n");
    else
        std::printf("[fva_recon] scratch_serialize ready\n");

    if (!fva::protobuf_alloc::init())
        std::printf("[fva_recon] WARN: protobuf_alloc::init failed — null-base alloc disabled\n");
    else
        std::printf("[fva_recon] protobuf_alloc ready\n");

    if (!fva::hooks::input_scratch_mirror::init())
        std::printf("[fva_recon] WARN: input_scratch_mirror::init failed — buttons/angles mirror disabled\n");
    else
        std::printf("[fva_recon] input_scratch_mirror ready\n");

    if (!fva::view_angle_spoofer::init())
        std::printf("[fva_recon] WARN: view_angle_spoofer::init failed — angle wrap disabled\n");
    else
        std::printf("[fva_recon] view_angle_spoofer ready\n");
    std::fflush(stdout);

    // engine2 state bindings (Category 1/2/3) — resolves IsInGame /
    // IsConnected / LevelShutdown + client helpers (ComputeRandomSeed,
    // ForceButtonsDown, Get/SetViewAngles).  Idempotent; safe if any
    // signature drifts (predicates fail-safe to false, hook returns false).
    if (!fva::hooks::engine2::init())
        std::printf("[fva_recon] WARN: engine2::init failed — view-angle emitter will "
                    "fall back to tick-based grace only\n");
    else
        std::printf("[fva_recon] engine2 bindings ready\n");
    std::fflush(stdout);

    // Fingerprint gate — run BEFORE install_all so drift kills the install
    // instead of us patching three functions in a client.dll we don't
    // recognise.  With FVA_STRICT_FINGERPRINT defined the run_all failure
    // aborts the thread outright; otherwise we log + install anyway (default
    // dev-friendly).
    // self_check::run_all reads several client.dll RVAs to verify build
    // parity.  On a drifted CS2 build (input_scratch_mirror::init had to fall through
    // to its heap fallback for CInButtonStatePB::New / CMsgQAngle::New)
    // some of those reads land on the wrong structure and
    // __security_check_cookie kills the caller.  Skip when input_scratch_mirror
    // signalled drift.  Note: input_scratch_mirror::ready() is now true even on drifted
    // builds (heap fallback keeps apply() running); used_heap_fallback()
    // is the correct canary.  Hooks A/B/C install path is robust to
    // drift (level_init resolve_target's sig scanner tolerates it; so
    // does create_move's client_input chain).
    if (!fva::hooks::input_scratch_mirror::used_heap_fallback()) {
        std::printf("[fva_recon] entering self_check::run_all\n"); std::fflush(stdout);
        const bool selfcheck_ok = fva::self_check::run_all();
        std::printf("[fva_recon] self_check returned: %d\n", (int)selfcheck_ok);
        std::fflush(stdout);
#if defined(FVA_STRICT_FINGERPRINT)
        if (!selfcheck_ok) {
            std::printf("[fva_recon] FATAL: self_check drift under STRICT — abort\n");
            ::FreeLibraryAndExitThread(reinterpret_cast<HMODULE>(module_handle), 3);
            return 3;
        }
#endif
    } else {
        std::printf("[fva_recon] SKIP self_check (input_scratch_mirror reported drift; "
                    "self_check reads might land on unmapped memory)\n");
        std::fflush(stdout);
    }

    std::printf("[fva_recon] entering install_all\n"); std::fflush(stdout);
    const bool install_ok = fva::hooks::install_all();
    std::printf("[fva_recon] install_all returned: %d\n", (int)install_ok); std::fflush(stdout);
    if (!install_ok) {
        std::printf("[fva_recon] FATAL: install_all failed — abort\n");
        ::FreeLibraryAndExitThread(reinterpret_cast<HMODULE>(module_handle), 2);
        return 2;
    }
    std::printf("[fva_recon] hooks installed\n"); std::fflush(stdout);

    // LevelShutdown hook RE-ENABLED 2026-07-11 — not the crash source.
    if (!fva::hooks::engine2::install_level_shutdown_hook())
        std::printf("[fva_recon] WARN: LevelShutdown hook install failed\n");
    else
        std::printf("[fva_recon] LevelShutdown hook installed\n");
    std::fflush(stdout);

    // Kick game_state_resolver eagerly so we don't have to wait for a
    // LevelInit event to observe it — logs whether sig-scan hit or not.
    if (void* base = fva::game_state::resolve())
        std::printf("[fva_recon] game_state resolved: interface=%p\n", base);
    else
        std::printf("[fva_recon] game_state resolve: MISS (accessor sig not "
                    "in client.dll — fire_flag_probe stays dormant)\n");

    // Sig-scan client.dll for CSubtickMoveStep vtable (closes spoofer GAP).
    if (void* vt = fva::log::find_csubtick_vtable())
        std::printf("[fva_recon] CSubtickMoveStep vtable @ %p\n", vt);
    else
        std::printf("[fva_recon] CSubtickMoveStep vtable: MISS (append_step "
                    "growth remains no-op)\n");

    // Sig-scan for the arena allocator (equivalent of FVA sub_7FFBE8103070).
    // Once found + the CSubtickMoveStep vtable above, view_angle_spoofer::append_step's
    // growth path can arena-allocate + stamp + zero the same way FVA does.
    if (void* aa = fva::log::find_arena_allocator())
        std::printf("[fva_recon] Arena allocator @ %p\n", aa);
    else
        std::printf("[fva_recon] Arena allocator: MISS (fallback prologue "
                    "no match — protobuf ABI may have shifted)\n");
    std::fflush(stdout);

    std::printf("[fva_recon] running — press END to unload\n");

    // Periodically check m_bIsValveDS. If Valve dedicated flag is 1 —
    // force it to 0. Runs every second, only writes when != 0.
    int isvds_ticks = 0;
    while (!(::GetAsyncKeyState(VK_END) & 0x8000)) {
        ::Sleep(100);
        if (++isvds_ticks >= 10) {   // every ~1 s
            fva::isvalveds::auto_off();
            isvds_ticks = 0;
        }
    }

    std::printf("[fva_recon] END pressed — uninstalling\n");
    fva::hooks::uninstall_all();

    ::FreeLibraryAndExitThread(reinterpret_cast<HMODULE>(module_handle), 0);
    return 0;
}

} // namespace

BOOL APIENTRY DllMain(HMODULE h, DWORD reason, LPVOID) noexcept
{
    if (reason == DLL_PROCESS_ATTACH) {
        ::DisableThreadLibraryCalls(h);
        ::CreateThread(nullptr, 0, main_thread, h, 0, nullptr);
    }
    return TRUE;
}
