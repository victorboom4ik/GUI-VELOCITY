// ============================================================================
// Console command executor — via engine2.dll InputService_001 vtable[25].
//
// Mirrors ConsoleInjector.dll's mechanism (user's own project at
// C:\Users\sshunko\source\repos\consoleinputdriver\ConsoleInjector\main.cpp).
//
// Used for autonomous test harness:
//   console::exec("exec tren")
//   console::exec("map de_mirage")
// ============================================================================
#pragma once

namespace fva::console
{

// One-shot init — resolve engine2.dll::CreateInterface + get InputService_001
// object.  Returns false if engine2.dll not loaded or interface unavailable.
bool init() noexcept;

// True after successful init.
bool ready() noexcept;

// Execute a console command as if user typed it in the developer console.
// Uses InputService_001 vtable[25] signature:
//   void __thiscall(void* self, int slot=5, const char* cmd, int flags=0)
// Returns false if not init() yet.
bool exec(const char* cmd) noexcept;

} // namespace fva::console
