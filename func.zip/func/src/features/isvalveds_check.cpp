// features/isvalveds_check.cpp — auto-disable m_bIsValveDS.
//
// Uses the same offsets as CS2IsValveDSSpooferDriver/main.cpp:
//   DEFAULT_OFF_DWGAMERULES = 0x23A0C58   client.dll!dwGameRules
//   DEFAULT_OFF_ISVALVEDS   = 0xA4        C_CSGameRules::m_bIsValveDS
//
// Kept in the injected DLL (user-mode) so no kernel driver is needed for
// this specific field — the driver approach is reserved for scenarios where
// cs2 explicitly protects the write path. In practice a plain user-mode
// write via the loaded client.dll module works for m_bIsValveDS because
// there's no anti-tamper on that field.

#include "isvalveds_check.h"

#include <Windows.h>
#include <cstdint>
#include <cstdio>

namespace fva::isvalveds {

namespace {

// Verified against a2x/cs2-dumper HEAD (2026-07-11):
//   client.dll!dwGameRules       = 0x23A39D8
//   C_CSGameRules::m_bIsValveDS  = 0xA4
constexpr std::uintptr_t kOffDwGameRules  = 0x23A39D8;
constexpr std::uintptr_t kOffIsValveDS    = 0xA4;

// Cached resolve — client.dll base only.
struct Cache {
    std::uintptr_t client_base = 0;
    bool tried = false;
};
static Cache g_cache;

std::uintptr_t client_base() noexcept
{
    if (!g_cache.tried) {
        HMODULE mod = ::GetModuleHandleW(L"client.dll");
        g_cache.client_base = reinterpret_cast<std::uintptr_t>(mod);
        g_cache.tried = true;
    }
    return g_cache.client_base;
}

// Return &m_bIsValveDS (or nullptr if unresolved / GameRules == null).
std::uint8_t* resolve() noexcept
{
    const auto base = client_base();
    if (!base) return nullptr;

    // Dereference dwGameRules — it's a pointer (not offset) stored at
    //   client.dll + kOffDwGameRules
    std::uintptr_t* pptr_gamerules = reinterpret_cast<std::uintptr_t*>(
        base + kOffDwGameRules);

    __try {
        std::uintptr_t gamerules = *pptr_gamerules;
        if (!gamerules) return nullptr;

        return reinterpret_cast<std::uint8_t*>(gamerules + kOffIsValveDS);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return nullptr;
    }
}

}  // namespace

int query() noexcept
{
    auto* ptr = resolve();
    if (!ptr) return -1;
    __try {
        return static_cast<int>(*ptr);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return -1;
    }
}

bool auto_off() noexcept
{
    auto* ptr = resolve();

    // Периодически (первые 5 вызовов + каждый 30-й) diagnostic-лог
    // текущего состояния — позволяет отличить "byte всегда 0 => spoof не
    // нужен на этом сервере" от "resolve() failed / offsets drifted".
    static int s_calls = 0;
    ++s_calls;
    const bool verbose = s_calls <= 5 || (s_calls % 30 == 0);

    if (!ptr) {
        if (verbose) {
            std::printf("[fva_recon] isvalveds resolve FAILED call#%d "
                        "(client.dll+0x%zX -> NULL GameRules ptr; "
                        "offset may have drifted or match not started)\n",
                        s_calls, (size_t)0x23A0C58);
            std::fflush(stdout);
        }
        return false;
    }

    __try {
        const std::uint8_t v = *ptr;
        if (v != 0) {
            *ptr = 0;
            std::printf("[fva_recon] isvalveds: m_bIsValveDS was %u @ %p -> "
                        "forced 0 (call#%d)\n",
                        (unsigned)v, (void*)ptr, s_calls);
            std::fflush(stdout);
            return true;
        }
        if (verbose) {
            std::printf("[fva_recon] isvalveds observe: m_bIsValveDS = 0 "
                        "@ %p (call#%d, spoof not needed)\n",
                        (void*)ptr, s_calls);
            std::fflush(stdout);
        }
        return false;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        if (verbose) {
            std::printf("[fva_recon] isvalveds SEH при чтении *%p (call#%d) "
                        "-> offset drift?\n",
                        (void*)ptr, s_calls);
            std::fflush(stdout);
        }
        return false;
    }
}

}  // namespace fva::isvalveds
