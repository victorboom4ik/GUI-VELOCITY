// ============================================================================
// Cvar suppression — reproduces FVA Hook A's per-tick zero of two ConVars.
//
// Verified via FVA sub_7FFBE80C9D8C disasm 2026-07-10:
//
//   +0x0E80: lea r10, aClPredPrintEve; "cl_pred_print_every_cmd"
//            (inline FNV-1a loop @ +0x0EA4..+0x0EB6, then
//             call sub_7FFBE80C9520 → cache pointer in qword_7FFBE823CC00,
//             once-guarded by TLS dword_7FFBE823CBFC)
//   +0x0F04: lea r9,  aClShowusercmd;  "cl_showusercmd"
//            (analogous cache in qword_7FFBE823CBF0 guarded by
//             dword_7FFBE823CC0C)
//
//   +0x0F63: mov rax, cs:qword_7FFBE823CC00        ; cvar #1 ptr
//            test rax, rax
//            jz +0x0F73
//            mov [rax+58h], dil                    ; ★ ZERO byte at +0x58
//   +0x0F73: mov rax, cs:qword_7FFBE823CBF0        ; cvar #2 ptr
//            test rax, rax
//            jz +0x0F83
//            mov [rax+58h], dil                    ; ★ ZERO byte at +0x58
//
// So FVA:
//   - Caches both ConVar* pointers via a TLS-once-init lookup on the FIRST
//     Hook A invocation.
//   - Writes 0 to each ConVar->value_byte(+0x58) on EVERY tick thereafter.
//
// Our reconstruction mirrors that shape:
//   - init()  → runs the lookup once and caches the pointers.  Called at
//                boot from DllMain for eagerness; if the ConVar registry
//                isn't ready yet, init() reports failure and Hook A retries
//                the lookup lazily.
//   - apply() → writes the zero byte to both cached pointers.  Called from
//                the Hook A detour every tick.
// ============================================================================
#pragma once

namespace fva::cvar_suppress
{

// Resolve both ConVar* pointers via FVA's FindConvarByHash walker.  Idempotent;
// returns true iff both were found.  Safe to call again from Hook A if the
// first boot-time attempt failed (ICvar not yet registered).
bool init();

// Zero the two ConVar value bytes.  No-op if either pointer isn't cached.
void apply();

// Diagnostic — is at least one ConVar resolved?  Used by Hook A to avoid
// re-running lookup every tick before ICvar is available.
[[nodiscard]] bool ready() noexcept;

} // namespace fva::cvar_suppress
