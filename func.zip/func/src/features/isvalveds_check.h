// features/isvalveds_check.h — auto-disable CCSGameRules::m_bIsValveDS.
//
// Reads m_bIsValveDS byte via a pointer chain identical to what
// CS2IsValveDSSpooferDriver uses:
//   client.dll + DEFAULT_OFF_DWGAMERULES  (== 0x23A0C58 for depot 14169)
//   -> pointer to CCSGameRules instance
//   -> + DEFAULT_OFF_ISVALVEDS (== 0xA4)  = m_bIsValveDS byte
//
// If the byte is 1, forcibly write 0. Idempotent; safe to call every tick
// from a hook. Cost = 1 mov + branch when already 0.

#pragma once

namespace fva::isvalveds {

// Query current m_bIsValveDS state. Returns:
//   -1 = couldn't resolve pointer chain (GameRules == null)
//    0 = false
//    1 = true
int query() noexcept;

// If m_bIsValveDS == 1, write 0. Returns true if a write happened
// (or would happen — noop when already 0).
bool auto_off() noexcept;

}  // namespace fva::isvalveds
