// ============================================================================
// Console command executor — implementation.
// ============================================================================
#include "console_exec.h"

#include <Windows.h>
#include <atomic>
#include <cstdio>

namespace fva::console
{

namespace {

using CreateInterfaceFn = void*(__cdecl*)(const char* name, int* rc);
using ExecCmdFn = void(__fastcall*)(void* self, int slot, const char* cmd, int flags);

std::atomic<void*> g_input_service{nullptr};
std::atomic<ExecCmdFn> g_exec_fn{nullptr};
std::atomic<bool> g_init_failed{false};

} // namespace

bool init() noexcept
{
    if (g_init_failed.load(std::memory_order_acquire)) return false;
    if (g_input_service.load(std::memory_order_acquire)) return true;

    HMODULE eng = ::GetModuleHandleA("engine2.dll");
    if (!eng) {
        std::printf("[fva_recon] console::init engine2.dll not loaded\n");
        g_init_failed.store(true, std::memory_order_release);
        return false;
    }

    auto ci = reinterpret_cast<CreateInterfaceFn>(::GetProcAddress(eng, "CreateInterface"));
    if (!ci) {
        std::printf("[fva_recon] console::init CreateInterface not exported\n");
        g_init_failed.store(true, std::memory_order_release);
        return false;
    }

    void* svc = ci("InputService_001", nullptr);
    if (!svc) {
        std::printf("[fva_recon] console::init InputService_001 factory returned null\n");
        g_init_failed.store(true, std::memory_order_release);
        return false;
    }

    void** vtable = *reinterpret_cast<void***>(svc);
    if (!vtable) {
        std::printf("[fva_recon] console::init vtable pointer null\n");
        g_init_failed.store(true, std::memory_order_release);
        return false;
    }

    auto fn = reinterpret_cast<ExecCmdFn>(vtable[25]);
    if (!fn) {
        std::printf("[fva_recon] console::init vtable[25] null\n");
        g_init_failed.store(true, std::memory_order_release);
        return false;
    }

    g_exec_fn.store(fn, std::memory_order_release);
    g_input_service.store(svc, std::memory_order_release);
    std::printf("[fva_recon] console: InputService_001=%p vtable[25]=%p ready\n", svc, fn);
    return true;
}

bool ready() noexcept
{
    return g_input_service.load(std::memory_order_acquire) != nullptr;
}

bool exec(const char* cmd) noexcept
{
    if (!cmd) return false;
    void* svc = g_input_service.load(std::memory_order_acquire);
    auto fn = g_exec_fn.load(std::memory_order_acquire);
    if (!svc || !fn) return false;
    std::printf("[fva_recon] console::exec: %s\n", cmd);
    fn(svc, 5, cmd, 0);
    return true;
}

} // namespace fva::console
