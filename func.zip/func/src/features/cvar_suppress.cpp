// ============================================================================
// Cvar suppression — implementation.
// ============================================================================
#include "cvar_suppress.h"
#include "../core/convar.h"
#include "../core/obfuscation.h"
#include "../version_manifest.h"

#include <Windows.h>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>

namespace fva::cvar_suppress
{

namespace {

// Cache slots — mirror FVA `qword_7FFBE823CC00` and `qword_7FFBE823CBF0`.
std::atomic<void*> g_cl_pred_print_every_cmd{nullptr};
std::atomic<void*> g_cl_showusercmd{nullptr};

// Fail-latch — once ICvar wire fails on this depot (e.g. root+72 layout
// drifted), stop retrying every tick so Hook A doesn't flood the console.
std::atomic<bool> g_wire_failed{false};

// Direct-RVA lookup: read the manifest-supplied static-cvar RVA and
// verify it points at a ConVar object whose name matches `expected_name`.
// The ConVar layout stores the name-pointer at +0x18 (Source 2 default).
// Fingerprint check protects against depot drift silently pointing at
// unrelated memory.
void* resolve_static_cvar(std::uintptr_t rva, const char* expected_name) noexcept
{
    HMODULE client = ::GetModuleHandleW(fva::version::module_names::client_dll);
    if (!client) return nullptr;
    auto* obj = reinterpret_cast<std::uint8_t*>(client) + rva;

    // Probe common name-pointer offsets (Source 2's ConVarBase uses 0x18,
    // ConCommand uses 0x08; the exact slot varies by codegen).
    for (std::size_t name_off : {std::size_t{0x18}, std::size_t{0x20},
                                  std::size_t{0x10}, std::size_t{0x28},
                                  std::size_t{0x08}}) {
        auto* name_ptr =
            *reinterpret_cast<const char**>(obj + name_off);
        // Cheap pointer sanity — reject null/kernel/misaligned.
        auto v = reinterpret_cast<std::uintptr_t>(name_ptr);
        if (v < 0x10000 || v >= 0x00007FFFFFFFFFFFULL) continue;
        // Try to match — protect against page faults with SEH.
        __try {
            if (std::strcmp(name_ptr, expected_name) == 0) {
                std::printf("[fva_recon] cvar_suppress: direct-RVA hit for "
                            "\"%s\" @ 0x%zX (name@obj+0x%zX)\n",
                            expected_name, rva, name_off);
                return obj;
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            // Bad name pointer, try next offset.
        }
    }
    return nullptr;
}

} // namespace

bool init()
{
    // Hard latch — if init has ever run to completion (success OR fail),
    // return the cached verdict without touching find_by_hash again.
    // view-angle emitter re-enters this once per tick via
    //   `if (!ready()) init();` in create_move_hook.cpp; without the latch
    // a failing init walks the 12,000-entry ConVar registry every tick,
    // dropping the game to 1 FPS.
    static std::atomic<int> s_tried{0};  // 0=never, 1=in-progress, 2=done
    int expected = 0;
    if (!s_tried.compare_exchange_strong(expected, 1,
                                          std::memory_order_acq_rel)) {
        // Another thread beat us to it — busy-wait for its verdict.  In
        // practice Hook A runs single-threaded on the CS2 client thread,
        // so this branch is effectively never taken.
        while (s_tried.load(std::memory_order_acquire) != 2) {}
        return g_cl_pred_print_every_cmd.load(std::memory_order_relaxed) &&
               g_cl_showusercmd.load(std::memory_order_relaxed);
    }

    namespace kr = fva::version::known_rva;

    // Preferred path: direct RVA to static ConVar instance in .data.
    if (!g_cl_pred_print_every_cmd.load(std::memory_order_relaxed)) {
        if (void* p = resolve_static_cvar(kr::static_cvar_cl_pred_print_every_cmd,
                                           "cl_pred_print_every_cmd")) {
            g_cl_pred_print_every_cmd.store(p, std::memory_order_release);
        }
    }
    if (!g_cl_showusercmd.load(std::memory_order_relaxed)) {
        if (void* p = resolve_static_cvar(kr::static_cvar_cl_showusercmd,
                                           "cl_showusercmd")) {
            g_cl_showusercmd.store(p, std::memory_order_release);
        }
    }

    const bool done_direct =
        g_cl_pred_print_every_cmd.load(std::memory_order_relaxed) &&
        g_cl_showusercmd.load(std::memory_order_relaxed);

    if (!done_direct && !g_wire_failed.load(std::memory_order_acquire)) {
        if (!fva::convar::wire_icvar()) {
            g_wire_failed.store(true, std::memory_order_release);
        } else {
            if (!g_cl_pred_print_every_cmd.load(std::memory_order_relaxed))
                g_cl_pred_print_every_cmd.store(
                    fva::convar::find_by_hash(fva::obf::fnv1a("cl_pred_print_every_cmd")),
                    std::memory_order_release);
            if (!g_cl_showusercmd.load(std::memory_order_relaxed))
                g_cl_showusercmd.store(
                    fva::convar::find_by_hash(fva::obf::fnv1a("cl_showusercmd")),
                    std::memory_order_release);
        }
    }

    // Latch a permanent failure so subsequent init() calls return
    // immediately.  Otherwise ready()==false would trigger a 12k-entry
    // registry walk every tick.
    const bool ok =
        g_cl_pred_print_every_cmd.load(std::memory_order_relaxed) &&
        g_cl_showusercmd.load(std::memory_order_relaxed);
    if (!ok) g_wire_failed.store(true, std::memory_order_release);

    s_tried.store(2, std::memory_order_release);
    return ok;
}

void apply()
{
    if (void* p = g_cl_pred_print_every_cmd.load(std::memory_order_acquire))
        *(static_cast<std::uint8_t*>(p) + fva::convar::k_convar_value_offset) = 0;

    if (void* p = g_cl_showusercmd.load(std::memory_order_acquire))
        *(static_cast<std::uint8_t*>(p) + fva::convar::k_convar_value_offset) = 0;
}

bool ready() noexcept
{
    return g_cl_pred_print_every_cmd.load(std::memory_order_acquire) != nullptr ||
           g_cl_showusercmd.load(std::memory_order_acquire) != nullptr;
}

} // namespace fva::cvar_suppress
