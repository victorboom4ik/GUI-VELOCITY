# VacLiveBypass — CS2 Anti-Aim Yeniden Yapılandırması (Reconstruction)

**Counter-Strike 2 için obfüske edilmiş Gamesense/FVA eklentisinin tamamen açık kaynaklı C++ yeniden yapılandırması.** Bu proje; canlı davranışların gözlemlenmesi, IDA Hex-Rays ile dekompile edilmesi ve RVA'ların bayt bazında doğrulanması gibi tersine mühendislik yöntemleriyle elde edilmiş, VMProtect ile gizlenmiş bir DLL'in "temiz" (clean-room) uygulamasıdır. Orijinal kaynak kodun hiçbiri kullanılmamıştır; yalnızca dekompilörden elde edilen bayt imzaları ve sözde kodlar (pseudocode) temel alınmıştır.

Amaç, **bilimsel ve savunma odaklı güvenlik (defensive-security) değeri** sağlamaktır: Görüş açısı sahteciliğinin (viewangles-spoofing) ve subtick enjeksiyonlu anti-aim sisteminin obfüske edilmemiş haliyle nasıl çalıştığını göstermek; böylece anti-hile geliştiricilerinin tek bir DLL'in peşinde koşmak yerine tespit mantığını bu kalıplar üzerine inşa edebilmelerini sağlamaktır.

---

## Proje Ne Yapıyor?

Her tikte (saniyede 64 kez) CS2 sunucuya, kullanıcının geçen arulıktaki girdilerini (görüş açıları, hareketler, tuşlar, tik içerisindeki tam basılma anlarını gösteren subtick olayları) açıklayan `CBaseUserCmdPB` adında bir protobuf mesajı gönderir. Eklentimiz istemcinin üç fonksiyonuna müdahale eder (hook atar):

1. **`CBaseUserCmd::CreateMove` iç fonksiyonu** — İstemci tarafında komutun doldurulması
2. **`IGameSystem::LevelInit`** — Yeni harita başlangıcı (önbelleklerin sıfırlanması için gereklidir)
3. **`CBaseUserCmdPB::SerializePartialToArray`** — Ağ üzerinden gönderim için seri hale getirme (teşhis için gereklidir)

**Hook A** detour'u içerisinde `pb->viewangles` değerini değiştirir ve `raw+0x28` (`input_history`) konumuna sahte `CSGOInputHistoryEntryPB` girdileri ekleyerek tikler arasında hızlı fare dönüşlerini taklit ederiz. CS2 sunucusu bu verileri mermi isabetlerini doğrulamak için kullanır: Ateş ettiğinizde sunucu, dünya durumunu subtick anına geri sarar (rewind) ve ışın takibini (trace) kontrol eder. Sahte `input_history` girdileri enjekte etmek, sunucunun oyuncunun baktığı yön hakkında hatalı bir model oluşturmasını sağlar — bu da anti-aim etkisini yaratır.

Yapılan değişiklikler ağ paketine otomatik olarak yansır: CS2'nin protobuf serileştirmesi, değişikliklerimizi normal verilerle aynı hat üzerinden okur.

---

## Mimari

### Bileşenler

```
src/
├── dllmain.cpp                    DLL giriş noktası, yükleme/kaldırma hattı (pipeline)
├── version_manifest.h             Tüm RVA / ofsetler / md5 / derleme parmak izleri
├── core/
│   ├── signature_scanner.cpp/.h   PE bölümlerinde bayt tabanlı imza taraması (sig-scan)
│   ├── convar.cpp/.h              CS2 ConVar sistemi ile etkileşim
│   └── logf.cpp                   printf çıktısını dosyaya yazma → C:\vmp\fva_recon.log
├── valve/
│   ├── cbaseusercmdpb_layout.h    CBaseUserCmdPB yapı düzeni (offsets, has_bits)
│   ├── cs2_proto_schema.h         Google Protobuf mesaj tanımları (dumper ile doğrulandı)
│   ├── client_input.cpp/.h        CS2 client_input arayüz çözümleme (kullanıcı komut alımı için)
│   └── protobuf_alloc.cpp/.h      CS2 protobuf tahsis edici köprüsü (T::New sarmalayıcıları)
├── features/
│   ├── cvar_suppress.cpp/.h       Hata ayıklama cvar'larının devre dışı bırakılması (cl_showusercmd vb.)
│   └── console_exec.cpp/.h        vtable[25] üzerinden konsola komut enjeksiyonu
├── hooks/
│   ├── hook_manager.cpp/.h        Tüm hook'ların kurulması ve kaldırılması
│   ├── create_move_hook.cpp/.h    Hook A — CreateMove detour + move_crc yazımı
│   ├── level_init_hook.cpp/.h     Hook B — LevelInit detour + zorunlu yeniden çözümleme
│   ├── serialize_to_array_hook.cpp/.h  Hook C — Serialize teşhis yakalaması
│   ├── animation_hook.cpp/.h      Hook D — Animasyon sistemi (taslak/stub)
│   ├── phase_b2.cpp/.h            ★ ANA KOD — J Bölümü yayıcısı (emitter) + Rep büyütme
│   ├── phase_c.cpp/.h             CInButtonStatePB::New / CMsgQAngle::New çözümleme
│   ├── phase_d.cpp/.h             Ek aşama (kritik değil)
│   ├── engine2_bindings.cpp/.h    engine2!IsInGame / IsConnected / LevelShutdown
│   ├── game_state_resolver.cpp/.h CS2 game_state arayüzü çözümleme
│   ├── scratch_serialize.cpp/.h   move_crc için CBaseUserCmdPB'nin yeniden serileştirilmesi
│   └── capture_buffer.cpp/.h      Ağ paketi anlık görüntü arabelleği (Wire snapshot buffer)
├── patterns/
│   └── cs2_signature_atlas.h      139 imza tarama kalıbı (genişletilmiş yüzey)
├── include/
│   └── cs2_structs.h              CS2 yapı türleri (cs2-dumper ofsetleri)
└── tests/
    ├── self_check.cpp/.h          Enjeksiyon anında doğrulama (beklenen md5 + RVA eşleşmesi)
    └── detect_build.cpp           Depot buildid otomatik tespiti

ext/
└── minhook/                       Projeye dahil edilmiş MinHook (trampoline hook kütüphanesi)

scripts/
└── auto_adapt_new_depot.ps1       Yeni depot güncellemeleri için tek tık uyarlama betiği

docs/
└── (Layout, hooks, Section-J ve depot farkları hakkında 5 temel doküman)
```

### Sihirli Kısım — Sahteciliğin Gerçekleştiği Yer

Tüm sahtecilik (spoof) mantığı — **`phase_b2.cpp::run_fva_section_j_emitter` içerisinde yaklaşık 30 satırdan oluşur**:

```cpp
apply(raw_CUserCmd)                        // src/hooks/phase_b2.cpp
  ├── pb = raw->base                        // CBaseUserCmdPB işaretçisi
  ├── pb->has_bits |= VIEWANGLES            // viewangles serileştirmesini zorunlu kıl
  ├── prior = pb->viewangles                // Sahtecilik ÖNCESİ anlık görüntü
  ├── delta = wrap180(prior - target)       // Her eksendeki fark
  └── run_fva_section_j_emitter(...):
        ├── for iter in 0..remaining:
        │     ├── step   = CS2_CSGOInputHistoryEntryPB_New(subs.arena)  // 120B
        │     ├── qangle = CS2_CMsgQAngle_New(nullptr)                  // 40B, heap
        │     ├── qangle.{x,y,z} = prior + fraction*delta                // Sahte açı
        │     ├── step[+0x18] = qangle                                    // step.viewAngles
        │     ├── step[+0x60..0x68] = tick/fraction                       // FVA sabitleri
        │     ├── step->has_bits |= 0x1E01                                // Varlık bayrakları
        │     └── AddAllocated fast-path VEYA add_allocated_slow_path      // Rep içerisine ekleme
        └── bir sonraki tik için referans önbelleğini güncelle
```

**Ağ Üzerinde Görünen Etki:** Sunucu, bu tik içinde "A noktasından B noktasına yumuşak bir şekilde döndüm" şeklinde bir subtick zinciri görür — gerçekte olan anlık dönme yerine. Anti-hile sisteminin zamanı geri alma (rewind) mantığı yanlış yere ateş eder → düşman hasar almaz = anti-aim etkisi.

---

## Önemli Teknik Keşifler

### 1. Protobuf `RepeatedPtrField` — Değiştirerek Ekleme (swap-append) ve Büyütme (grow)

FVA `sub_7FFBE80CB348` (bizim kodumuzdaki `add_allocated_slow_path`) **3 dala** sahiptir:

- **A: Büyütme (grow)** — `!rep || current==total` → `IMemAlloc::Alloc` ile yeni bir `Rep` tahsis et, elemanları kopyala, `subs->rep=new` olarak ayarla.
- **B: Değiştirerek Ekleme (swap-append)** — `allocated<total` → `elements[allocated] = elements[current]; elements[current++] = step; allocated++`.
- **C: Geri Dönüştürme (recycle)** — `allocated==total && current<total && arena==0` → Tahsis yapmadan `elements[current]` üzerine yaz (eski eleman bir sonraki sıfırlamada CS2'nin arenası tarafından geri kazanılır).

İlk aktarımdaki bir hata — Durum C'nin büyütme yapmaya zorlanması → yaklaşık 200 tik sonra CS2'nin ertelenmiş çökmesine neden oluyordu (CS2 `subs->rep` alanını değiştiriyordu ancak `subs->total_size` alanını sıfırlamıyordu → networksystem içinde sınır dışı okumalar gerçekleşiyordu).

### 2. `ArenaStringPtr::Set` ABI

`move_crc` — `ArenaStringPtr` türünde bir alandır (`std::string*` değil!), 3 bit içeren **etiketlenmiş bir işaretçi (tagged pointer)** barındırır:
- bit 0 — `kAllocated`
- bit 1 — `kMutableArena`
- bit 2 — `kDefault`

**Kritik Hata (task #84):**
```cpp
// YANLIŞ — Etiketlenmiş DEĞERİ bu (this) olarak geçirir
arena_set(raw->base->move_crc, &s_bytes, arena);

// DOĞRU — YUVANIN ADRESİNİ geçirir
void* asp_this = static_cast<void*>(&raw->base->move_crc);
arena_set(asp_this, &s_bytes, arena);
```

İlk seçenek CS2'yi yaklaşık 10 saniye sonra çökertiyordu (kısmi bellek yazımı tagged_ptr yapısını bozuyordu). İkinci seçenekte ise doğru `this` = alanın adresi oluyordu.

### 3. Arena Kelimesi Etiketini Kaldırma (word untag)

FVA, arena işaretçilerini etiketlemek için özel bir düzen kullanır (`msg + 8` kelimesinde):
- bit 1 (`raw & 2`) = boş arena etiketi → geçerli arena = 0
- bit 0 (`raw & 1`) = dolaylı erişim bayrağı → geçerli arena = `*(untagged)`
- etiket kaldırılmış taban = `raw & ~3`

Kodumuz:
```cpp
auto untag_msg_arena = [](std::uint8_t* msg) -> std::uint64_t {
    const auto raw = *reinterpret_cast<std::uint64_t*>(msg + 8);
    if (raw & 2) return 0;
    auto untagged = raw & ~std::uint64_t{3};
    if (raw & 1) untagged = *reinterpret_cast<std::uint64_t*>(untagged);
    return untagged;
};
```

### 4. Arenalar Arası Kopyalama (Cross-arena copy)

`step` ve `qangle` farklı arenalarda tahsis edildiğinde FVA (`sub_7FFBE8101CC0`) şunları yapar:
1. `new_qangle = qangle.vtable[+0x10](qangle, target_arena)` (protobuf `New(Arena*)`)
2. `new_qangle.vtable[+0x30](new_qangle, qangle)` (`MergeFrom(other)`)
3. Orijinal yerine `new_qangle` kullan

`+0x10` ve `+0x30` yuvaları — oluşturulan protobuf mesaj vtable'ları için standarttır (sırasıyla `New` ve `MergeFrom`).

### 5. `tier0!g_pMemAlloc` — Ortak Bellek Tahsis Edicisi

FVA `sub_7FFBE80DC5A8` (bizim `cs2_alloc`), XOR ile kodlanmış dizgiler üzerinden çözümleme yapar:
- Modül karma değeri (hash) → `tier0.dll`
- Dışa aktarım (export) → `g_pMemAlloc` (CS2'nin tek genel bellek yöneticisi)

Bizim uyarlamamız doğrudan `GetProcAddress(tier0, "g_pMemAlloc")` kullanır — sonuç tamamen aynıdır, VMP korumalı olmak yerine meşru bir DLL olduğumuz için obfüskasyon baypas edilir.

Vtable yuvaları:
- `[+0x08]` = `Alloc(size)` (yuva 1)
- `[+0x18]` = `Free(ptr)` (yuva 3)
- CS2'nin protobuf çalışma zamanı ile uyumluluk sağlar (her iki taraf da aynı tahsis ediciyi kullandığı için yıkım esnasında Use-After-Free oluşmaz).

---

## Çoklu Depot Desteği (Multi-depot support)

`src/version_manifest.h` dosyası desteklenen her derleme için `#if FVA_TARGET_DEPOT == ...` blokları içerir:

| Depot buildid | client.dll md5 | Boyut | Tarih |
|---|---|---|---|
| **14167** | b0fd08261be12cceb8e5636500e5a1d0 | 37.272.728 B | 2026-07-10 (temel çizgi) |
| **24134959** | 16917fce6c15715434f6604e8086d38a | 37.419.160 B | 2026-07-10 (güncel) |

RVA Değişimi 14167 → 24134959:
```
Hook A CreateMove:      +0x3A598  (0xACEF90  → 0xB09528)
Hook B LevelInit:       +0x3C650  (0xAFDFB0  → 0xB3A600)
Hook C Serialize:       +0x23BB0  (0x1189930 → 0x11AD4E0)
CBaseUserCmdPB::New:    +0x30120  (0x4B21E0  → 0x4E2300)
CSubtickMoveStep::New:  +0x30120  (0x4B22D0  → 0x4E23F0)
CInButtonStatePB::New:  +0x30120  (0x4B2250  → 0x4E2370)
CMsgQAngle::New:        -0x28F00  (0x6840F0  → 0x65B1F0)
CSGOInputHistoryEntry:  +0x34CE0  (0x742730  → 0x777410)
CBaseUserCmdPB vtable:  +0x3FE40  (0x1995748 → 0x19D5588)
ArenaStringPtr::Set:    +0x23BB0  (0x11712C0 → 0x1194E70)
```

---

## Derleme

Gereksinimler: C++20 destekli **Visual Studio 2022** (veya Build Tools), **CMake 3.20+**, **Windows SDK 10.0.26100+**.

```powershell
# Depot 24134959 için (güncel):
cmake -B build -DFVA_TARGET_DEPOT=24134959
cmake --build build --config Release --target fva_recon

# Depot 14167 için (temel çizgi):
cmake -B build_baseline -DFVA_TARGET_DEPOT=14167
cmake --build build_baseline --config Release --target fva_recon

# Çıktı:
#   build/Release/fva_recon.dll        (~82 KB)
#   build_baseline/Release/fva_recon.dll (~82 KB)
```

---

## Kullanım

### Enjeksiyon

`CreateRemoteThread + LoadLibraryW` kullanan herhangi bir standart enjektör yeterlidir. Örnek PowerShell betiği:

```powershell
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class Inj {
    [DllImport("kernel32")] public static extern IntPtr OpenProcess(uint da, bool ih, uint pid);
    [DllImport("kernel32")] public static extern IntPtr VirtualAllocEx(IntPtr h, IntPtr a, uint s, uint t, uint p);
    [DllImport("kernel32")] public static extern bool WriteProcessMemory(IntPtr h, IntPtr a, byte[] b, uint s, out UIntPtr w);
    [DllImport("kernel32")] public static extern IntPtr GetModuleHandle(string m);
    [DllImport("kernel32")] public static extern IntPtr GetProcAddress(IntPtr h, string p);
    [DllImport("kernel32")] public static extern IntPtr CreateRemoteThread(IntPtr h, IntPtr a, uint s, IntPtr sa, IntPtr p, uint f, IntPtr tid);
    public static void Inject(int pid, string dll) {
        IntPtr h = OpenProcess(0x1F0FFF, false, (uint)pid);
        byte[] b = System.Text.Encoding.Unicode.GetBytes(dll + "\0");
        IntPtr m = VirtualAllocEx(h, IntPtr.Zero, (uint)b.Length, 0x3000, 0x04);
        UIntPtr w; WriteProcessMemory(h, m, b, (uint)b.Length, out w);
        IntPtr ll = GetProcAddress(GetModuleHandle("kernel32.dll"), "LoadLibraryW");
        CreateRemoteThread(h, IntPtr.Zero, 0, ll, m, 0, IntPtr.Zero);
    }
}
"@
$cs2 = Get-Process cs2
[Inj]::Inject($cs2.Id, "dosya\yolu\fva_recon.dll")
```

### Enjeksiyondan Sonra Ne Olur?

DLL günlüklerini `C:\vmp\fva_recon.log` dosyasına yazar (`core/logf.cpp` üzerinden değiştirilebilir):

1. CS2 modüllerinin çözümlenmesi (client, engine2, networksystem, animationsystem)
2. client_input arayüzünün çözümlenmesi → get_slot_input, current_seq, get_cmd
3. ICvar arayüzünün çözümlenmesi → cvar_suppress için cvar tablosu
4. Konsol komut arayüzünün çözümlenmesi (potansiyel yürütmeler için)
5. `ArenaStringPtr::Set`, phase_c protobuf T::New, engine2 bağlarının imza taraması
6. Doğrulama (Self-check) — client.dll md5 değerini beklenen ile + üç hook hedefinin ilk 5 baytını karşılaştırır
7. Hook A (CreateMove), Hook B (LevelInit), Hook C (Serialize) kurulumu
8. engine2 LevelShutdown MinHook kurulumu (durum kontrolü için)
9. game_state çözümlenmesi → alt_symbol işaretçisi (ateşleme bayrağı)
10. CSubtickMoveStep vtable çözümlenmesi (doğrulama için)
11. Günlüğe "running — press END to unload" yazılır

Bu andan itibaren her tikte Hook A denetimi alır, `alt_original` (FVA ateşleme bayrağı) durumunu okur ve sıfırdan farklıysa J Bölümü yayıcısını başlatır.

### İzleme / Günlük Takibi

```powershell
Get-Content C:\vmp\fva_recon.log -Wait -Tail 30
```

Günlükteki ölçümler:
- `H1 tick=N` — Hook A tik sayacı
- `SectionJ fired #N` — Sahteciliğin kaç kez tetiklendiği
- `B2-EM ENTRY/EXIT emitted=N` — Kaç subtick üretildiği (tik başına en fazla 15)
- `INSERT ok` / `SLOW-PATH ok (branch=A-grow/B-swap/C-recycle)` — Rep içerisine ekleme yolu
- `MOVE_CRC set` — ArenaStringPtr::Set üzerinden başarılı yazım
- `SEH` — Yapılandırılmış Özel Durum İşleme (SEH) olay sayısı (0 = kusursuz)
- `engine2!stable=0` — Güvenlik kapısının sahteciliği kaç kez engellediği (0 = oyun sürekli kararlı durumda)

---

## Yeni CS2 Sürümüne Uyarlama

Valve bir güncelleme yayınladığında ve client.dll değiştiğinde:

```powershell
# 1. Otomatik analiz betiğini çalıştırın
powershell -ExecutionPolicy Bypass -File scripts/auto_adapt_new_depot.ps1

# Betik:
#   - Mevcut client.dll md5 değerini okur
#   - Eğer yeniyse (14167 veya 24134959 değilse):
#     * depot_snapshots/depot_<buildid>_<tarih>/ dizinine anlık görüntü alır
#     * Hook A/B/C, ArenaStringPtr::Set, 5x protobuf T::New, arena allocator için imza taraması yapar
#     * 24134959 sürümüne kıyasla RVA sapmasını gösterir
#     * version_manifest.h dosyasına yapıştırmanız için hazır bir #elif bloğu verir

# 2. Çıktıdaki bloğu src/version_manifest.h dosyasına kopyalayın (mevcut #elif bloklarının altına)

# 3. build_fingerprint isim alanındaki parmak izini güncelleyin:
#      kExpectedClientMd5[] = "<yeni md5>"
#      kExpectedClientSize  = <yeni boyut>

# 4. Yeniden derleyin:
cmake -B build -DFVA_TARGET_DEPOT=<yeni buildid>
cmake --build build --config Release --target fva_recon
```

Eğer imza taramaları **BAŞARISIZ (MISS)** olursa (Valve ABI yapısını ciddi şekilde değiştirdiyse), IDA üzerinden manuel olarak yapılmalıdır:
1. Yeni client.dll dosyasını IDA ile açın
2. Prolog veya dize referansı (string xref) ile CreateMove fonksiyonunu bulun
3. Sınıf RTTI tanımlayıcısı üzerinden LevelInit fonksiyonunu bulun
4. CBaseUserCmdPB vtable[11] üzerinden SerializePartialToArray fonksiyonunu bulun

Genellikle RVA değişimleri fonksiyon prologlarını korur → imza taraması müdahale gerektirmeden çalışır.

---

## Kararlılık

Depot 24134959 üzerinde yapılan testler:
- ✅ 2 dakika boyunca (~20 dk oyun içi) çökme yaşanmadan 79.271 H1 tiki gerçekleşti
- ✅ ArenaStringPtr::Set üzerinden 15 başarılı move_crc yazımı yapıldı
- ✅ Birincil yolda 10 SEH olayı → tamamı etiketlenmemiş atama yedeklemesiyle yakalandı, kalıcı devre dışı kalma yaşanmadı
- ✅ phase_b2 yayıcısında 0 çökme
- ✅ 4.1 GB kararlı bellek kullanımı (WS)
- ✅ engine2!IsInGame + IsConnected kapısı çalışıyor — 0 adet stable=0 olayı

Depot 14167 temel çizgisinde yapılan testler:
- ✅ 3+ dakika boyunca 88 J Bölümü tetiklemesi
- ✅ 12 başarılı HIZLI YOL eklemesi (fast-path INSERT)
- ✅ 28 YAVAŞ YOL kesintisi (güvenli yedekleme)
- ✅ 0 SEH olayı
- ✅ 0 çökme

---

## Lisans ve Kullanım Amacı

Bu proje **araştırma ve savunma amaçlı** dağıtılmaktadır. Matchmaking / rekabetçi oyunlarda kullanımı [Steam Abone Sözleşmesi](https://store.steampowered.com/subscriber_agreement/) ve Valve kurallarının ihlalidir; bu tür bir kullanım **yazar tarafından desteklenmemektedir**.

Meşru kullanım alanları:
- Anti-hile atlatma (evasion) tekniklerini inceleyerek tespit mantığı oluşturmak
- Hata ödül programlarında (Valve BugHunter) bildirimde bulunmak
- Güvenlik araştırmaları üzerine akademik çalışmalar yürütmek
- İkili dosyalar (binaries) üzerinde tersine mühendislik eğitimi almak

Diğer oyuncuların etkilenmemesi için tüm testler `-insecure` parametresiyle (VAC devre dışı) yerel sunucularda gerçekleştirilmiştir.

---

## Teknik Referanslar

- FVA (`FuckVacAgain.dll`) — Temel alınan orijinal obfüske eklenti
- Google Protobuf 3.21.8 — [RepeatedPtrField kaynak kodu](https://github.com/protocolbuffers/protobuf)
- VMProtect 3.9.4 — FVA tarafından kullanılan ticari koruyucu
- MinHook — [github.com/TsudaKageyu/minhook](https://github.com/TsudaKageyu/minhook)
- SteamKit ProtobufDumper — [CS2 ikililerinden .proto çıkarmak için](https://github.com/SteamRE/SteamKit)
- cs2-dumper — [Ofset çıkarımı için](https://github.com/a2x/cs2-dumper)

---

## Yazar / Katkıda Bulunanlar

IDA Pro Hex-Rays + Cheat Engine + x64dbg yardımıyla yürütülen tersine mühendislik çalışmalarına dayanmaktadır. Tüm imza tarama kalıpları ve RVA'lar, orijinal kaynak koda erişim olmadan client.dll dosyasının ayrıştırılmasıyla bağımsız olarak doğrulanmıştır.
